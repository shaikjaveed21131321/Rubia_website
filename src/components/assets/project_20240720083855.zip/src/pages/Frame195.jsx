import './Frame195.css'

export default function Frame195() {
  return (
    <div className="frame-195">
      <div className="singh">
        <div className="container">
          <div className="group-95">
            <div className="rectangle-50">
            </div>
            <span className="job-seeker">
            #Job seeker
            </span>
          </div>
          <div className="container-1">
            <div className="sampras-singh">
            Sampras singh
            </div>
            <div className="ui-ux-designer">
            UI/UX Designer
            </div>
            <p className="remote-internship-alertrubia-services-read-more">
            <span className="remote-internship-alertrubia-services-read-more-sub-0"></span><span></span>
            </p>
          </div>
        </div>
        <div className="container-2">
          <div className="hr-ago">
          1hr ago
          </div>
          <div className="pepicons-popdots-y">
            <div className="vector-2">
            </div>
            <div className="vector-1">
            </div>
            <div className="vector">
            </div>
          </div>
        </div>
      </div>
      <div className="group-104">
        <div className="rectangle-51">
        </div>
      </div>
      <div className="component-7">
        <div className="container-3">
          <span className="likes">
          120 likes
          </span>
          <span className="comments">
          123 Comments
          </span>
        </div>
        <div className="rectangle-53">
        </div>
        <div className="frame-172">
          <div className="frame-128">
            <div className="mdilike-outline">
              <img className="vector-3" src="assets/vectors/Vector240_x2.svg" />
            </div>
            <div className="like">
            Like
            </div>
          </div>
          <div className="frame-129">
            <div className="material-symbolscomment-outline">
              <img className="vector-4" src="assets/vectors/Vector142_x2.svg" />
            </div>
            <div className="comment">
            Comment
            </div>
          </div>
          <div className="frame-130">
            <div className="material-symbolsshare">
              <img className="vector-5" src="assets/vectors/Vector237_x2.svg" />
            </div>
            <div className="share">
            Share
            </div>
          </div>
          <div className="frame-131">
            <div className="fluentsave-copy-20-filled">
              <img className="vector-6" src="assets/vectors/Vector446_x2.svg" />
            </div>
            <div className="save">
            Save
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
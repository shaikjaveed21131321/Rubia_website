import './Property1Component175.css'

export default function Property1Component175() {
  return (
    <div className="property-1-component-17">
      <div className="rectangle-72">
      </div>
      <span className="music">
      Music
      </span>
    </div>
  )
}
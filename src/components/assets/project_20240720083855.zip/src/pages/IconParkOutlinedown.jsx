import './IconParkOutlinedown.css'

export default function IconParkOutlinedown() {
  return (
    <div className="icon-park-outlinedown">
      <img className="vector" src="assets/vectors/Vector124_x2.svg" />
    </div>
  )
}
import './Group117.css'

export default function Group117() {
  return (
    <div className="group-117">
      <div className="container-7">
        <div className="frame-176">
          <span className="residential">
          Residential
          </span>
        </div>
        <div className="frame-177">
          <span className="commercial">
          Commercial
          </span>
        </div>
        <div className="frame-178">
          <span className="plots-1">
          Plots
          </span>
        </div>
      </div>
      <div className="container-4">
        <div className="flates">
          <span className="flates-1">
          Independent House
          </span>
        </div>
        <div className="under-50-lac-1">
          <span className="under-50-lac-3">
          Independent House
          </span>
        </div>
        <div className="under-50-lac-2">
          <span className="under-50-lac-4">
          Open plots
          </span>
        </div>
      </div>
      <div className="container-5">
        <div className="house">
          <span className="house-1">
          duplex house 
          </span>
        </div>
        <div className="cr-15-cr-1">
          <span className="cr-15-cr-2">
          Duplex house 
          </span>
        </div>
      </div>
      <div className="container-1">
        <div className="plots">
          <span className="plots-2">
          Triplex house
          </span>
        </div>
        <div className="under-50-lac">
          <span className="lac-1-cr">
          Triplex house
          </span>
        </div>
      </div>
      <div className="container-2">
        <div className="villas">
          <span className="villas-1">
          Independent flates
          </span>
        </div>
        <div className="cr-15-cr">
          <span className="above-15-cr">
          Open plots
          </span>
        </div>
      </div>
      <div className="office-space">
        <span className="office-space-2">
        duplex flates
        </span>
      </div>
      <div className="office-space-1">
        <span className="office-space-3">
        Triplex flates
        </span>
      </div>
      <div className="container">
        <div className="container-6">
          <span className="buy">
          Buy
          </span>
        </div>
        <div className="container-3">
          <span className="rent">
          Rent
          </span>
        </div>
      </div>
    </div>
  )
}
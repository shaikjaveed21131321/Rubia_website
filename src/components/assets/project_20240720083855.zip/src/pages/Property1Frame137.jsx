import './Property1Frame137.css'

export default function Property1Frame137() {
  return (
    <div className="property-1-frame-137">
      <span className="done">
      Done
      </span>
    </div>
  )
}
import './Property1Group1111.css'

export default function Property1Group1111() {
  return (
    <div className="property-1-group-111">
      <span className="sign-in">
      Sign in
      </span>
      <div className="mingcutedown-fill">
        <img className="vector" src="assets/vectors/Vector414_x2.svg" />
      </div>
    </div>
  )
}
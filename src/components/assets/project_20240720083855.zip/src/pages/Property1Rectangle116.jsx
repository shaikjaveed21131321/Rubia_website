import './Property1Rectangle116.css'

export default function Property1Rectangle116() {
  return (
    <div className="property-1-rectangle-116">
      <div className="rectangle-116">
      </div>
    </div>
  )
}
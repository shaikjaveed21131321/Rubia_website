import './LikeComment.css'

export default function LikeComment() {
  return (
    <div className="like-comment">
      <div className="container">
        <span className="likes">
        1203 likes
        </span>
        <span className="comments">
        1203 Comments
        </span>
      </div>
      <div className="rectangle-53">
      </div>
      <div className="container-1">
        <div className="frame-128">
          <div className="mdilike-outline">
            <img className="vector" src="assets/vectors/Vector360_x2.svg" />
          </div>
          <span className="like">
          Like
          </span>
        </div>
        <div className="frame-129">
          <div className="material-symbolscomment-outline">
            <img className="vector-1" src="assets/vectors/Vector278_x2.svg" />
          </div>
          <div className="comment">
          Comment
          </div>
        </div>
        <div className="frame-130">
          <div className="material-symbolsshare">
            <img className="vector-2" src="assets/vectors/Vector238_x2.svg" />
          </div>
          <div className="share">
          Share
          </div>
        </div>
        <div className="frame-131">
          <div className="fluentsave-copy-20-filled">
            <img className="vector-3" src="assets/vectors/Vector370_x2.svg" />
          </div>
          <span className="save">
          Save
          </span>
        </div>
      </div>
    </div>
  )
}
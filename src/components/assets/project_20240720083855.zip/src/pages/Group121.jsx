import './Group121.css'

export default function Group121() {
  return (
    <div className="group-121">
      <div className="rectangle-102">
      </div>
    </div>
  )
}
import './Property1Frame1806.css'

export default function Property1Frame1806() {
  return (
    <div className="property-1-frame-180">
      <span className="with-in-25-kilometers">
      With in 25 kilometers
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector483_x2.svg" />
      </div>
    </div>
  )
}
import './Property1Group170.css'

export default function Property1Group170() {
  return (
    <div className="property-1-group-170">
      <div className="no-1">
        <div className="group-155">
          <div className="image-3">
          </div>
          <div className="rectangle-124">
          </div>
          <div className="rectangle-28">
          </div>
          <div className="ellipse-4">
          </div>
          <div className="ellipse-5">
          </div>
        </div>
      </div>
      <div className="container-2">
        <div className="container">
          <div className="group-166">
            <div className="unnati-shree-rath-apartments">
            Unnati Shree Rath Apartments
            </div>
            <span className="nizampet-hyderabad">
            Nizampet, Hyderabad
            </span>
          </div>
          <div className="days-ago">
          2 days ago<br />
          
          </div>
        </div>
        <div className="frame-221">
          <div className="container-4">
            <div className="frame-217">
              <img className="group-164" src="assets/vectors/Group1644_x2.svg" />
              <span className="beds">
              4Beds
              </span>
            </div>
            <div className="frame-218">
              <img className="id-76-bdb-6-oht-rkv-v-28-elmb-db-xzx-1" src="assets/vectors/Id76Bdb6OhtRkvV28ElmbDbXzx118_x2.svg" />
              <span className="baths">
              3Baths
              </span>
            </div>
            <div className="frame-219">
              <div className="phcar-thin">
                <img className="vector-20" src="assets/vectors/Vector568_x2.svg" />
              </div>
              <span className="covered-parking">
              1 Covered Parking
              </span>
            </div>
          </div>
          <div className="frame-220">
            <img className="id-eg-1-cr-1-iyh-0-n-8-o-1-wy-psxkl-5-ms-1" src="assets/vectors/IdEg1Cr1Iyh0N8O1WyPsxkl5Ms118_x2.svg" />
            <span className="unfurnished">
            Unfurnished
            </span>
          </div>
        </div>
        <div className="group-167">
          <p className="transaction-type-new-property">
          <span className="transaction-type-new-property-sub-7"></span><span></span>
          </p>
          <p className="status-ready-to-move">
          <span className="status-ready-to-move-sub-5"></span><span></span>
          </p>
          <p className="super-area-2079-sqft">
          <span className="super-area-2079-sqft-sub-5"></span><span></span>
          </p>
        </div>
        <div className="container-3">
          <div className="group-165">
            <p className="cr">
            <span className="cr-sub-1"></span><span></span>
            </p>
            <div className="rectangle-126">
            </div>
            <img className="iytsnctfi-5-e-8-sm-zs-pj-cy-3-erg-b-71" src="assets/vectors/Iytsnctfi5E8SmZsPjCy3ErgB715_x2.svg" />
            <div className="sqft">
            2079 sqft
            </div>
          </div>
          <div className="container-1">
            <div className="frame-223">
              <span className="share">
              Share
              </span>
            </div>
            <div className="frame-222">
              <span className="contact">
              Contact
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
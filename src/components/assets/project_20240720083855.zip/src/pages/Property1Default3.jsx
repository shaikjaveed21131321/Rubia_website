import './Property1Default3.css'

export default function Property1Default3() {
  return (
    <div className="property-1-default">
      <span className="employers-sign-in">
      Employers  Sign in
      </span>
    </div>
  )
}
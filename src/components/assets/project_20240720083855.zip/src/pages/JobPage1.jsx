import './JobPage1.css'

export default function JobPage1() {
  return (
    <div className="job-page">
      <div className="group-90">
        <div className="rectangle-29">
        </div>
        <div className="rectangle-30">
        </div>
        <div className="rectangle-31">
        </div>
        <div className="rectangle-32">
        </div>
      </div>
      <div className="container-8">
        <div className="container-2">
          <div className="group-101">
          </div>
          <div className="frame-4">
            <span className="home-1">
            HOME
            </span>
            <span className="services">
            SERVICES
            </span>
            <span className="about-us">
            ABOUT US
            </span>
            <span className="contact-us">
            CONTACT US
            </span>
            <span className="blog">
            BLOG
            </span>
          </div>
        </div>
        <div className="container-6">
          <div className="group-89">
            <div className="frame-12">
              <span className="we-provide">
              We Provide
              </span>
            </div>
            <div className="frame-3">
              <span className="drivers">
              DRIVERS
              </span>
            </div>
            <div className="frame-7">
              <span className="graphic-designing">
              GRAPHIC DESIGNING
              </span>
            </div>
            <div className="frame-6">
              <span className="software">
              SOFTWARE
              </span>
            </div>
            <div className="frame-8">
              <span className="digital-marketing">
              DIGITAL MARKETING
              </span>
            </div>
            <div className="frame-15">
              <span className="ux-ui-designing">
              UX/UI Designing
              </span>
            </div>
            <div className="frame-114">
              <span className="taxi">
              TAXI
              </span>
            </div>
            <div className="frame-115">
              <span className="job-portal">
              JOB PORTAL
              </span>
            </div>
            <div className="frame-116">
              <span className="real-estate">
              REAL ESTATE
              </span>
            </div>
          </div>
          <div className="container-12">
            <div className="container-10">
              <div className="container">
                <div className="frame-123">
                  <div className="heroiconshome-solid">
                    <img className="group-3" src="assets/vectors/Group2_x2.svg" />
                  </div>
                  <span className="home">
                  Home
                  </span>
                </div>
                <div className="component-5">
                  <div className="icbaseline-search-1">
                    <img className="vector-28" src="assets/vectors/Vector463_x2.svg" />
                  </div>
                  <span className="search">
                  Search
                  </span>
                </div>
                <div className="component-2">
                  <div className="basilbag-solid">
                    <img className="vector-31" src="assets/vectors/Vector50_x2.svg" />
                    <img className="vector-32" src="assets/vectors/Vector649_x2.svg" />
                  </div>
                  <span className="jobs">
                  Jobs
                  </span>
                </div>
                <div className="component-6">
                  <div className="mdipeople-add">
                    <img className="vector-29" src="assets/vectors/Vector311_x2.svg" />
                  </div>
                  <span className="my-network">
                  My Network
                  </span>
                </div>
                <div className="component-4">
                  <div className="lets-iconsmessage-fill">
                    <img className="vector-30" src="assets/vectors/Vector403_x2.svg" />
                  </div>
                  <span className="messages">
                  Messages
                  </span>
                </div>
                <div className="frame-178">
                  <div className="ellipse-14">
                  </div>
                  <div className="frame-176">
                    <span className="profile">
                    Profile
                    </span>
                    <div className="teenyiconsdown-solid">
                      <img className="vector-33" src="assets/vectors/Vector125_x2.svg" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="group-108">
                <div className="ready-to-find-your-dream-job-now">
                Ready  to Find your Dream Job Now
                </div>
                <div className="group-94">
                  <div className="container-7">
                    <div className="icbaseline-search">
                      <img className="vector-16" src="assets/vectors/Vector674_x2.svg" />
                    </div>
                    <span className="ui-ux-designer">
                    ui ux designer
                    </span>
                  </div>
                  <div className="container-3">
                    <div className="rectangle-46">
                    </div>
                    <div className="weuilocation-outlined">
                      <img className="vector-17" src="assets/vectors/Vector528_x2.svg" />
                    </div>
                    <div className="hyderabad">
                    Hyderabad
                    </div>
                  </div>
                  <div className="frame-126">
                    <span className="search-jobs">
                    Search Jobs
                    </span>
                  </div>
                </div>
              </div>
              <div className="group-113">
                <div className="group-112">
                  <div className="ellipse-141">
                  </div>
                  <div className="container-11">
                    <div className="sampras-singh">
                    Sampras singh
                    </div>
                    <span className="ui-ux-designer-2">
                    UI/UX Designer
                    </span>
                  </div>
                </div>
                <div className="frame-179">
                  <span className="view-profile">
                  View profile
                  </span>
                </div>
                <div className="employers-sign-in">
                Employers Sign in 
                </div>
                <span className="sign-out">
                Sign Out 
                </span>
              </div>
            </div>
            <div className="container-4">
              <div className="frame-220">
                <div className="frame-218">
                  <div className="image-1">
                  </div>
                  <div className="frame-202">
                    <div className="ui-ux-designer-1">
                    UI/UX Designer
                    </div>
                    <span className="rubia-services">
                    Rubia.services
                    </span>
                  </div>
                </div>
                <div className="frame-219">
                  <div className="frame-216">
                    <div className="weuilocation-outlined-1">
                      <img className="vector-18" src="assets/vectors/Vector202_x2.svg" />
                    </div>
                    <div className="hyderabad-erragadda">
                    Hyderabad, Erragadda 
                    </div>
                  </div>
                  <div className="frame-217">
                    <div className="group-109">
                      <span className="container">
                      ₹
                      </span>
                      <div className="ellipse-15">
                      </div>
                    </div>
                    <div className="monthly">
                    ₹15,000 - 30,000 monthly
                    </div>
                  </div>
                </div>
              </div>
              <div className="container-1">
                <div className="frame-212">
                  <div className="icomoon-freeoffice">
                    <img className="vector-19" src="assets/vectors/Vector340_x2.svg" />
                  </div>
                  <div className="work-from-office">
                  Work from Office
                  </div>
                </div>
                <div className="frame-213">
                  <div className="healthiconsf-negative">
                    <img className="vector-20" src="assets/vectors/Vector667_x2.svg" />
                  </div>
                  <div className="full-time">
                  Full Time<br />
                  
                  </div>
                </div>
                <div className="frame-214">
                  <div className="phbag-simple-light">
                    <img className="vector-21" src="assets/vectors/Vector613_x2.svg" />
                  </div>
                  <div className="min-3-months">
                  Min. 3 Months
                  </div>
                </div>
                <div className="frame-222">
                  <img className="vector-23" src="assets/vectors/Vector178_x2.svg" />
                  <div className="day-shift">
                  Day Shift
                  </div>
                </div>
              </div>
              <div className="container-5">
                <div className="frame-209">
                  <span className="apply">
                  Apply
                  </span>
                </div>
                <div className="frame-221">
                  <div className="material-symbolsshare">
                    <img className="vector-22" src="assets/vectors/Vector450_x2.svg" />
                  </div>
                  <div className="share">
                  Share
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-13">
          <div className="job-description">
          Job Description
          </div>
          <div className="ux-ui-designer-responsive-designsprototypeslogos-for-websites-and-campaign-pages-website-layout-app-layout-create-ui-solutions-in-adobe-xd-figma-or-similar-software-managing-the-ux-ui-design-on-multiple-projects-in-parallel-prototyping-of-ux-ui-designs-within-the-low-codeno-code-platform-to-accelerate-time-to-valuemarket-for-mvps-deliver-wireframes-ux-flows-mockups-interactive-prototypesdesign-specifications-and-final-assets-rapidly-prototype-new-designs-and-concepts-experience-in-avariety-of-design-and-prototype-tools-such-as-xd-sketch-axure-invisionapp-photoshop-illustrator-and-in-design-or-similar">
          UX UI Designer<br />
          <br />
          Responsive designs/prototypes/logos for websites and campaign pages<br />
          Website Layout, App Layout<br />
          Create UI Solutions in Adobe XD, Figma or similar software<br />
          Managing the UX / UI Design on multiple projects in parallel.<br />
          Prototyping of UX / UI designs within the low-code/no-code platform to accelerate time to value/market for MVP’s Deliver wireframes, UX flows, mockups, interactive prototypes,design specifications, and final assets. Rapidly prototype new designs and concepts.<br />
          Experience in a variety of design and prototype tools such as XD, Sketch, Axure, Invisionapp, Photoshop, Illustrator and InDesign or similar
          </div>
          <div className="rectangle-66">
          </div>
          <div className="interview-details">
          Interview details
          </div>
          <div className="frame-224">
            <div className="game-iconsface-to-face">
              <img className="vector-24" src="assets/vectors/Vector542_x2.svg" />
            </div>
            <div className="frame-223">
              <div className="interview-mode">
              Interview Mode
              </div>
              <span className="face-to-face">
              Face -to- face
              </span>
            </div>
          </div>
          <div className="frame-225">
            <div className="hugeiconslocation-04">
              <img className="group-4" src="assets/vectors/Group8_x2.svg" />
            </div>
            <div className="frame-2231">
              <div className="interview-address">
              Interview address
              </div>
              <span className="address-pillar-no-974-flat-no-107-rams-enclave-above-jawa-showroom-erragadda">
              Address :  pillar no. 974,Flat no.<br />
              107,Rams Enclave, above Jawa Showroom, Erragadda
              </span>
            </div>
          </div>
          <div className="rectangle-67">
          </div>
          <div className="about-company">
          About company
          </div>
          <div className="frame-226">
            <div className="image-11">
            </div>
            <div className="frame-2232">
              <div className="name">
              Name
              </div>
              <span className="rubia-services-1">
              Rubia.services
              </span>
            </div>
          </div>
          <div className="frame-227">
            <div className="weuilocation-outlined-2">
              <img className="vector-27" src="assets/vectors/Vector681_x2.svg" />
            </div>
            <div className="frame-2233">
              <div className="location">
              Location
              </div>
              <span className="address-pillar-no-974-flat-no-107-rams-enclave-above-jawa-showroom-erragadda-1">
              Address :  pillar no. 974,Flat no.<br />
              107,Rams Enclave, above Jawa Showroom, Erragadda
              </span>
            </div>
          </div>
        </div>
        <div className="frame-31">
          <div className="download-the-mobile-app-now">
          Download the Mobile App Now
          </div>
          <div className="frame-30">
            <div className="frame-29">
              <div className="qr-code">
                <img className="vector-11" src="assets/vectors/Vector308_x2.svg" />
              </div>
              <div className="image-260-nw-23151053071">
              </div>
            </div>
            <div className="frame-28">
              <div className="qr-code-1">
                <img className="vector-13" src="assets/vectors/Vector564_x2.svg" />
              </div>
              <div className="image-260-nw-23151053072">
              </div>
            </div>
          </div>
        </div>
        <div className="frame-27">
          <div className="container-9">
            <div className="frame-22">
              <div className="links">
              Links
              </div>
              <div className="frame-20">
                <div className="home-2">
                Home
                </div>
                <div className="about">
                About
                </div>
                <div className="service">
                Service
                </div>
                <span className="contact-us-1">
                Contact us
                </span>
              </div>
            </div>
            <div className="frame-21">
              <div className="info">
              Info
              </div>
              <div className="frame-201">
                <div className="terms-conditions">
                Terms &amp; Conditions
                </div>
                <div className="refund-policy">
                Refund policy
                </div>
                <span className="privacy-policy">
                Privacy policy
                </span>
              </div>
            </div>
            <div className="frame-19">
              <div className="address">
              Address
              </div>
              <div className="frame-18">
                <p className="registed-61105-saifabad-khairatabad-hyderabad-500004">
                <span className="registed-61105-saifabad-khairatabad-hyderabad-500004-sub-1"></span><span></span>
                </p>
                <p className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018">
                <span className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018-sub-2"></span><span></span>
                </p>
              </div>
            </div>
          </div>
          <div className="frame-26">
            <div className="frame-24">
              <div className="contact-no">
              Contact No
              </div>
              <div className="frame-23">
                <div className="container-1">
                +91 78936 53899
                </div>
                <span className="inforubia-services">
                info@rubia.services
                </span>
              </div>
            </div>
            <div className="frame-25">
              <div className="skill-iconstwitter">
                <img className="group" src="assets/vectors/Group42_x2.svg" />
              </div>
              <div className="akar-iconsfacebook-fill">
                <img className="vector-3" src="assets/vectors/Vector643_x2.svg" />
              </div>
              <div className="skill-iconslinkedin">
                <img className="group-1" src="assets/vectors/Group12_x2.svg" />
              </div>
              <div className="skill-iconsinstagram">
                <img className="group-2" src="assets/vectors/Group19_x2.svg" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
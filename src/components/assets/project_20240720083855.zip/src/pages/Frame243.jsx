import './Frame243.css'

export default function Frame243() {
  return (
    <div className="frame-243">
    </div>
  )
}
import './Property1Default19.css'

export default function Property1Default19() {
  return (
    <div className="property-1-default">
      <img className="group-115" src="assets/vectors/Group115_x2.svg" />
      <div className="frame-125">
        <span className="plots-pg">
        Plots/PG
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector595_x2.svg" />
        </div>
      </div>
    </div>
  )
}
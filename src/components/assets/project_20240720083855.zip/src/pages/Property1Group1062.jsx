import './Property1Group1062.css'

export default function Property1Group1062() {
  return (
    <div className="property-1-group-106">
      <div className="frame-136">
        <div className="container-1">
          <span className="likes">
          1203 likes
          </span>
          <span className="comments">
          1203 Comments
          </span>
        </div>
        <div className="rectangle-53">
        </div>
      </div>
      <div className="frame-135">
        <div className="frame-128">
          <div className="mdilike-outline">
            <img className="vector-4" src="assets/vectors/Vector33_x2.svg" />
          </div>
          <div className="like">
          Like
          </div>
        </div>
        <div className="frame-129">
          <div className="material-symbolscomment-outline">
            <img className="vector" src="assets/vectors/Vector506_x2.svg" />
          </div>
          <div className="comment">
          Comment
          </div>
        </div>
        <div className="frame-130">
          <div className="material-symbolsshare">
            <img className="vector-1" src="assets/vectors/Vector170_x2.svg" />
          </div>
          <div className="share">
          Share
          </div>
        </div>
        <div className="frame-131">
          <div className="fluentsave-copy-20-filled">
            <img className="vector-2" src="assets/vectors/Vector96_x2.svg" />
          </div>
          <span className="save">
          Save
          </span>
        </div>
      </div>
      <div className="frame-134">
        <div className="rectangle-49">
        </div>
        <div className="group-103">
          <span className="add-acomment">
          Add a Comment
          </span>
          <div className="fluentemoji-24-regular">
            <img className="vector-3" src="assets/vectors/Vector612_x2.svg" />
          </div>
        </div>
      </div>
      <div className="frame-137">
        <div className="rectangle-56">
        </div>
        <div className="group-105">
          <div className="container">
            <span className="karan-sharma">
            Karan sharma
            </span>
            <div className="mdilike-outline-1">
              <img className="vector-5" src="assets/vectors/Vector112_x2.svg" />
            </div>
          </div>
          <div className="ui-ux-designer">
          UI/UX Designer
          </div>
          <span className="interested">
          #interested
          </span>
        </div>
      </div>
      <div className="frame-138">
        <div className="rectangle-561">
        </div>
        <div className="group-1051">
          <div className="container-2">
            <span className="karan-sharma-1">
            Karan sharma
            </span>
            <div className="mdilike-outline-2">
              <img className="vector-6" src="assets/vectors/Vector546_x2.svg" />
            </div>
          </div>
          <div className="ui-ux-designer-1">
          UI/UX Designer
          </div>
          <span className="interested-1">
          #interested
          </span>
        </div>
      </div>
      <div className="read-more-comment">
        <span className="read-more-comment-1">
        Read more comment
        </span>
      </div>
    </div>
  )
}
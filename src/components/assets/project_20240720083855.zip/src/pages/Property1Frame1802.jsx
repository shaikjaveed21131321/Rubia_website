import './Property1Frame1802.css'

export default function Property1Frame1802() {
  return (
    <div className="property-1-frame-180">
      <span className="remote">
      Remote
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector99_x2.svg" />
      </div>
    </div>
  )
}
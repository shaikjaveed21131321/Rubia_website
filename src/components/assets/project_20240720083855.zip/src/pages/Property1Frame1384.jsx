import './Property1Frame1384.css'

export default function Property1Frame1384() {
  return (
    <div className="property-1-frame-138">
      <span className="bicycles">
      Bicycles
      </span>
    </div>
  )
}
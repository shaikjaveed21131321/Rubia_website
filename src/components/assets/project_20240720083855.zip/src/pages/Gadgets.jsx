import './Gadgets.css'

export default function Gadgets() {
  return (
    <div className="gadgets">
      <div className="codicongame">
        <img className="group" src="assets/vectors/Group86_x2.svg" />
      </div>
      <div className="moter-cycle">
        <span className="gadgets-1">
        gadgets 
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-2" src="assets/vectors/Vector422_x2.svg" />
        </div>
      </div>
    </div>
  )
}
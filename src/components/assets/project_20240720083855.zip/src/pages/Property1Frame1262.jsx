import './Property1Frame1262.css'

export default function Property1Frame1262() {
  return (
    <div className="property-1-frame-126">
      <div className="frame-125">
        <div className="basilbag-solid">
          <img className="vector" src="assets/vectors/Vector192_x2.svg" />
          <img className="vector-1" src="assets/vectors/Vector18_x2.svg" />
        </div>
        <span className="jobs">
        Jobs
        </span>
      </div>
      <div className="group-92">
        <div className="container-1">
          <div className="container-2">
            <div className="job-by-category">
            Job By Category
            </div>
            <div className="frame-118">
              <div className="it">
                <span className="it-software">
                IT / software
                </span>
              </div>
              <div className="internship-jobs">
                <span className="internship-jobs-1">
                Internship jobs 
                </span>
              </div>
              <div className="part-time-jobs">
                <span className="part-time-jobs-1">
                Part time jobs
                </span>
              </div>
              <div className="mba-jobs">
                <span className="mba-jobs-1">
                MBA Jobs
                </span>
              </div>
              <div className="bank-jobs">
                <span className="bank-jobs-1">
                Bank jobs
                </span>
              </div>
              <div className="data-science-jobs">
                <span className="data-science-jobs-1">
                Data Science jobs
                </span>
              </div>
              <div className="diploma-jobs">
                <span className="diploma-jobs-2">
                Diploma jobs
                </span>
              </div>
              <div className="engineering-jobs">
                <span className="engineering-jobs-1">
                Engineering jobs
                </span>
              </div>
              <div className="health-care">
                <span className="health-care-1">
                Health care
                </span>
              </div>
              <div className="hr-jobs">
                <span className="hr-jobs-1">
                HR jobs
                </span>
              </div>
              <div className="journalism">
                <span className="journalism-1">
                Journalism
                </span>
              </div>
              <div className="marketing-jobs">
                <span className="marketing-jobs-1">
                Marketing jobs
                </span>
              </div>
              <div className="sales-jobs">
                <span className="sales-jobs-1">
                Sales jobs
                </span>
              </div>
              <div className="research">
                <span className="research-1">
                Research
                </span>
              </div>
              <div className="pharmacy-jobs">
                <span className="pharmacy-jobs-1">
                Pharmacy jobs 
                </span>
              </div>
            </div>
          </div>
          <div className="rectangle-35">
          </div>
          <div className="container">
            <div className="job-by-location">
            Job By Location
            </div>
            <div className="frame-121">
              <div className="any-where-in-india">
                <span className="any-where-in-india-1">
                Any where in India
                </span>
              </div>
              <div className="telangana">
                <span className="telangana-1">
                Telangana
                </span>
              </div>
              <div className="hyderabad">
                <span className="hyderabad-1">
                Hyderabad
                </span>
              </div>
              <div className="bangalore">
                <span className="bangalore-1">
                Bangalore
                </span>
              </div>
              <div className="chennai">
                <span className="chennai-1">
                Chennai
                </span>
              </div>
              <div className="delhi">
                <span className="delhi-1">
                Delhi
                </span>
              </div>
              <div className="jaipur">
                <span className="jaipur-1">
                Jaipur
                </span>
              </div>
              <div className="mumbai">
                <span className="mumbai-1">
                Mumbai
                </span>
              </div>
              <div className="pune">
                <span className="pune-1">
                Pune
                </span>
              </div>
            </div>
          </div>
          <div className="rectangle-37">
          </div>
          <div className="container-3">
            <div className="job-by-courses">
            Job By Courses
            </div>
            <div className="frame-122">
              <div className="btech">
                <span className="btech-1">
                B.Tech
                </span>
              </div>
              <div className="bca-jobs">
                <span className="bca-jobs-1">
                BCA jobs
                </span>
              </div>
              <div className="be">
                <span className="be-1">
                BE
                </span>
              </div>
              <div className="bsc-jobs">
                <span className="bsc-jobs-1">
                BSC jobs
                </span>
              </div>
              <div className="diploma-jobs-1">
                <span className="diploma-jobs-3">
                Diploma jobs
                </span>
              </div>
              <div className="inter-jobs">
                <span className="inter-jobs-1">
                Inter jobs
                </span>
              </div>
              <div className="msc-jobs">
                <span className="msc-jobs-1">
                M.sc jobs
                </span>
              </div>
              <div className="mba">
                <span className="mba-1">
                MBA
                </span>
              </div>
              <div className="other-courses">
                <span className="other-courses-1">
                Other Courses...
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="rectangle-36">
        </div>
      </div>
    </div>
  )
}
import './Property1Group106.css'

export default function Property1Group106() {
  return (
    <div className="property-1-group-106">
      <div className="container">
        <span className="likes">
        1203 likes
        </span>
        <span className="comments">
        1203 Comments
        </span>
      </div>
      <div className="rectangle-53">
      </div>
      <div className="frame-172">
        <div className="frame-128">
          <div className="mdilike-outline">
            <img className="vector-3" src="assets/vectors/Vector173_x2.svg" />
          </div>
          <div className="like">
          Like
          </div>
        </div>
        <div className="frame-129">
          <div className="material-symbolscomment-outline">
            <img className="vector" src="assets/vectors/Vector251_x2.svg" />
          </div>
          <div className="comment">
          Comment
          </div>
        </div>
        <div className="frame-130">
          <div className="material-symbolsshare">
            <img className="vector-1" src="assets/vectors/Vector758_x2.svg" />
          </div>
          <div className="share">
          Share
          </div>
        </div>
        <div className="frame-131">
          <div className="fluentsave-copy-20-filled">
            <img className="vector-2" src="assets/vectors/Vector466_x2.svg" />
          </div>
          <div className="save">
          Save
          </div>
        </div>
      </div>
    </div>
  )
}
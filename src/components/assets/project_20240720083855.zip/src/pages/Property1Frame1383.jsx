import './Property1Frame1383.css'

export default function Property1Frame1383() {
  return (
    <div className="property-1-frame-138">
      <span className="scooters">
      Scooters
      </span>
    </div>
  )
}
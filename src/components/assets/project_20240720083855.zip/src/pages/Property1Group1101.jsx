import './Property1Group1101.css'

export default function Property1Group1101() {
  return (
    <div className="property-1-group-110">
      <div className="frame-211">
        <div className="ui-ux-designer">
        UI/UX Designer
        </div>
        <p className="posted-1-hr-ago">
        <span className="posted-1-hr-ago-sub-3"></span><span></span>
        </p>
      </div>
      <div className="rectangle-63">
      </div>
      <div className="frame-203">
        <div className="image-1">
        </div>
        <div className="frame-202">
          <div className="rubia-services">
          Rubia.services
          </div>
          <span className="hyderabad-erragadda">
          Hyderabad, Erragadda 
          </span>
        </div>
      </div>
      <div className="frame-208">
        <div className="frame-204">
          <div className="group-109">
            <span className="container">
            ₹
            </span>
            <div className="ellipse-15">
            </div>
          </div>
          <div className="container-1">
          ₹15,000 - 30,000
          </div>
        </div>
        <div className="frame-205">
          <div className="phbag-simple-light">
            <img className="vector" src="assets/vectors/Vector152_x2.svg" />
          </div>
          <div className="months-experience">
          3 Months Experience
          </div>
        </div>
        <div className="frame-206">
          <div className="teenyiconsbulb-on-outline">
            <img className="vector-1" src="assets/vectors/Vector693_x2.svg" />
          </div>
          <div className="figma-photoshop-adobe-xd-protopie-maze">
          Figma , Photoshop , Adobe XD , Protopie , Maze 
          </div>
        </div>
        <div className="frame-207">
          <img className="carboneducation" src="assets/vectors/Carboneducation4_x2.svg" />
          <div className="bachelors-degree">
          Bachelor’s degree 
          </div>
        </div>
      </div>
      <div className="container">
        <div className="frame-210">
          <img className="rectangle-62" src="assets/vectors/Rectangle623_x2.svg" />
        </div>
        <div className="frame-209">
          <span className="apply">
          Apply
          </span>
        </div>
      </div>
    </div>
  )
}
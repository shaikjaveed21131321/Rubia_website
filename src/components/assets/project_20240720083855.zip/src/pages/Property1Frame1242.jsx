import './Property1Frame1242.css'

export default function Property1Frame1242() {
  return (
    <div className="property-1-frame-124">
      <div className="icbaseline-search">
        <img className="vector" src="assets/vectors/Vector327_x2.svg" />
      </div>
      <span className="search">
      Search
      </span>
    </div>
  )
}
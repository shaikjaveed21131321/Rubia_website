import './Frame1271.css'

export default function Frame1271() {
  return (
    <div className="frame-127">
      <span className="follow">
      Follow
      </span>
    </div>
  )
}
import './Property1Frame217.css'

export default function Property1Frame217() {
  return (
    <div className="property-1-frame-217">
      <div className="group-135">
        <span className="budget">
        Budget
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector750_x2.svg" />
        </div>
      </div>
      <div className="group-154">
        <div className="container-2">
          <div className="budget-1">
          Budget
          </div>
          <div className="container">
            <div className="group-136">
              <span className="lac">
              ₹5Lac
              </span>
              <div className="group">
                <img className="vector-1" src="assets/vectors/Vector522_x2.svg" />
              </div>
            </div>
            <div className="group-137">
              <span className="max">
              Max
              </span>
              <div className="group-1">
                <img className="vector-2" src="assets/vectors/Vector174_x2.svg" />
              </div>
            </div>
          </div>
          <div className="container-1">
            <div className="group-139">
              <span className="lac-1">
              ₹5Lac
              </span>
            </div>
            <div className="group-138">
              <span className="cr">
              ₹ 5cr
              </span>
            </div>
          </div>
          <div className="rectangle-106">
          </div>
          <div className="done">
            <span className="done-1">
            Done
            </span>
          </div>
        </div>
        <div className="rectangle-105">
        </div>
        <div className="group-152">
          <div className="ellipse-21">
          </div>
          <span className="container-1">
          +
          </span>
        </div>
        <div className="group-150">
          <div className="ellipse-18">
          </div>
          <span className="container">
          -
          </span>
        </div>
      </div>
    </div>
  )
}
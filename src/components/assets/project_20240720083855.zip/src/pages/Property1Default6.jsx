import './Property1Default6.css'

export default function Property1Default6() {
  return (
    <div className="property-1-default">
      <div className="mingcuteservice-fill">
        <img className="vector" src="assets/vectors/Vector689_x2.svg" />
      </div>
      <div className="frame-125">
        <span className="help">
        Help
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-1" src="assets/vectors/Vector223_x2.svg" />
        </div>
      </div>
    </div>
  )
}
import './Property1Group135.css'

export default function Property1Group135() {
  return (
    <div className="property-1-group-135">
      <span className="posted-by">
      Posted By
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector359_x2.svg" />
      </div>
    </div>
  )
}
import './Group101.css'

export default function Group101() {
  return (
    <div className="group-101">
      <img className="rectangle-40" src="assets/vectors/Rectangle401_x2.svg" />
      <img className="rectangle-39" src="assets/vectors/Rectangle392_x2.svg" />
      <span className="sign-in">
      Sign in
      </span>
      <span className="employers">
      Employers 
      </span>
    </div>
  )
}
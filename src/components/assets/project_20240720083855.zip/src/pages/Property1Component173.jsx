import './Property1Component173.css'

export default function Property1Component173() {
  return (
    <div className="property-1-component-17">
      <div className="rectangle-72">
      </div>
      <span className="sanchari">
      Sanchari
      </span>
    </div>
  )
}
import './JobPortal.css'

export default function JobPortal() {
  return (
    <div className="job-portal">
      <div className="container-2">
        <div className="group-101">
        </div>
        <div className="frame-4">
          <span className="home">
          HOME
          </span>
          <span className="services">
          SERVICES
          </span>
          <span className="about-us">
          ABOUT US
          </span>
          <span className="contact-us">
          CONTACT US
          </span>
          <span className="blog">
          BLOG
          </span>
        </div>
      </div>
      <div className="container-1">
        <div className="group-89">
          <div className="frame-12">
            <span className="we-provide">
            We Provide
            </span>
          </div>
          <div className="frame-3">
            <span className="drivers">
            DRIVERS
            </span>
          </div>
          <div className="frame-7">
            <span className="graphic-designing">
            GRAPHIC DESIGNING
            </span>
          </div>
          <div className="frame-6">
            <span className="software">
            SOFTWARE
            </span>
          </div>
          <div className="frame-8">
            <span className="digital-marketing">
            DIGITAL MARKETING
            </span>
          </div>
          <div className="frame-15">
            <span className="ux-ui-designing">
            UX/UI Designing
            </span>
          </div>
          <div className="frame-114">
            <span className="taxi">
            TAXI
            </span>
          </div>
          <div className="frame-115">
            <span className="job-portal-1">
            JOB PORTAL
            </span>
          </div>
          <div className="frame-116">
            <span className="real-estate">
            REAL ESTATE
            </span>
          </div>
        </div>
        <div className="container-9">
          <div className="container-6">
            <div className="frame-123">
              <div className="heroiconshome-solid">
                <img className="group-3" src="assets/vectors/Group54_x2.svg" />
              </div>
              <span className="home-2">
              Home
              </span>
            </div>
            <div className="component-5">
              <div className="icbaseline-search-1">
                <img className="vector-18" src="assets/vectors/Vector480_x2.svg" />
              </div>
              <span className="search">
              Search
              </span>
            </div>
            <div className="component-2">
              <div className="basilbag-solid">
                <img className="vector-21" src="assets/vectors/Vector233_x2.svg" />
                <img className="vector-22" src="assets/vectors/Vector365_x2.svg" />
              </div>
              <span className="jobs">
              Jobs
              </span>
            </div>
            <div className="component-6">
              <div className="mdipeople-add">
                <img className="vector-19" src="assets/vectors/Vector75_x2.svg" />
              </div>
              <span className="my-network">
              My Network
              </span>
            </div>
            <div className="component-4">
              <div className="lets-iconsmessage-fill">
                <img className="vector-20" src="assets/vectors/Vector452_x2.svg" />
              </div>
              <span className="messages">
              Messages
              </span>
            </div>
          </div>
          <div className="ready-to-find-your-dream-job-now">
          Ready  to Find your Dream Job Now
          </div>
          <div className="group-94">
            <div className="container-3">
              <div className="icbaseline-search">
                <img className="vector-16" src="assets/vectors/Vector102_x2.svg" />
              </div>
              <span className="search-job-by">
              Search job by
              </span>
              <div className="component-3">
                <span className="skill">
                ‘Skill’
                </span>
              </div>
            </div>
            <div className="container">
              <div className="rectangle-46">
              </div>
              <div className="weuilocation-outlined">
                <img className="vector-17" src="assets/vectors/Vector127_x2.svg" />
              </div>
              <div className="anywhere-in-india">
              Anywhere in India
              </div>
            </div>
            <div className="frame-126">
              <span className="search-jobs">
              Search Jobs
              </span>
            </div>
          </div>
          <div className="frame-173">
            <div className="profile">
              <div className="container-4">
                <div className="group-95">
                  <div className="rectangle-50">
                  </div>
                  <span className="hiring">
                  #Hiring
                  </span>
                </div>
                <div className="container-10">
                  <div className="sampras-singh">
                  Sampras singh
                  </div>
                  <div className="rubia-services-recruiter">
                  Rubia.services Recruiter
                  </div>
                  <p className="remote-internship-alertrubia-services-read-more">
                  <span className="remote-internship-alertrubia-services-read-more-sub-0"></span><span></span>
                  </p>
                </div>
              </div>
              <div className="container-7">
                <div className="hr-ago">
                1hr ago
                </div>
                <div className="frame-127">
                  <span className="follow">
                  Follow
                  </span>
                </div>
              </div>
            </div>
            <div className="group-104">
              <div className="image-8">
              </div>
            </div>
            <div className="component-7">
              <div className="container-5">
                <span className="likes">
                1203 likes
                </span>
                <span className="comments">
                1203 Comments
                </span>
              </div>
              <div className="rectangle-53">
              </div>
              <div className="frame-172">
                <div className="frame-128">
                  <div className="mdilike-outline">
                    <img className="vector-23" src="assets/vectors/Vector245_x2.svg" />
                  </div>
                  <div className="like">
                  Like
                  </div>
                </div>
                <div className="frame-129">
                  <div className="material-symbolscomment-outline">
                    <img className="vector-24" src="assets/vectors/Vector338_x2.svg" />
                  </div>
                  <div className="comment">
                  Comment
                  </div>
                </div>
                <div className="frame-130">
                  <div className="material-symbolsshare">
                    <img className="vector-25" src="assets/vectors/Vector347_x2.svg" />
                  </div>
                  <div className="share">
                  Share
                  </div>
                </div>
                <div className="frame-131">
                  <div className="fluentsave-copy-20-filled">
                    <img className="vector-26" src="assets/vectors/Vector694_x2.svg" />
                  </div>
                  <div className="save">
                  Save
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="group-90">
          <div className="rectangle-29">
          </div>
          <div className="rectangle-30">
          </div>
          <div className="rectangle-31">
          </div>
          <div className="rectangle-32">
          </div>
        </div>
      </div>
      <div className="frame-31">
        <div className="download-the-mobile-app-now">
        Download the Mobile App Now
        </div>
        <div className="frame-30">
          <div className="frame-29">
            <div className="qr-code">
              <img className="vector-11" src="assets/vectors/Vector387_x2.svg" />
            </div>
            <div className="image-260-nw-23151053071">
            </div>
          </div>
          <div className="frame-28">
            <div className="qr-code-1">
              <img className="vector-13" src="assets/vectors/Vector288_x2.svg" />
            </div>
            <div className="image-260-nw-23151053072">
            </div>
          </div>
        </div>
      </div>
      <div className="frame-27">
        <div className="container-8">
          <div className="frame-22">
            <div className="links">
            Links
            </div>
            <div className="frame-20">
              <div className="home-1">
              Home
              </div>
              <div className="about">
              About
              </div>
              <div className="service">
              Service
              </div>
              <span className="contact-us-1">
              Contact us
              </span>
            </div>
          </div>
          <div className="frame-21">
            <div className="info">
            Info
            </div>
            <div className="frame-201">
              <div className="terms-conditions">
              Terms &amp; Conditions
              </div>
              <div className="refund-policy">
              Refund policy
              </div>
              <span className="privacy-policy">
              Privacy policy
              </span>
            </div>
          </div>
          <div className="frame-19">
            <div className="address">
            Address
            </div>
            <div className="frame-18">
              <p className="registed-61105-saifabad-khairatabad-hyderabad-500004">
              <span className="registed-61105-saifabad-khairatabad-hyderabad-500004-sub-1"></span><span></span>
              </p>
              <p className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018">
              <span className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018-sub-2"></span><span></span>
              </p>
            </div>
          </div>
        </div>
        <div className="frame-26">
          <div className="frame-24">
            <div className="contact-no">
            Contact No
            </div>
            <div className="frame-23">
              <div className="container">
              +91 78936 53899
              </div>
              <span className="inforubia-services">
              info@rubia.services
              </span>
            </div>
          </div>
          <div className="frame-25">
            <div className="skill-iconstwitter">
              <img className="group" src="assets/vectors/Group48_x2.svg" />
            </div>
            <div className="akar-iconsfacebook-fill">
              <img className="vector-3" src="assets/vectors/Vector290_x2.svg" />
            </div>
            <div className="skill-iconslinkedin">
              <img className="group-1" src="assets/vectors/Group61_x2.svg" />
            </div>
            <div className="skill-iconsinstagram">
              <img className="group-2" src="assets/vectors/Group29_x2.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
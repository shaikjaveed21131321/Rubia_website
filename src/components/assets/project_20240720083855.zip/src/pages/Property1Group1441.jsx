import './Property1Group1441.css'

export default function Property1Group1441() {
  return (
    <div className="property-1-group-144">
      <div className="ellipse-21">
      </div>
    </div>
  )
}
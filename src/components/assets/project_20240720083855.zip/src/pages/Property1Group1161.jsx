import './Property1Group1161.css'

export default function Property1Group1161() {
  return (
    <div className="property-1-group-116">
      <div className="rectangle-72">
      </div>
      <span className="game-screen-ui">
      Game screen Ui
      </span>
    </div>
  )
}
import './Property1Group1631.css'

export default function Property1Group1631() {
  return (
    <div className="property-1-group-163">
      <div className="unnati-shree-rath-apartments">
      Unnati Shree Rath Apartments
      </div>
      <div className="nizampet-hyderabad">
      Nizampet, Hyderabad
      </div>
      <div className="group-162">
        <p className="cr">
        <span className="cr-sub-6"></span><span></span>
        </p>
        <div className="container">
          <div className="rectangle-126">
          </div>
          <span className="sqft">
          2044 sqft
          </span>
        </div>
      </div>
      <img className="iytsnctfi-5-e-8-sm-zs-pj-cy-3-erg-b-71" src="assets/vectors/Iytsnctfi5E8SmZsPjCy3ErgB7114_x2.svg" />
    </div>
  )
}
import './PopUpSignIn1.css'

export default function PopUpSignIn1() {
  return (
    <div className="pop-up-sign-in">
      <div className="container">
        <div className="employers-sign-in">
        Employers  Sign in
        </div>
        <div className="enter-your-mobile-number-email-id-for-login">
        Enter your mobile number &amp; Email id for Login 
        </div>
        <div className="group-105">
          <div className="container-3">
            <span className="enter-your-mobile-number-here">
            Enter your Mobile number here
            </span>
          </div>
          <div className="frame-142">
            <span className="mobile-number">
            Mobile Number
            </span>
          </div>
        </div>
        <div className="group-106">
          <div className="container-2">
            <span className="enter-your-email-id-here">
            Enter your email id here
            </span>
          </div>
          <div className="frame-1421">
            <span className="email-id">
            Email id
            </span>
          </div>
        </div>
        <div className="group-107">
          <div className="container-1">
            <span className="minimum-6-characters">
            Minimum 6 characters
            </span>
          </div>
          <div className="frame-1422">
            <span className="password">
            Password
            </span>
          </div>
        </div>
        <div className="frame-178">
          <span className="continue">
          Continue
          </span>
        </div>
        <div className="frame-190">
          <span className="dont-have-an-account">
          Don’t have an account? 
          </span>
          <span className="sign-up">
          Sign up
          </span>
        </div>
      </div>
      <span className="forgot-possword">
      Forgot Possword
      </span>
    </div>
  )
}
import './Property1Frame1774.css'

export default function Property1Frame1774() {
  return (
    <div className="property-1-frame-177">
      <div className="group-114">
        <div className="group-108">
          <div className="ellipse-16">
          </div>
        </div>
        <div className="buyer">
        Buyer
        </div>
      </div>
      <div className="group-112">
        <div className="group-109">
          <div className="ellipse-151">
          </div>
        </div>
        <div className="owner">
        Owner
        </div>
      </div>
      <div className="group-111">
        <div className="group-110">
          <div className="ellipse-152">
          </div>
        </div>
        <div className="agent">
        Agent
        </div>
      </div>
      <div className="group-113">
        <div className="group-1101">
          <div className="ellipse-153">
          </div>
        </div>
        <div className="builder">
        Builder
        </div>
      </div>
    </div>
  )
}
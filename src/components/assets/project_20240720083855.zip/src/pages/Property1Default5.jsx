import './Property1Default5.css'

export default function Property1Default5() {
  return (
    <div className="property-1-default">
      <img className="group-93" src="assets/vectors/Group933_x2.svg" />
      <div className="frame-125">
        <span className="sell">
        Sell
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-6" src="assets/vectors/Vector751_x2.svg" />
        </div>
      </div>
    </div>
  )
}
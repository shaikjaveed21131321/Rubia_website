import './Frame178.css'

export default function Frame178() {
  return (
    <div className="frame-178">
      <span className="post">
      Post
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector505_x2.svg" />
      </div>
    </div>
  )
}
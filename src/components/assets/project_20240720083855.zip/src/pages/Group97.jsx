import './Group97.css'

export default function Group97() {
  return (
    <div className="group-97">
      <div className="group-95">
        <div className="rectangle-50">
        </div>
        <span className="hiring">
        #Hiring
        </span>
      </div>
      <div className="container">
        <p className="sampras-singh-1-hr-ago">
        <span className="sampras-singh-1-hr-ago-sub-0"></span><span></span>
        </p>
        <div className="rubia-services-recruiter">
        Rubia.services Recruiter
        </div>
        <p className="remote-internship-alertrubia-services-bangalore-india-is-hiring-ui-ux-designer-intern-stipend-rs-20-k-25-kmonth-eligible-202120222023202420252026-skills-figma-ui-ux-product-design-ux-research-duration-3-monthsstarting-date-immediate-comment-interested-ill-dm-you-the-link-see-less">
        <span className="remote-internship-alertrubia-services-bangalore-india-is-hiring-ui-ux-designer-intern-stipend-rs-20-k-25-kmonth-eligible-202120222023202420252026-skills-figma-ui-ux-product-design-ux-research-duration-3-monthsstarting-date-immediate-comment-interested-ill-dm-you-the-link-see-less-sub-0"></span><span></span>
        </p>
      </div>
    </div>
  )
}
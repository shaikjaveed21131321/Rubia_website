import './Property1Frame1373.css'

export default function Property1Frame1373() {
  return (
    <div className="property-1-frame-137">
      <span className="scooters">
      Scooters
      </span>
    </div>
  )
}
import './Property1Group110.css'

export default function Property1Group110() {
  return (
    <div className="property-1-group-110">
      <div className="container">
        <div className="job-seeker-sign-in">
        Job seeker Sign in
        </div>
        <span className="employers-sign-in">
        Employers  Sign in
        </span>
      </div>
      <div className="mingcutedown-fill">
        <img className="vector" src="assets/vectors/Vector253_x2.svg" />
      </div>
    </div>
  )
}
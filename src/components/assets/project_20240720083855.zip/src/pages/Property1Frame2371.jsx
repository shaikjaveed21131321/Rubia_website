import './Property1Frame2371.css'

export default function Property1Frame2371() {
  return (
    <div className="property-1-frame-237">
      <div className="rectangle-49">
      </div>
      <div className="frame-236">
        <div className="shiva-krishna">
        Shiva Krishna
        </div>
        <span className="web-design">
        web design
        </span>
      </div>
    </div>
  )
}
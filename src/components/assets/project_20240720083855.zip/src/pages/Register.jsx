import './Register.css'

export default function Register() {
  return (
    <div className="register">
      <div className="job-seeker-register">
      Job Seeker Register
      </div>
      <div className="enter-your-mobile-number-email-id-for-create-aaccount">
      Enter your mobile number &amp; Email id for Create a Account 
      </div>
      <div className="container">
        <div className="frame-1881">
          <div className="name">
          Name
          </div>
          <div className="frame-13">
            <span className="first-name">
            First name
            </span>
          </div>
        </div>
        <div className="frame-1891">
          <div className="frame-14">
            <span className="last-name">
            Last name
            </span>
          </div>
        </div>
      </div>
      <div className="container-2">
        <div className="frame-188">
          <div className="email-id">
          Email id
          </div>
          <div className="frame-11">
            <span className="enter-your-email-id-here">
            Enter your email id here
            </span>
          </div>
        </div>
        <div className="frame-187">
          <div className="mobile-number">
          Mobile Number
          </div>
          <div className="frame-1">
            <img className="emojione-v-1-flag-for-india" src="assets/vectors/EmojioneV1FlagForIndia1_x2.svg" />
            <div className="container">
            +91
            </div>
            <div className="enter-your-10-digit-mobile-number">
            Enter your 10 digit Mobile number 
            </div>
          </div>
        </div>
      </div>
      <div className="container-3">
        <div className="frame-189">
          <div className="create-password">
          Create Password
          </div>
          <div className="frame-12">
            <span className="minimum-6-characters">
            Minimum 6 characters
            </span>
          </div>
        </div>
        <div className="frame-191">
          <div className="reenter-password">
          Reenter Password
          </div>
          <div className="frame-16">
            <span className="reenter-password-1">
            Reenter Password
            </span>
          </div>
        </div>
      </div>
      <div className="container-1">
        <div className="frame-1901">
          <div className="qualification-details">
          Qualification Details
          </div>
          <div className="frame-15">
            <span className="select-course">
            Select Course
            </span>
          </div>
        </div>
        <div className="frame-193">
          <div className="upload-resume">
          Upload Resume
          </div>
          <div className="frame-192">
            <span className="choose-file">
            Choose File
            </span>
          </div>
        </div>
      </div>
      <div className="frame-178">
        <span className="submit">
        Submit
        </span>
      </div>
      <div className="frame-190">
        <span className="already-have-an-account">
        Already have an account
        </span>
        <span className="sign-in">
        Sign in
        </span>
      </div>
    </div>
  )
}
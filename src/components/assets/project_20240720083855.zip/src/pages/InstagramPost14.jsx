import './InstagramPost14.css'

export default function InstagramPost14() {
  return (
    <div className="instagram-post-14">
      <img className="ellipse-1" src="assets/vectors/Ellipse1_x2.svg" />
      <div className="group-101">
      </div>
      <img className="container" src="assets/vectors/Container1_x2.svg" />
    </div>
  )
}
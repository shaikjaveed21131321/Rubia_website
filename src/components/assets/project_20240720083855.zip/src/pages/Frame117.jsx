import './Frame117.css'

export default function Frame117() {
  return (
    <div className="frame-117">
      <span className="jobs">
      Jobs
      </span>
      <div className="group">
        <img className="vector" src="assets/vectors/Vector392_x2.svg" />
      </div>
    </div>
  )
}
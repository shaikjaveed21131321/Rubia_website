import './Component1.css'

export default function Component1() {
  return (
    <div className="component-1">
      <span className="jobs">
      Jobs
      </span>
      <div className="mingcutedown-fill">
        <img className="vector" src="assets/vectors/Vector749_x2.svg" />
      </div>
    </div>
  )
}
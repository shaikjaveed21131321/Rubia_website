import './Property1Group1091.css'

export default function Property1Group1091() {
  return (
    <div className="property-1-group-109">
      <span className="sign-in">
      Sign in
      </span>
      <div className="mingcutedown-fill">
        <img className="vector" src="assets/vectors/Vector94_x2.svg" />
      </div>
    </div>
  )
}
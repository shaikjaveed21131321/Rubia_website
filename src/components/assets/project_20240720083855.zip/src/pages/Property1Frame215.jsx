import './Property1Frame215.css'

export default function Property1Frame215() {
  return (
    <div className="property-1-frame-215">
      <div className="group-133">
        <span className="bhk">
        BHK
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector79_x2.svg" />
        </div>
      </div>
      <div className="group-134">
        <div className="bhk-1">
        BHK
        </div>
        <div className="container">
          <div className="component-13">
            <span className="independent-house">
            1 BHK
            </span>
          </div>
          <div className="component-14">
            <span className="independent-house-1">
            2 BHK
            </span>
          </div>
          <div className="component-15">
            <span className="independent-house-2">
            3 BHK
            </span>
          </div>
          <div className="component-16">
            <span className="independent-house-3">
            4 BHK
            </span>
          </div>
        </div>
        <div className="container-1">
          <div className="component-17">
            <span className="independent-house-4">
            5 BHK
            </span>
          </div>
          <div className="component-18">
            <span className="independent-house-5">
            &gt;5 BHK
            </span>
          </div>
        </div>
        <div className="done">
          <span className="done-1">
          Done
          </span>
        </div>
      </div>
    </div>
  )
}
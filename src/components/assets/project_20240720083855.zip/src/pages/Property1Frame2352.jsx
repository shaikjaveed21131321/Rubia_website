import './Property1Frame2352.css'

export default function Property1Frame2352() {
  return (
    <div className="property-1-frame-235">
      <div className="material-symbolspost-add">
        <img className="vector-1" src="assets/vectors/Vector712_x2.svg" />
      </div>
      <span className="create-apost">
      Create a post
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector632_x2.svg" />
      </div>
    </div>
  )
}
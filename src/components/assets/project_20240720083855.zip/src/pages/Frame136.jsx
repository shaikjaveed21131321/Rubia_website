import './Frame136.css'

export default function Frame136() {
  return (
    <div className="frame-136">
      <div className="mditv">
        <img className="vector" src="assets/vectors/Vector70_x2.svg" />
      </div>
      <div className="frame-135">
        <span className="electronic-appliances">
        Electronic<br />
        Appliances
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-1" src="assets/vectors/Vector517_x2.svg" />
        </div>
      </div>
    </div>
  )
}
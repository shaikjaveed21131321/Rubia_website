import './Property1Frame1271.css'

export default function Property1Frame1271() {
  return (
    <div className="property-1-frame-127">
      <img className="group-94" src="assets/vectors/Group9412_x2.svg" />
      <div className="frame-126">
        <span className="home-loans">
        Home Loans
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-3" src="assets/vectors/Vector666_x2.svg" />
        </div>
      </div>
    </div>
  )
}
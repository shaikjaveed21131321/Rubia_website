import './Property1Group111.css'

export default function Property1Group111() {
  return (
    <div className="property-1-group-111">
      <div className="property-1-group-112">
        <span className="sign-in">
        Sign in
        </span>
        <div className="mingcutedown-fill">
          <img className="vector" src="assets/vectors/Vector257_x2.svg" />
        </div>
      </div>
      <div className="group-110">
        <div className="job-seeker-sign-in">
        Job seeker Sign in
        </div>
        <span className="employers-sign-in">
        Employers  Sign in
        </span>
      </div>
    </div>
  )
}
import './Property1Frame1387.css'

export default function Property1Frame1387() {
  return (
    <div className="property-1-frame-138">
      <span className="read-more-comment">
      Read more comment
      </span>
    </div>
  )
}
import './Group120.css'

export default function Group120() {
  return (
    <div className="group-120">
      <div className="rectangle-49">
      </div>
      <div className="frame-235">
        <div className="sandeep">
        Sandeep
        </div>
        <span className="uiux-designer">
        Ui/ux designer
        </span>
      </div>
    </div>
  )
}
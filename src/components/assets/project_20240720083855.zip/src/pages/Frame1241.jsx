import './Frame1241.css'

export default function Frame1241() {
  return (
    <div className="frame-124">
      <div className="lets-iconsmessage-fill">
        <img className="vector" src="assets/vectors/Vector82_x2.svg" />
      </div>
      <span className="search">
      Search
      </span>
    </div>
  )
}
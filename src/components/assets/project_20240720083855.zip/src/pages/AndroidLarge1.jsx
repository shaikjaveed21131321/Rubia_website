import './AndroidLarge1.css'

export default function AndroidLarge1() {
  return (
    <div className="android-large-1">
      <div className="component-10">
        <span className="sign-in">
        Sign in
        </span>
        <div className="mingcutedown-fill">
          <img className="vector" src="assets/vectors/Vector87_x2.svg" />
        </div>
      </div>
    </div>
  )
}
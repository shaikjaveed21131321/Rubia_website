import './Property1Default34.css'

export default function Property1Default34() {
  return (
    <div className="property-1-default">
      <div className="giscar">
        <img className="vector" src="assets/vectors/Vector103_x2.svg" />
      </div>
      <div className="frame-134">
        <span className="cars">
        Cars
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-1" src="assets/vectors/Vector224_x2.svg" />
        </div>
      </div>
    </div>
  )
}
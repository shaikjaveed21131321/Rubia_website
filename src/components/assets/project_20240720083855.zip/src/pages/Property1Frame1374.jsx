import './Property1Frame1374.css'

export default function Property1Frame1374() {
  return (
    <div className="property-1-frame-137">
      <span className="bicycles">
      Bicycles
      </span>
    </div>
  )
}
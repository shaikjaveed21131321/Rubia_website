import './SelectYouCar2.css'

export default function SelectYouCar2() {
  return (
    <div className="select-you-car-2">
      <div className="group-77">
        <div className="select-your-car">
        Select your car
        </div>
        <div className="container">
          <div className="group-74">
            <div className="automatic">
              <div className="material-symbols-lightdirections-car">
                <img className="vector" src="assets/vectors/Vector411_x2.svg" />
              </div>
              <span className="automatic-1">
              Automatic
              </span>
              <div className="mingcutedown-fill">
                <img className="vector-1" src="assets/vectors/Vector660_x2.svg" />
              </div>
            </div>
          </div>
          <div className="group-75">
            <div className="tablermanual-gearbox-filled">
              <img className="vector-2" src="assets/vectors/Vector358_x2.svg" />
            </div>
            <div className="manual">
            Manual
            </div>
            <div className="mingcutedown-fill-1">
              <img className="vector-3" src="assets/vectors/Vector98_x2.svg" />
            </div>
          </div>
        </div>
      </div>
      <img className="group-78" src="assets/vectors/Group781_x2.svg" />
      <div className="frame-108">
        <div className="giscar">
          <img className="vector-4" src="assets/vectors/Vector664_x2.svg" />
        </div>
        <span className="hatchback">
        Hatchback
        </span>
      </div>
      <div className="frame-109">
        <div className="bicar-front-fill">
          <img className="vector-5" src="assets/vectors/Vector71_x2.svg" />
        </div>
        <span className="sedan">
        Sedan
        </span>
      </div>
      <div className="luxury">
        <div className="ioncar-sport-sharp">
          <img className="vector-6" src="assets/vectors/Vector589_x2.svg" />
        </div>
        <span className="luxury-1">
        Luxury
        </span>
      </div>
      <div className="frame-107">
        <div className="bitcoin-iconscar-filled">
          <img className="vector-7" src="assets/vectors/Vector532_x2.svg" />
        </div>
        <span className="suv">
        Suv
        </span>
      </div>
      <div className="mditick-circle-outline">
        <img className="vector-8" src="assets/vectors/Vector601_x2.svg" />
      </div>
    </div>
  )
}
import './Property1Frame1773.css'

export default function Property1Frame1773() {
  return (
    <div className="property-1-frame-177">
      <span className="hybrid-work">
      Hybrid Work
      </span>
    </div>
  )
}
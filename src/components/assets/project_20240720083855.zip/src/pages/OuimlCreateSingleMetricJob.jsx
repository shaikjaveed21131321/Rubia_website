import './OuimlCreateSingleMetricJob.css'

export default function OuimlCreateSingleMetricJob() {
  return (
    <div className="ouiml-create-single-metric-job">
      <img className="vector" src="assets/vectors/Vector388_x2.svg" />
      <img className="vector-1" src="assets/vectors/Vector500_x2.svg" />
    </div>
  )
}
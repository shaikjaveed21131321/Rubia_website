import './Profile.css'

export default function Profile() {
  return (
    <div className="profile">
      <div className="ellipse-14">
      </div>
      <div className="frame-176">
        <span className="profile-1">
        Profile
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector47_x2.svg" />
        </div>
      </div>
    </div>
  )
}
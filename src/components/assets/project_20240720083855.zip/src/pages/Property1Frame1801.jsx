import './Property1Frame1801.css'

export default function Property1Frame1801() {
  return (
    <div className="property-1-frame-180">
      <div className="frame-178">
        <div className="ellipse-14">
        </div>
        <div className="frame-176">
          <span className="profile">
          Profile
          </span>
          <div className="teenyiconsdown-solid">
            <img className="vector" src="assets/vectors/Vector97_x2.svg" />
          </div>
        </div>
      </div>
      <div className="group-113">
        <div className="group-112">
          <div className="ellipse-141">
          </div>
          <div className="container">
            <div className="sampras-singh">
            Sampras singh
            </div>
            <span className="ui-ux-designer">
            UI/UX Designer
            </span>
          </div>
        </div>
        <div className="frame-179">
          <span className="view-profile">
          View profile
          </span>
        </div>
        <div className="employers-sign-in">
        Employers Sign in 
        </div>
        <span className="sign-out">
        Sign Out 
        </span>
      </div>
    </div>
  )
}
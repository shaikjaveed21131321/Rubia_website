import './Property1Filter2.css'

export default function Property1Filter2() {
  return (
    <div className="property-1-filter-2">
      <span className="filters">
      Filters
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector742_x2.svg" />
      </div>
    </div>
  )
}
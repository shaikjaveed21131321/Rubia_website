import './RealEstate7.css'

export default function RealEstate7() {
  return (
    <div className="real-estate">
      <img className="group-90" src="assets/vectors/Group90_x2.svg" />
      <div className="container-16">
        <div className="group-101">
        </div>
        <div className="frame-4">
          <span className="home">
          HOME
          </span>
          <span className="services">
          SERVICES
          </span>
          <span className="about-us">
          ABOUT US
          </span>
          <span className="contact-us">
          CONTACT US
          </span>
          <span className="blog">
          BLOG
          </span>
        </div>
      </div>
      <div className="container-13">
        <div className="side-bar">
          <div className="frame-12">
            <span className="our-services">
            OUR SERVICES
            </span>
          </div>
          <div className="frame-228">
            <div className="fcc">
              <img className="mask-group-1" src="assets/vectors/MaskGroup69_x2.svg" />
              <div className="business-listing">
              Business Listing
              </div>
            </div>
            <div className="drivers">
              <img className="mask-group-2" src="assets/vectors/MaskGroup89_x2.svg" />
              <div className="drivers-1">
              DRIVERS
              </div>
            </div>
            <div className="taxi">
              <img className="mask-group-3" src="assets/vectors/MaskGroup37_x2.svg" />
              <div className="taxi-1">
              TAXI
              </div>
            </div>
            <div className="graphic-designing">
              <div className="group-42">
                <img className="mask-group-4" src="assets/vectors/MaskGroup79_x2.svg" />
              </div>
              <span className="graphic-designing-1">
              GRAPHIC DESIGNING
              </span>
            </div>
            <div className="software">
              <img className="mask-group-5" src="assets/vectors/MaskGroup66_x2.svg" />
              <div className="software-1">
              SOFTWARE
              </div>
            </div>
            <div className="digital-marketing">
              <img className="mask-group-6" src="assets/vectors/MaskGroup61_x2.svg" />
              <div className="digital-marketing-1">
              DIGITAL MARKETING
              </div>
            </div>
            <div className="ux-ui-designing">
              <img className="mask-group-7" src="assets/vectors/MaskGroup27_x2.svg" />
              <div className="ux-ui-designing-1">
              UX/UI Designing
              </div>
            </div>
            <div className="job-portal">
              <img className="mask-group-8" src="assets/vectors/MaskGroup7_x2.svg" />
              <div className="job-portal-1">
              JOB PORTAL
              </div>
            </div>
            <div className="frame-116">
              <img className="mask-group" src="assets/vectors/MaskGroup52_x2.svg" />
              <div className="real-estate-1">
              REAL ESTATE
              </div>
            </div>
          </div>
        </div>
        <div className="container-4">
          <div className="container-18">
            <div className="container-20">
              <div className="buy-222">
                <img className="group-91" src="assets/vectors/Group915_x2.svg" />
                <div className="frame-124">
                  <span className="buy">
                  Buy
                  </span>
                  <div className="teenyiconsdown-solid-3">
                    <img className="vector-38" src="assets/vectors/Vector752_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="rent-1">
                <img className="group-92" src="assets/vectors/Group9210_x2.svg" />
                <div className="frame-1253">
                  <span className="rent">
                  Rent
                  </span>
                  <div className="teenyiconsdown-solid-5">
                    <img className="vector-43" src="assets/vectors/Vector93_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="sell">
                <img className="group-93" src="assets/vectors/Group9314_x2.svg" />
                <div className="frame-125">
                  <span className="sell-1">
                  Sell
                  </span>
                  <div className="teenyiconsdown-solid">
                    <img className="vector-24" src="assets/vectors/Vector169_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="home-loans">
                <img className="group-941" src="assets/vectors/Group943_x2.svg" />
                <div className="frame-1261">
                  <span className="home-loans-1">
                  Home Loans
                  </span>
                  <div className="teenyiconsdown-solid-1">
                    <img className="vector-28" src="assets/vectors/Vector225_x2.svg" />
                  </div>
                </div>
              </div>
            </div>
            <div className="container-1">
              <div className="pg">
                <div className="fluent-emoji-high-contrastoffice-building">
                  <img className="vector-40" src="assets/vectors/Vector191_x2.svg" />
                </div>
                <div className="frame-1252">
                  <span className="pg-1">
                  PG
                  </span>
                  <div className="teenyiconsdown-solid-4">
                    <img className="vector-39" src="assets/vectors/Vector725_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="help">
                <div className="mingcuteservice-fill">
                  <img className="group-3" src="assets/vectors/Group1_x2.svg" />
                </div>
                <div className="frame-1251">
                  <span className="help-1">
                  Help
                  </span>
                  <div className="teenyiconsdown-solid-2">
                    <img className="vector-31" src="assets/vectors/Vector267_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="frame-212">
                <span className="sign-in">
                Sign in
                </span>
                <div className="mingcutedown-fill">
                  <img className="vector-14" src="assets/vectors/Vector206_x2.svg" />
                </div>
              </div>
            </div>
          </div>
          <div className="container-19">
            <div className="container-15">
              <div className="property-types">
                <span className="property-types-1">
                Property Types
                </span>
                <div className="teenyiconsdown-solid-9">
                  <img className="vector-103" src="assets/vectors/Vector498_x2.svg" />
                </div>
              </div>
              <div className="bhk">
                <span className="bhk-1">
                BHK
                </span>
                <div className="teenyiconsdown-solid-6">
                  <img className="vector-44" src="assets/vectors/Vector569_x2.svg" />
                </div>
              </div>
              <div className="budgettttttttttttt">
                <span className="budget">
                Budget
                </span>
                <div className="teenyiconsdown-solid-10">
                  <img className="vector-104" src="assets/vectors/Vector31_x2.svg" />
                </div>
              </div>
              <div className="posted-by">
                <span className="posted-by-1">
                Posted By
                </span>
                <div className="teenyiconsdown-solid-7">
                  <img className="vector-45" src="assets/vectors/Vector270_x2.svg" />
                </div>
              </div>
              <div className="component-34">
                <span className="filters">
                Filters
                </span>
                <div className="teenyiconsdown-solid-8">
                  <img className="vector-46" src="assets/vectors/Vector84_x2.svg" />
                </div>
              </div>
            </div>
            <div className="group-108">
              <div className="frame-227">
                <p className="find-ahome-away-fromhome">
                <span className="find-ahome-away-fromhome-sub-0"></span><span></span>
                </p>
              </div>
              <div className="group-94">
                <div className="container-10">
                  <div className="icbaseline-search">
                    <img className="vector-15" src="assets/vectors/Vector652_x2.svg" />
                  </div>
                  <span className="search">
                  Search
                  </span>
                </div>
                <div className="container-21">
                  <div className="rectangle-46">
                  </div>
                  <div className="weuilocation-outlined">
                    <img className="vector-16" src="assets/vectors/Vector145_x2.svg" />
                  </div>
                  <div className="anywhere-in-india">
                  Anywhere in India
                  </div>
                </div>
                <div className="container-6">
                  <div className="map">
                    <div className="fluentmy-location-20-filled">
                      <img className="vector-17" src="assets/vectors/Vector634_x2.svg" />
                    </div>
                  </div>
                  <div className="frame-126">
                    <span className="search-1">
                    Search
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="group-168">
            <div className="unnati-shree-rath-apartments">
              <div className="no-1">
                <div className="group-155">
                  <div className="image-3">
                  </div>
                  <div className="rectangle-124">
                  </div>
                  <div className="rectangle-281">
                  </div>
                  <div className="ellipse-4">
                  </div>
                  <div className="ellipse-5">
                  </div>
                </div>
              </div>
              <div className="container-7">
                <div className="container-2">
                  <div className="group-166">
                    <div className="unnati-shree-rath-apartments-2">
                    Unnati Shree Rath Apartments
                    </div>
                    <span className="nizampet-hyderabad">
                    Nizampet, Hyderabad
                    </span>
                  </div>
                  <div className="days-ago">
                  2 days ago<br />
                  
                  </div>
                </div>
                <div className="frame-221">
                  <div className="container-14">
                    <div className="frame-217">
                      <img className="group-164" src="assets/vectors/Group16419_x2.svg" />
                      <span className="beds">
                      4Beds
                      </span>
                    </div>
                    <div className="frame-218">
                      <img className="id-76-bdb-6-oht-rkv-v-28-elmb-db-xzx-1" src="assets/vectors/Id76Bdb6OhtRkvV28ElmbDbXzx114_x2.svg" />
                      <span className="baths">
                      3Baths
                      </span>
                    </div>
                    <div className="frame-219">
                      <div className="phcar-thin">
                        <img className="vector-67" src="assets/vectors/Vector179_x2.svg" />
                      </div>
                      <span className="covered-parking">
                      1 Covered Parking
                      </span>
                    </div>
                  </div>
                  <div className="frame-220">
                    <img className="id-eg-1-cr-1-iyh-0-n-8-o-1-wy-psxkl-5-ms-1" src="assets/vectors/IdEg1Cr1Iyh0N8O1WyPsxkl5Ms116_x2.svg" />
                    <span className="unfurnished">
                    Unfurnished
                    </span>
                  </div>
                </div>
                <div className="group-167">
                  <p className="transaction-type-new-property">
                  <span className="transaction-type-new-property-sub-7"></span><span></span>
                  </p>
                  <p className="status-ready-to-move">
                  <span className="status-ready-to-move-sub-5"></span><span></span>
                  </p>
                  <p className="super-area-2079-sqft">
                  <span className="super-area-2079-sqft-sub-5"></span><span></span>
                  </p>
                </div>
                <div className="container">
                  <div className="group-165">
                    <p className="cr">
                    <span className="cr-sub-1"></span><span></span>
                    </p>
                    <div className="rectangle-126">
                    </div>
                    <img className="iytsnctfi-5-e-8-sm-zs-pj-cy-3-erg-b-71" src="assets/vectors/Iytsnctfi5E8SmZsPjCy3ErgB7111_x2.svg" />
                    <div className="sqft">
                    2079 sqft
                    </div>
                  </div>
                  <div className="container-11">
                    <div className="frame-223">
                      <span className="share">
                      Share
                      </span>
                    </div>
                    <div className="frame-222">
                      <span className="contact">
                      Contact
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="unnati-shree-rath-apartments-1">
              <div className="no-11">
                <div className="group-1551">
                  <div className="image-31">
                  </div>
                  <div className="rectangle-1241">
                  </div>
                  <div className="rectangle-282">
                  </div>
                  <div className="ellipse-41">
                  </div>
                  <div className="ellipse-51">
                  </div>
                </div>
              </div>
              <div className="container-9">
                <div className="container-17">
                  <div className="group-1661">
                    <div className="unnati-shree-rath-apartments-3">
                    Unnati Shree Rath Apartments
                    </div>
                    <span className="nizampet-hyderabad-1">
                    Nizampet, Hyderabad
                    </span>
                  </div>
                  <div className="days-ago-1">
                  2 days ago<br />
                  
                  </div>
                </div>
                <div className="frame-2211">
                  <div className="container-12">
                    <div className="frame-2171">
                      <img className="group-1641" src="assets/vectors/Group1641_x2.svg" />
                      <span className="beds-1">
                      4Beds
                      </span>
                    </div>
                    <div className="frame-2181">
                      <img className="id-76-bdb-6-oht-rkv-v-28-elmb-db-xzx-11" src="assets/vectors/Id76Bdb6OhtRkvV28ElmbDbXzx19_x2.svg" />
                      <span className="baths-1">
                      3Baths
                      </span>
                    </div>
                    <div className="frame-2191">
                      <div className="phcar-thin-1">
                        <img className="vector-95" src="assets/vectors/Vector37_x2.svg" />
                      </div>
                      <span className="covered-parking-1">
                      1 Covered Parking
                      </span>
                    </div>
                  </div>
                  <div className="frame-2201">
                    <img className="id-eg-1-cr-1-iyh-0-n-8-o-1-wy-psxkl-5-ms-11" src="assets/vectors/IdEg1Cr1Iyh0N8O1WyPsxkl5Ms12_x2.svg" />
                    <span className="unfurnished-1">
                    Unfurnished
                    </span>
                  </div>
                </div>
                <div className="group-1671">
                  <p className="transaction-type-new-property-1">
                  <span className="transaction-type-new-property-1-sub-7"></span><span></span>
                  </p>
                  <p className="status-ready-to-move-1">
                  <span className="status-ready-to-move-1-sub-5"></span><span></span>
                  </p>
                  <p className="super-area-2079-sqft-1">
                  <span className="super-area-2079-sqft-1-sub-5"></span><span></span>
                  </p>
                </div>
                <div className="container-3">
                  <div className="group-1651">
                    <p className="cr-1">
                    <span className="cr-1-sub-1"></span><span></span>
                    </p>
                    <div className="rectangle-1261">
                    </div>
                    <img className="iytsnctfi-5-e-8-sm-zs-pj-cy-3-erg-b-711" src="assets/vectors/Iytsnctfi5E8SmZsPjCy3ErgB7120_x2.svg" />
                    <div className="sqft-1">
                    2079 sqft
                    </div>
                  </div>
                  <div className="container-5">
                    <div className="frame-2231">
                      <span className="share-1">
                      Share
                      </span>
                    </div>
                    <div className="frame-2221">
                      <span className="contact-1">
                      Contact
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="frame-31">
            <div className="download-the-mobile-app-now">
            Download the Mobile App Now
            </div>
            <div className="frame-30">
              <div className="frame-29">
                <div className="qr-code">
                  <img className="vector-11" src="assets/vectors/Vector198_x2.svg" />
                </div>
                <div className="image-260-nw-23151053071">
                </div>
              </div>
              <div className="frame-28">
                <div className="qr-code-1">
                  <img className="vector-13" src="assets/vectors/Vector451_x2.svg" />
                </div>
                <div className="image-260-nw-23151053072">
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-22">
          <div className="new-project">
          New project
          </div>
          <div className="group-901">
            <div className="rectangle-291">
            </div>
            <div className="rectangle-301">
            </div>
            <div className="rectangle-311">
            </div>
          </div>
        </div>
      </div>
      <div className="frame-27">
        <div className="container-8">
          <div className="frame-22">
            <div className="links">
            Links
            </div>
            <div className="frame-20">
              <div className="home-1">
              Home
              </div>
              <div className="about">
              About
              </div>
              <div className="service">
              Service
              </div>
              <span className="contact-us-1">
              Contact us
              </span>
            </div>
          </div>
          <div className="frame-21">
            <div className="info">
            Info
            </div>
            <div className="frame-201">
              <div className="terms-conditions">
              Terms &amp; Conditions
              </div>
              <div className="refund-policy">
              Refund policy
              </div>
              <span className="privacy-policy">
              Privacy policy
              </span>
            </div>
          </div>
          <div className="frame-19">
            <div className="address">
            Address
            </div>
            <div className="frame-18">
              <p className="registed-61105-saifabad-khairatabad-hyderabad-500004">
              <span className="registed-61105-saifabad-khairatabad-hyderabad-500004-sub-1"></span><span></span>
              </p>
              <p className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018">
              <span className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018-sub-2"></span><span></span>
              </p>
            </div>
          </div>
        </div>
        <div className="frame-26">
          <div className="frame-24">
            <div className="contact-no">
            Contact No
            </div>
            <div className="frame-23">
              <div className="container">
              +91 78936 53899
              </div>
              <span className="inforubia-services">
              info@rubia.services
              </span>
            </div>
          </div>
          <div className="frame-25">
            <div className="skill-iconstwitter">
              <img className="group" src="assets/vectors/Group28_x2.svg" />
            </div>
            <div className="akar-iconsfacebook-fill">
              <img className="vector-3" src="assets/vectors/Vector80_x2.svg" />
            </div>
            <div className="skill-iconslinkedin">
              <img className="group-1" src="assets/vectors/Group79_x2.svg" />
            </div>
            <div className="skill-iconsinstagram">
              <img className="group-2" src="assets/vectors/Group_x2.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
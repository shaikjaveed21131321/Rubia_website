import './Property1Frame1771.css'

export default function Property1Frame1771() {
  return (
    <div className="property-1-frame-177">
      <div className="ellipse-14">
      </div>
      <div className="frame-176">
        <span className="profile">
        Profile
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector623_x2.svg" />
        </div>
      </div>
    </div>
  )
}
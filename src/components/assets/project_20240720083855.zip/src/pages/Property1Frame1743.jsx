import './Property1Frame1743.css'

export default function Property1Frame1743() {
  return (
    <div className="property-1-frame-174">
      <span className="sign-in">
      Sign in
      </span>
      <div className="mingcutedown-fill">
        <img className="vector" src="assets/vectors/Vector110_x2.svg" />
      </div>
    </div>
  )
}
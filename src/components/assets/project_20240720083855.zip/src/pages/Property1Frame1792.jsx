import './Property1Frame1792.css'

export default function Property1Frame1792() {
  return (
    <div className="property-1-frame-179">
      <div className="rent">
        <img className="group-92" src="assets/vectors/Group9211_x2.svg" />
        <div className="frame-125">
          <span className="rent-1">
          Rent
          </span>
          <div className="teenyiconsdown-solid">
            <img className="vector-2" src="assets/vectors/Vector618_x2.svg" />
          </div>
        </div>
      </div>
      <div className="group-118">
        <div className="container-2">
          <div className="frame-176">
            <span className="residential">
            Residential
            </span>
          </div>
          <div className="frame-177">
            <span className="commercial">
            Commercial
            </span>
          </div>
        </div>
        <div className="container-3">
          <div className="flates">
            <span className="flates-1">
            Independent House for Rent
            </span>
          </div>
          <div className="under-50-lac-1">
            <span className="under-50-lac-2">
            Independent House  for Rent
            </span>
          </div>
        </div>
        <div className="container-4">
          <div className="house">
            <span className="house-1">
            duplex house for Rent 
            </span>
          </div>
          <div className="cr-15-cr-1">
            <span className="cr-15-cr-2">
            Duplex house for Rent 
            </span>
          </div>
        </div>
        <div className="container-1">
          <div className="plots">
            <span className="plots-1">
            Triplex house for Rent
            </span>
          </div>
          <div className="under-50-lac">
            <span className="lac-1-cr">
            Triplex house  for Rent
            </span>
          </div>
        </div>
        <div className="container">
          <div className="villas">
            <span className="villas-1">
            Independent flates for Rent
            </span>
          </div>
          <div className="cr-15-cr">
            <span className="above-15-cr">
            Open plots
            </span>
          </div>
        </div>
        <div className="office-space">
          <span className="office-space-2">
          duplex flates for Rent
          </span>
        </div>
        <div className="office-space-1">
          <span className="office-space-3">
          Triplex flates for Rent
          </span>
        </div>
      </div>
    </div>
  )
}
import './Frame123.css'

export default function Frame123() {
  return (
    <div className="frame-123">
      <div className="mdipeople-add">
        <img className="vector" src="assets/vectors/Vector146_x2.svg" />
      </div>
      <span className="my-network">
      My Network
      </span>
    </div>
  )
}
import './PopUpSignIn3.css'

export default function PopUpSignIn3() {
  return (
    <div className="pop-up-sign-in">
      <div className="profile-details">
      Profile Details
      </div>
      <div className="frame-225">
        <div className="name">
        Name
        </div>
        <div className="frame-11">
          <span className="bsamprassingh">
          B.samprassingh
          </span>
        </div>
      </div>
      <div className="frame-187">
        <div className="mobile-number">
        Mobile Number
        </div>
        <div className="frame-1">
          <img className="emojione-v-1-flag-for-india" src="assets/vectors/EmojioneV1FlagForIndia_x2.svg" />
          <div className="container">
          +91
          </div>
          <div className="container-1">
          8309881421
          </div>
        </div>
      </div>
      <div className="frame-188">
        <div className="email-id">
        Email id
        </div>
        <div className="frame-12">
          <span className="banothsamprassinghgmail-com">
          banothsamprassingh@gmail.com
          </span>
        </div>
      </div>
      <div className="frame-226">
        <div className="registered-as">
        Registered As
        </div>
        <div className="frame-13">
          <span className="agent">
          Agent
          </span>
        </div>
      </div>
      <div className="frame-178">
        <span className="edit-profile">
        Edit profile
        </span>
      </div>
    </div>
  )
}
import './Property1Frame123.css'

export default function Property1Frame123() {
  return (
    <div className="property-1-frame-123">
      <span className="sign-in">
      Sign in
      </span>
    </div>
  )
}
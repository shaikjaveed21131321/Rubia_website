import './Property1Default26.css'

export default function Property1Default26() {
  return (
    <div className="property-1-default">
      <img className="mask-group" src="assets/vectors/MaskGroup40_x2.svg" />
      <div className="moter-cycle">
        <span className="motor-cycles">
        Motor cycles
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector458_x2.svg" />
        </div>
      </div>
    </div>
  )
}
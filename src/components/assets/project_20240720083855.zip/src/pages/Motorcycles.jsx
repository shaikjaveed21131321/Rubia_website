import './Motorcycles.css'

export default function Motorcycles() {
  return (
    <div className="motorcycles">
      <img className="mask-group" src="assets/vectors/MaskGroup29_x2.svg" />
      <div className="moter-cycle">
        <span className="motorcycles-1">
        Motor cycles
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector4_x2.svg" />
        </div>
      </div>
    </div>
  )
}
import './Property1Frame1251.css'

export default function Property1Frame1251() {
  return (
    <div className="property-1-frame-125">
      <div className="lets-iconsmessage-fill">
        <img className="vector" src="assets/vectors/Vector460_x2.svg" />
      </div>
      <span className="messages">
      Messages
      </span>
    </div>
  )
}
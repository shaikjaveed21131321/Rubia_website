import './Property1Group991.css'

export default function Property1Group991() {
  return (
    <div className="property-1-group-99">
      <div className="container">
        <div className="group-95">
          <div className="rectangle-50">
          </div>
          <span className="hiring">
          #Hiring
          </span>
        </div>
        <div className="container-2">
          <div className="sampras-singh">
          Sampras singh
          </div>
          <div className="rubia-services-recruiter">
          Rubia.services Recruiter
          </div>
          <p className="remote-internship-alertrubia-services-read-more">
          <span className="remote-internship-alertrubia-services-read-more-sub-0"></span><span></span>
          </p>
        </div>
      </div>
      <div className="container-1">
        <div className="hr-ago">
        1hr ago
        </div>
        <div className="frame-127">
          <span className="follow">
          Follow
          </span>
        </div>
      </div>
    </div>
  )
}
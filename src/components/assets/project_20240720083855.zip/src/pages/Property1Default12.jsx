import './Property1Default12.css'

export default function Property1Default12() {
  return (
    <div className="property-1-default">
      <img className="group-93" src="assets/vectors/Group935_x2.svg" />
      <div className="frame-125">
        <span className="sell">
        Sell
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-6" src="assets/vectors/Vector704_x2.svg" />
        </div>
      </div>
    </div>
  )
}
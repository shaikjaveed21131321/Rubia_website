import './Property1Group145.css'

export default function Property1Group145() {
  return (
    <div className="property-1-group-145">
      <div className="ellipse-21">
      </div>
    </div>
  )
}
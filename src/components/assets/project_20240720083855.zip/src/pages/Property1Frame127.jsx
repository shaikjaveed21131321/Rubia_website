import './Property1Frame127.css'

export default function Property1Frame127() {
  return (
    <div className="property-1-frame-127">
      <img className="group-92" src="assets/vectors/Group927_x2.svg" />
      <div className="frame-125">
        <span className="rent">
        Rent
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-2" src="assets/vectors/Vector571_x2.svg" />
        </div>
      </div>
    </div>
  )
}
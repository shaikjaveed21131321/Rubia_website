import './Property1Component182.css'

export default function Property1Component182() {
  return (
    <div className="property-1-component-18">
      <div className="rectangle-72">
      </div>
      <span className="music">
      music
      </span>
    </div>
  )
}
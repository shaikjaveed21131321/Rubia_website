import './InstagramPost5.css'

export default function InstagramPost5() {
  return (
    <div className="instagram-post-5">
      <div className="rectangle-81">
      </div>
      <div className="container-1">
        <div className="image-46">
        </div>
        <div className="rectangle-841">
        </div>
        <div className="container-3">
          <div className="rectangle-84">
          </div>
          <div className="container">
            <div className="get-your-power-nap">
            Get Your<br />
            Power nap
            </div>
            <div className="reasons-to-book-rubia-drivers">
            Reasons to Book Rubia drivers
            </div>
            <div className="container-2">
              <div className="rubia-services">
              Rubia.services
              </div>
              <div className="qr-code">
                <img className="vector-1" src="assets/vectors/Vector23_x2.svg" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
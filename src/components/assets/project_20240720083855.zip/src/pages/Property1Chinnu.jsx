import './Property1Chinnu.css'

export default function Property1Chinnu() {
  return (
    <div className="property-1-chinnu">
      <img className="group-91" src="assets/vectors/Group918_x2.svg" />
      <div className="frame-124">
        <span className="buy">
        Buy
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-6" src="assets/vectors/Vector708_x2.svg" />
        </div>
      </div>
    </div>
  )
}
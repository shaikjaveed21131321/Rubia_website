import './Property1Frame1803.css'

export default function Property1Frame1803() {
  return (
    <div className="property-1-frame-180">
      <span className="job-type">
      Job type
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector417_x2.svg" />
      </div>
    </div>
  )
}
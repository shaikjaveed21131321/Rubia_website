import './Property1Frame1845.css'

export default function Property1Frame1845() {
  return (
    <div className="property-1-frame-184">
      <div className="frame-183">
        <span className="with-in-25-kilometers">
        With in 25 kilometers
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector709_x2.svg" />
        </div>
      </div>
      <div className="group-114">
        <div className="late-24-hours">
          <span className="last-24-hours">
          With in 25 kilometers
          </span>
        </div>
        <div className="late-03-days">
          <span className="last-03-days">
          With in 40 kilometers
          </span>
        </div>
        <div className="late-07-days">
          <span className="last-07-days">
          With in 50 kilometers
          </span>
        </div>
        <div className="since-you-last-visit">
          <span className="since-you-last-visit-1">
          With in 100 kilometers
          </span>
        </div>
      </div>
    </div>
  )
}
import './InstagramPost6.css'

export default function InstagramPost6() {
  return (
    <div className="instagram-post-6">
      <div className="image-12">
      </div>
      <div className="container-2">
        <div className="container">
          <div className="container-1">
            <div className="group-2">
              <img className="mask-group" src="assets/vectors/MaskGroup10_x2.svg" />
            </div>
            <div className="happy-international-yoga-day">
            Happy<br />
            International yoga<br />
            Day
            </div>
          </div>
          <div className="image-6">
          </div>
        </div>
        <img className="mask-group-1" src="assets/vectors/MaskGroup77_x2.svg" />
      </div>
      <div className="image-1">
      </div>
    </div>
  )
}
import './Frame177.css'

export default function Frame177() {
  return (
    <div className="frame-177">
      <span className="save">
      Save
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector615_x2.svg" />
      </div>
    </div>
  )
}
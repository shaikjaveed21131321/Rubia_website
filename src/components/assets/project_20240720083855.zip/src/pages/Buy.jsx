import './Buy.css'

export default function Buy() {
  return (
    <div className="buy">
      <div className="office-space">
        <div className="property-1-frame-1764">
          <span className="office-space-1">
          Office space
          </span>
        </div>
        <div className="property-1-frame-1814">
          <span className="office-space-2">
          Office space
          </span>
        </div>
      </div>
      <div className="container">
        <div className="plots">
          <div className="property-1-frame-1763">
            <span className="plots-1">
            Plots
            </span>
          </div>
          <div className="property-1-frame-1813">
            <span className="plots-2">
            Plots
            </span>
          </div>
        </div>
        <div className="flates-2">
          <div className="property-1-frame-176">
            <span className="flates">
            Flates
            </span>
          </div>
          <div className="property-1-frame-181">
            <span className="flates-1">
            Flates
            </span>
          </div>
        </div>
      </div>
      <div className="container-1">
        <div className="villas">
          <div className="property-1-frame-1762">
            <span className="villas-1">
            Villa’s
            </span>
          </div>
          <div className="property-1-frame-1812">
            <span className="villas-2">
            Villa’s
            </span>
          </div>
        </div>
        <div className="house">
          <div className="property-1-frame-1761">
            <span className="house-1">
            House
            </span>
          </div>
          <div className="property-1-frame-1811">
            <span className="house-2">
            House
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
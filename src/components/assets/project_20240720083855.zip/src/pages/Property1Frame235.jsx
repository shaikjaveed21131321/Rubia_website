import './Property1Frame235.css'

export default function Property1Frame235() {
  return (
    <div className="property-1-frame-235">
      <div className="subwaybox-1">
        <img className="vector-1" src="assets/vectors/Vector671_x2.svg" />
      </div>
      <span className="posts">
      Posts
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector680_x2.svg" />
      </div>
    </div>
  )
}
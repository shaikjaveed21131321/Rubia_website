import './Property1Default27.css'

export default function Property1Default27() {
  return (
    <div className="property-1-default">
      <img className="mask-group" src="assets/vectors/MaskGroup60_x2.svg" />
      <div className="moter-cycle">
        <span className="motorcycles">
        Motorcycles
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector34_x2.svg" />
        </div>
      </div>
    </div>
  )
}
import './Property1Default32.css'

export default function Property1Default32() {
  return (
    <div className="property-1-default">
      <div className="healthiconshome-outline">
        <img className="group" src="assets/vectors/Group87_x2.svg" />
      </div>
      <div className="moter-cycle">
        <span className="kitchen-appliances">
        Kitchen Appliances
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-2" src="assets/vectors/Vector262_x2.svg" />
        </div>
      </div>
    </div>
  )
}
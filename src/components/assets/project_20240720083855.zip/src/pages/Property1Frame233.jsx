import './Property1Frame233.css'

export default function Property1Frame233() {
  return (
    <div className="property-1-frame-233">
      <div className="subwaybox-1">
        <img className="vector-1" src="assets/vectors/Vector153_x2.svg" />
      </div>
      <span className="posts">
      Posts
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector67_x2.svg" />
      </div>
    </div>
  )
}
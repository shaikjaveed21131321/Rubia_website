import './Property1Company.css'

export default function Property1Company() {
  return (
    <div className="property-1-company">
      <span className="company">
      ‘Company’
      </span>
    </div>
  )
}
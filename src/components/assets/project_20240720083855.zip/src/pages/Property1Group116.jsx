import './Property1Group116.css'

export default function Property1Group116() {
  return (
    <div className="property-1-group-116">
      <div className="rectangle-72">
      </div>
      <span className="yoga-day">
      Yoga Day
      </span>
    </div>
  )
}
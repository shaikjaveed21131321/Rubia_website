import './Frame213.css'

export default function Frame213() {
  return (
    <div className="frame-213">
      <span className="property-types">
      Property Types
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector213_x2.svg" />
      </div>
    </div>
  )
}
import './SignIn.css'

export default function SignIn() {
  return (
    <div className="sign-in">
      <span className="sign-in-1">
      Sign in
      </span>
      <div className="mingcutedown-fill">
        <img className="vector" src="assets/vectors/Vector56_x2.svg" />
      </div>
    </div>
  )
}
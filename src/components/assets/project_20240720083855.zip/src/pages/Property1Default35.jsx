import './Property1Default35.css'

export default function Property1Default35() {
  return (
    <div className="property-1-default">
      <div className="giscar">
        <img className="vector" src="assets/vectors/Vector287_x2.svg" />
      </div>
      <div className="frame-134">
        <span className="cars">
        Cars
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-1" src="assets/vectors/Vector162_x2.svg" />
        </div>
      </div>
    </div>
  )
}
import './Property1Frame2336.css'

export default function Property1Frame2336() {
  return (
    <div className="property-1-frame-233">
      <div className="fluent-mdl-2-group">
        <img className="vector" src="assets/vectors/Vector543_x2.svg" />
      </div>
      <span className="groups">
      Groups
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector-1" src="assets/vectors/Vector8_x2.svg" />
      </div>
    </div>
  )
}
import './Group1201.css'

export default function Group1201() {
  return (
    <div className="group-120">
      <span className="property-types">
      Property Types
      </span>
    </div>
  )
}
import './Property1Frame1764.css'

export default function Property1Frame1764() {
  return (
    <div className="property-1-frame-176">
      <span className="on-site">
      On site
      </span>
    </div>
  )
}
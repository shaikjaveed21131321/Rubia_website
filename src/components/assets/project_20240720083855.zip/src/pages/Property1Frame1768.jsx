import './Property1Frame1768.css'

export default function Property1Frame1768() {
  return (
    <div className="property-1-frame-176">
      <span className="independent-house">
      Independent House
      </span>
    </div>
  )
}
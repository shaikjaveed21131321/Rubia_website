import './Property1Frame2151.css'

export default function Property1Frame2151() {
  return (
    <div className="property-1-frame-215">
      <div className="group-135">
        <span className="budget">
        Budget
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector228_x2.svg" />
        </div>
      </div>
      <div className="group-141">
        <div className="budget-1">
        Budget
        </div>
        <div className="container-1">
          <div className="group-136">
            <span className="min">
            Min
            </span>
            <div className="group">
              <img className="vector-1" src="assets/vectors/Vector29_x2.svg" />
            </div>
          </div>
          <div className="group-137">
            <span className="max">
            Max
            </span>
            <div className="group-1">
              <img className="vector-2" src="assets/vectors/Vector537_x2.svg" />
            </div>
          </div>
        </div>
        <div className="container">
          <div className="group-139">
            <span className="container">
            0
            </span>
          </div>
          <div className="group-138">
            <span className="cr">
            ₹ 5cr
            </span>
          </div>
        </div>
        <img className="group-140" src="assets/vectors/Group1406_x2.svg" />
        <div className="done">
          <span className="done-1">
          Done
          </span>
        </div>
      </div>
    </div>
  )
}
import './Property1Group126.css'

export default function Property1Group126() {
  return (
    <div className="property-1-group-126">
      <span className="bhk">
      BHK
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector519_x2.svg" />
      </div>
    </div>
  )
}
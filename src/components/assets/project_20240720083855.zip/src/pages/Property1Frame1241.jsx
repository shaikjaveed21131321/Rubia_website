import './Property1Frame1241.css'

export default function Property1Frame1241() {
  return (
    <div className="property-1-frame-124">
      <div className="basilbag-solid">
        <img className="vector" src="assets/vectors/Vector590_x2.svg" />
        <img className="vector-1" src="assets/vectors/Vector376_x2.svg" />
      </div>
      <span className="jobs">
      Jobs
      </span>
    </div>
  )
}
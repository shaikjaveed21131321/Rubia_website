import './Property1Default18.css'

export default function Property1Default18() {
  return (
    <div className="property-1-default">
      <img className="group-116" src="assets/vectors/Group116_x2.svg" />
      <div className="frame-125">
        <span className="plots-pg">
        Plots/PG
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector143_x2.svg" />
        </div>
      </div>
    </div>
  )
}
import './Property1Frame1765.css'

export default function Property1Frame1765() {
  return (
    <div className="property-1-frame-176">
      <span className="hybrid-work">
      Hybrid Work
      </span>
    </div>
  )
}
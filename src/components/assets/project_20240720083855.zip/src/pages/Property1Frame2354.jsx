import './Property1Frame2354.css'

export default function Property1Frame2354() {
  return (
    <div className="property-1-frame-235">
      <div className="fluentpeople-16-regular">
        <img className="vector-1" src="assets/vectors/Vector2_x2.svg" />
      </div>
      <span className="followers">
      Followers
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector35_x2.svg" />
      </div>
    </div>
  )
}
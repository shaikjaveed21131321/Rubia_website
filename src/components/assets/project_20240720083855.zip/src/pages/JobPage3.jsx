import './JobPage3.css'

export default function JobPage3() {
  return (
    <div className="job-page">
      <div className="container-14">
        <div className="group-101">
        </div>
        <div className="frame-4">
          <span className="home">
          HOME
          </span>
          <span className="services">
          SERVICES
          </span>
          <span className="about-us">
          ABOUT US
          </span>
          <span className="contact-us">
          CONTACT US
          </span>
          <span className="blog">
          BLOG
          </span>
        </div>
      </div>
      <div className="container">
        <div className="group-89">
          <div className="frame-12">
            <span className="we-provide">
            We Provide
            </span>
          </div>
          <div className="frame-3">
            <span className="drivers">
            DRIVERS
            </span>
          </div>
          <div className="frame-7">
            <span className="graphic-designing">
            GRAPHIC DESIGNING
            </span>
          </div>
          <div className="frame-6">
            <span className="software">
            SOFTWARE
            </span>
          </div>
          <div className="frame-8">
            <span className="digital-marketing">
            DIGITAL MARKETING
            </span>
          </div>
          <div className="frame-15">
            <span className="ux-ui-designing">
            UX/UI Designing
            </span>
          </div>
          <div className="frame-114">
            <span className="taxi">
            TAXI
            </span>
          </div>
          <div className="frame-115">
            <span className="job-portal">
            JOB PORTAL
            </span>
          </div>
          <div className="frame-116">
            <span className="real-estate">
            REAL ESTATE
            </span>
          </div>
        </div>
        <div className="container-5">
          <div className="container-8">
            <div className="frame-123">
              <div className="heroiconshome-solid">
                <img className="group-3" src="assets/vectors/Group37_x2.svg" />
              </div>
              <span className="home-2">
              Home
              </span>
            </div>
            <div className="component-5">
              <div className="icbaseline-search">
                <img className="vector-23" src="assets/vectors/Vector662_x2.svg" />
              </div>
              <span className="search">
              Search
              </span>
            </div>
            <div className="component-2">
              <div className="basilbag-solid">
                <img className="vector-26" src="assets/vectors/Vector575_x2.svg" />
                <img className="vector-27" src="assets/vectors/Vector305_x2.svg" />
              </div>
              <span className="jobs">
              Jobs
              </span>
            </div>
            <div className="component-6">
              <div className="mdipeople-add">
                <img className="vector-24" src="assets/vectors/Vector741_x2.svg" />
              </div>
              <span className="my-network">
              My Network
              </span>
            </div>
            <div className="component-4">
              <div className="lets-iconsmessage-fill">
                <img className="vector-25" src="assets/vectors/Vector696_x2.svg" />
              </div>
              <span className="messages">
              Messages
              </span>
            </div>
            <div className="profile">
              <div className="ellipse-143">
              </div>
              <div className="frame-176">
                <span className="profile-1">
                Profile
                </span>
                <div className="teenyiconsdown-solid">
                  <img className="vector-28" src="assets/vectors/Vector16_x2.svg" />
                </div>
              </div>
            </div>
          </div>
          <div className="container-4">
            <div className="container-12">
              <div className="container-6">
                <div className="ui-ux-designer">
                UI/UX Designer
                </div>
                <img className="group-16" src="assets/vectors/Group161_x2.svg" />
              </div>
              <div className="container-1">
                <div className="frame-232">
                  <div className="sampras-singh">
                  Sampras singh
                  </div>
                  <span className="ui-ux-designer-1">
                  UI/UX Designer
                  </span>
                </div>
                <div className="frame-233">
                  <div className="frame-229">
                    <div className="container-1">
                    24
                    </div>
                    <span className="post">
                    Post
                    </span>
                  </div>
                  <div className="frame-230">
                    <div className="container-2">
                    124
                    </div>
                    <span className="followers">
                    Followers
                    </span>
                  </div>
                  <div className="frame-231">
                    <div className="container-3">
                    84
                    </div>
                    <span className="following">
                    Following
                    </span>
                  </div>
                </div>
              </div>
              <div className="container-3">
                <div className="container-2">
                  <div className="post-1">
                    <div className="subwaybox-1">
                      <img className="vector-36" src="assets/vectors/Vector437_x2.svg" />
                    </div>
                    <span className="posts">
                    Posts
                    </span>
                    <div className="teenyiconsdown-solid-4">
                      <img className="vector-35" src="assets/vectors/Vector540_x2.svg" />
                    </div>
                  </div>
                  <div className="saved">
                    <img className="rectangle-62" src="assets/vectors/Rectangle626_x2.svg" />
                    <span className="saved-3">
                    Saved
                    </span>
                    <div className="teenyiconsdown-solid-1">
                      <img className="vector-29" src="assets/vectors/Vector637_x2.svg" />
                    </div>
                  </div>
                </div>
                <div className="saved-1">
                  <div className="material-symbolspost-add">
                    <img className="vector-31" src="assets/vectors/Vector715_x2.svg" />
                  </div>
                  <span className="create-apost">
                  Create a post
                  </span>
                  <div className="teenyiconsdown-solid-2">
                    <img className="vector-30" src="assets/vectors/Vector591_x2.svg" />
                  </div>
                </div>
                <div className="saved-2">
                  <div className="hugeiconsjob-search">
                    <img className="group-4" src="assets/vectors/Group64_x2.svg" />
                  </div>
                  <span className="applied-jobs">
                  Applied Jobs
                  </span>
                  <div className="teenyiconsdown-solid-3">
                    <img className="vector-32" src="assets/vectors/Vector321_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="container-7">
                <div className="yoga">
                  <div className="rectangle-725">
                  </div>
                  <span className="yoga-day">
                  Yoga Day
                  </span>
                </div>
                <div className="case-study">
                  <div className="rectangle-72">
                  </div>
                  <span className="case-study-1">
                  Case study
                  </span>
                </div>
                <div className="music-2">
                  <div className="rectangle-723">
                  </div>
                  <span className="game-app">
                  Game app
                  </span>
                </div>
              </div>
              <div className="container-11">
                <div className="music-3">
                  <div className="rectangle-724">
                  </div>
                  <span className="sanchari">
                  Sanchari
                  </span>
                </div>
                <div className="music-1">
                  <div className="rectangle-722">
                  </div>
                  <span className="music-5">
                  Music
                  </span>
                </div>
                <div className="music">
                  <div className="rectangle-721">
                  </div>
                  <span className="music-4">
                  Music
                  </span>
                </div>
              </div>
              <div className="group-118">
                <div className="group-117">
                  <span className="experience">
                  Experience
                  </span>
                  <div className="container-9">
                    <img className="ouiml-create-single-metric-job" src="assets/vectors/OuimlCreateSingleMetricJob_x2.svg" />
                    <img className="group-161" src="assets/vectors/Group16_x2.svg" />
                  </div>
                </div>
                <div className="group-116">
                  <div className="frame-203">
                    <div className="image-1">
                    </div>
                    <div className="frame-202">
                      <div className="rubia-services">
                      Rubia.services
                      </div>
                      <span className="hyderabad-erragadda">
                      Hyderabad, Erragadda 
                      </span>
                    </div>
                  </div>
                  <div className="ellipse-17">
                  </div>
                  <div className="line-1">
                  </div>
                  <div className="frame-234">
                    <div className="image-11">
                    </div>
                    <div className="frame-2021">
                      <div className="newgen-services">
                      Newgen.services
                      </div>
                      <span className="hyderabad-kphb">
                      Hyderabad, KPHB 
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="group-1171">
                <span className="resume">
                Resume
                </span>
                <div className="container-10">
                  <img className="ouiml-create-single-metric-job-1" src="assets/vectors/OuimlCreateSingleMetricJob1_x2.svg" />
                  <img className="group-162" src="assets/vectors/Group162_x2.svg" />
                </div>
              </div>
              <div className="rectangle-81">
              </div>
            </div>
            <div className="group-115">
              <div className="ellipse-16">
              </div>
            </div>
          </div>
        </div>
        <div className="group-90">
          <div className="rectangle-29">
          </div>
          <div className="rectangle-30">
          </div>
          <div className="rectangle-31">
          </div>
          <div className="rectangle-32">
          </div>
        </div>
      </div>
      <div className="frame-31">
        <div className="download-the-mobile-app-now">
        Download the Mobile App Now
        </div>
        <div className="frame-30">
          <div className="frame-29">
            <div className="qr-code">
              <img className="vector-11" src="assets/vectors/Vector86_x2.svg" />
            </div>
            <div className="image-260-nw-23151053071">
            </div>
          </div>
          <div className="frame-28">
            <div className="qr-code-1">
              <img className="vector-13" src="assets/vectors/Vector90_x2.svg" />
            </div>
            <div className="image-260-nw-23151053072">
            </div>
          </div>
        </div>
      </div>
      <div className="frame-27">
        <div className="container-13">
          <div className="frame-22">
            <div className="links">
            Links
            </div>
            <div className="frame-20">
              <div className="home-1">
              Home
              </div>
              <div className="about">
              About
              </div>
              <div className="service">
              Service
              </div>
              <span className="contact-us-1">
              Contact us
              </span>
            </div>
          </div>
          <div className="frame-21">
            <div className="info">
            Info
            </div>
            <div className="frame-201">
              <div className="terms-conditions">
              Terms &amp; Conditions
              </div>
              <div className="refund-policy">
              Refund policy
              </div>
              <span className="privacy-policy">
              Privacy policy
              </span>
            </div>
          </div>
          <div className="frame-19">
            <div className="address">
            Address
            </div>
            <div className="frame-18">
              <p className="registed-61105-saifabad-khairatabad-hyderabad-500004">
              <span className="registed-61105-saifabad-khairatabad-hyderabad-500004-sub-1"></span><span></span>
              </p>
              <p className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018">
              <span className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018-sub-2"></span><span></span>
              </p>
            </div>
          </div>
        </div>
        <div className="frame-26">
          <div className="frame-24">
            <div className="contact-no">
            Contact No
            </div>
            <div className="frame-23">
              <div className="container">
              +91 78936 53899
              </div>
              <span className="inforubia-services">
              info@rubia.services
              </span>
            </div>
          </div>
          <div className="frame-25">
            <div className="skill-iconstwitter">
              <img className="group" src="assets/vectors/Group71_x2.svg" />
            </div>
            <div className="akar-iconsfacebook-fill">
              <img className="vector-3" src="assets/vectors/Vector282_x2.svg" />
            </div>
            <div className="skill-iconslinkedin">
              <img className="group-1" src="assets/vectors/Group55_x2.svg" />
            </div>
            <div className="skill-iconsinstagram">
              <img className="group-2" src="assets/vectors/Group21_x2.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
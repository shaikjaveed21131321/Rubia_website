import './Property1Frame124.css'

export default function Property1Frame124() {
  return (
    <div className="property-1-frame-124">
      <span className="sign-in">
      Sign in
      </span>
    </div>
  )
}
import './Property1Frame1385.css'

export default function Property1Frame1385() {
  return (
    <div className="property-1-frame-138">
      <span className="ev-scooters">
      EV Scooters
      </span>
    </div>
  )
}
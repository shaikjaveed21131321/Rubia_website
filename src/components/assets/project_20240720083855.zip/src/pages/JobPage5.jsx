import './JobPage5.css'

export default function JobPage5() {
  return (
    <div className="job-page">
      <div className="container-7">
        <div className="group-101">
        </div>
        <div className="frame-4">
          <span className="home-1">
          HOME
          </span>
          <span className="services">
          SERVICES
          </span>
          <span className="about-us">
          ABOUT US
          </span>
          <span className="contact-us">
          CONTACT US
          </span>
          <span className="blog">
          BLOG
          </span>
        </div>
      </div>
      <div className="container-11">
        <div className="group-89">
          <div className="frame-12">
            <span className="we-provide">
            We Provide
            </span>
          </div>
          <div className="frame-3">
            <span className="drivers">
            DRIVERS
            </span>
          </div>
          <div className="frame-7">
            <span className="graphic-designing">
            GRAPHIC DESIGNING
            </span>
          </div>
          <div className="frame-6">
            <span className="software">
            SOFTWARE
            </span>
          </div>
          <div className="frame-8">
            <span className="digital-marketing">
            DIGITAL MARKETING
            </span>
          </div>
          <div className="frame-15">
            <span className="ux-ui-designing">
            UX/UI Designing
            </span>
          </div>
          <div className="frame-114">
            <span className="taxi">
            TAXI
            </span>
          </div>
          <div className="frame-115">
            <span className="job-portal">
            JOB PORTAL
            </span>
          </div>
          <div className="frame-116">
            <span className="real-estate">
            REAL ESTATE
            </span>
          </div>
        </div>
        <div className="container-4">
          <div className="container-6">
            <div className="frame-123">
              <div className="heroiconshome-solid">
                <img className="group" src="assets/vectors/Group82_x2.svg" />
              </div>
              <span className="home">
              Home
              </span>
            </div>
            <div className="component-5">
              <div className="icbaseline-search-1">
                <img className="vector-18" src="assets/vectors/Vector343_x2.svg" />
              </div>
              <span className="search-1">
              Search
              </span>
            </div>
            <div className="container-10">
              <div className="component-2">
                <div className="basilbag-solid">
                  <img className="vector-21" src="assets/vectors/Vector324_x2.svg" />
                  <img className="vector-22" src="assets/vectors/Vector509_x2.svg" />
                </div>
                <span className="jobs">
                Jobs
                </span>
              </div>
              <div className="component-6">
                <div className="mdipeople-add">
                  <img className="vector-19" src="assets/vectors/Vector11_x2.svg" />
                </div>
                <span className="my-network">
                My Network
                </span>
              </div>
            </div>
            <div className="component-4">
              <div className="lets-iconsmessage-fill">
                <img className="vector-20" src="assets/vectors/Vector105_x2.svg" />
              </div>
              <span className="messages">
              Messages
              </span>
            </div>
            <div className="profile">
              <div className="ellipse-144">
              </div>
              <div className="frame-176">
                <span className="profile-1">
                Profile
                </span>
                <div className="teenyiconsdown-solid">
                  <img className="vector-23" src="assets/vectors/Vector580_x2.svg" />
                </div>
              </div>
            </div>
          </div>
          <div className="group-119">
            <div className="icbaseline-search">
              <img className="vector-16" src="assets/vectors/Vector482_x2.svg" />
            </div>
            <span className="search">
            Search
            </span>
            <div className="material-symbolsmic">
              <img className="vector-17" src="assets/vectors/Vector544_x2.svg" />
            </div>
          </div>
          <div className="container-9">
            <div className="followers-2">
              <div className="fluentpeople-16-regular">
                <img className="vector-29" src="assets/vectors/Vector348_x2.svg" />
              </div>
              <span className="followers-4">
              Followers
              </span>
              <div className="teenyiconsdown-solid-3">
                <img className="vector-28" src="assets/vectors/Vector55_x2.svg" />
              </div>
            </div>
            <div className="container-2">
              <div className="followers-1">
                <div className="simple-line-iconsuser-following">
                  <img className="vector-26" src="assets/vectors/Vector605_x2.svg" />
                </div>
                <span className="following">
                Following
                </span>
                <div className="teenyiconsdown-solid-2">
                  <img className="vector-27" src="assets/vectors/Vector404_x2.svg" />
                </div>
              </div>
              <div className="followers">
                <div className="fluent-mdl-2-group">
                  <img className="vector-24" src="assets/vectors/Vector636_x2.svg" />
                </div>
                <span className="groups">
                Groups
                </span>
                <div className="teenyiconsdown-solid-1">
                  <img className="vector-25" src="assets/vectors/Vector576_x2.svg" />
                </div>
              </div>
              <div className="followers-3">
                <span className="container-1">
                #
                </span>
                <div className="hashtags">
                Hashtags
                </div>
                <div className="teenyiconsdown-solid-4">
                  <img className="vector-30" src="assets/vectors/Vector49_x2.svg" />
                </div>
              </div>
            </div>
          </div>
          <div className="container-12">
            <div className="group-122">
              <div className="container-3">
                <div className="rectangle-80">
                </div>
                <div className="frame-238">
                  <div className="sampras-singh">
                  Sampras singh
                  </div>
                  <span className="junior-ui-ux-designer">
                  Junior UI/UX Designer
                  </span>
                </div>
                <div className="frame-239">
                  <div className="ellipse-14">
                  </div>
                  <span className="nagendra-and-5-other-mutual-connections">
                  Nagendra and 5 other<br />
                  mutual connections
                  </span>
                </div>
                <div className="frame-240">
                  <span className="follow-back">
                  Follow back
                  </span>
                </div>
              </div>
              <div className="ellipse-18">
              </div>
            </div>
            <div className="group-123">
              <div className="container-13">
                <div className="rectangle-801">
                </div>
                <div className="frame-2381">
                  <div className="rishabh-pant">
                  Rishabh pant
                  </div>
                  <span className="junior-ui-ux-designer-1">
                  Junior UI/UX Designer
                  </span>
                </div>
                <div className="frame-2391">
                  <div className="ellipse-141">
                  </div>
                  <span className="nagendra-and-5-other-mutual-connections-1">
                  Nagendra and 5 other<br />
                  mutual connections
                  </span>
                </div>
                <div className="frame-2401">
                  <span className="follow-back-1">
                  Follow back
                  </span>
                </div>
              </div>
              <div className="ellipse-181">
              </div>
            </div>
          </div>
        </div>
        <div className="group-90">
          <div className="rectangle-29">
          </div>
          <div className="rectangle-30">
          </div>
          <div className="rectangle-31">
          </div>
          <div className="rectangle-32">
          </div>
        </div>
      </div>
      <div className="container-8">
        <div className="group-124">
          <div className="container-1">
            <div className="rectangle-802">
            </div>
            <div className="frame-2382">
              <div className="shruthi">
              Shruthi
              </div>
              <span className="junior-ui-ux-designer-2">
              Junior UI/UX Designer
              </span>
            </div>
            <div className="frame-2392">
              <div className="ellipse-142">
              </div>
              <span className="nagendra-and-5-other-mutual-connections-2">
              Nagendra and 5 other<br />
              mutual connections
              </span>
            </div>
            <div className="frame-2402">
              <span className="follow-back-2">
              Follow back
              </span>
            </div>
          </div>
          <div className="ellipse-182">
          </div>
        </div>
        <div className="group-125">
          <div className="container">
            <div className="rectangle-803">
            </div>
            <div className="frame-2383">
              <div className="shruthi-1">
              Shruthi
              </div>
              <span className="junior-ui-ux-designer-3">
              Junior UI/UX Designer
              </span>
            </div>
            <div className="frame-2393">
              <div className="ellipse-143">
              </div>
              <span className="nagendra-and-5-other-mutual-connections-3">
              Nagendra and 5 other<br />
              mutual connections
              </span>
            </div>
            <div className="frame-2403">
              <span className="follow-back-3">
              Follow back
              </span>
            </div>
          </div>
          <div className="ellipse-183">
          </div>
        </div>
      </div>
      <div className="frame-31">
        <div className="download-the-mobile-app-now">
        Download the Mobile App Now
        </div>
        <div className="frame-30">
          <div className="frame-29">
            <div className="qr-code">
              <img className="vector-13" src="assets/vectors/Vector222_x2.svg" />
            </div>
            <div className="image-260-nw-23151053071">
            </div>
          </div>
          <div className="frame-28">
            <div className="qr-code-1">
              <img className="vector-15" src="assets/vectors/Vector731_x2.svg" />
            </div>
            <div className="image-260-nw-23151053072">
            </div>
          </div>
        </div>
      </div>
      <div className="frame-27">
        <div className="container-5">
          <div className="frame-22">
            <div className="links">
            Links
            </div>
            <div className="frame-20">
              <div className="home-2">
              Home
              </div>
              <div className="about">
              About
              </div>
              <div className="service">
              Service
              </div>
              <span className="contact-us-1">
              Contact us
              </span>
            </div>
          </div>
          <div className="frame-21">
            <div className="info">
            Info
            </div>
            <div className="frame-201">
              <div className="terms-conditions">
              Terms &amp; Conditions
              </div>
              <div className="refund-policy">
              Refund policy
              </div>
              <span className="privacy-policy">
              Privacy policy
              </span>
            </div>
          </div>
          <div className="frame-19">
            <div className="address">
            Address
            </div>
            <div className="frame-18">
              <p className="registed-61105-saifabad-khairatabad-hyderabad-500004">
              <span className="registed-61105-saifabad-khairatabad-hyderabad-500004-sub-1"></span><span></span>
              </p>
              <p className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018">
              <span className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018-sub-2"></span><span></span>
              </p>
            </div>
          </div>
        </div>
        <div className="frame-26">
          <div className="frame-24">
            <div className="contact-no">
            Contact No
            </div>
            <div className="frame-23">
              <div className="container">
              +91 78936 53899
              </div>
              <span className="inforubia-services">
              info@rubia.services
              </span>
            </div>
          </div>
          <div className="frame-25">
            <div className="skill-iconstwitter">
              <img className="group-1" src="assets/vectors/Group83_x2.svg" />
            </div>
            <div className="akar-iconsfacebook-fill">
              <img className="vector-5" src="assets/vectors/Vector557_x2.svg" />
            </div>
            <div className="skill-iconslinkedin">
              <img className="group-2" src="assets/vectors/Group68_x2.svg" />
            </div>
            <div className="skill-iconsinstagram">
              <img className="group-3" src="assets/vectors/Group76_x2.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
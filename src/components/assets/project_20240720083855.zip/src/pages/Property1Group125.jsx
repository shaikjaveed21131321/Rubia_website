import './Property1Group125.css'

export default function Property1Group125() {
  return (
    <div className="property-1-group-125">
      <span className="property-types">
      Property Types
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector510_x2.svg" />
      </div>
    </div>
  )
}
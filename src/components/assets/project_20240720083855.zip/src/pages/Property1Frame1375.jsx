import './Property1Frame1375.css'

export default function Property1Frame1375() {
  return (
    <div className="property-1-frame-137">
      <span className="ev-scooters">
       EV Scooters
      </span>
    </div>
  )
}
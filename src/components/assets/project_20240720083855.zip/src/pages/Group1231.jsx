import './Group1231.css'

export default function Group1231() {
  return (
    <div className="group-123">
      <span className="property-types">
      Property Types
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector736_x2.svg" />
      </div>
    </div>
  )
}
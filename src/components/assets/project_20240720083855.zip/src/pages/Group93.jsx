import './Group93.css'

export default function Group93() {
  return (
    <div className="group-93">
      <img className="rectangle-40" src="assets/vectors/Rectangle402_x2.svg" />
      <img className="rectangle-39" src="assets/vectors/Rectangle391_x2.svg" />
      <span className="job-seeker-sign-in">
      Job seeker Sign in 
      </span>
      <span className="employers">
      Employers 
      </span>
    </div>
  )
}
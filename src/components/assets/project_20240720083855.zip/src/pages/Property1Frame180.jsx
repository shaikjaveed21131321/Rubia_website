import './Property1Frame180.css'

export default function Property1Frame180() {
  return (
    <div className="property-1-frame-180">
      <span className="date-posted">
      Date posted
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector167_x2.svg" />
      </div>
    </div>
  )
}
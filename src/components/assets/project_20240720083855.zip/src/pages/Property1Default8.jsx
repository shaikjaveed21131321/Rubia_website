import './Property1Default8.css'

export default function Property1Default8() {
  return (
    <div className="property-1-default">
      <img className="group-91" src="assets/vectors/Group919_x2.svg" />
      <div className="frame-124">
        <span className="buy">
        Buy
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-6" src="assets/vectors/Vector730_x2.svg" />
        </div>
      </div>
    </div>
  )
}
import './Property1Frame1772.css'

export default function Property1Frame1772() {
  return (
    <div className="property-1-frame-177">
      <span className="on-site">
      On site
      </span>
    </div>
  )
}
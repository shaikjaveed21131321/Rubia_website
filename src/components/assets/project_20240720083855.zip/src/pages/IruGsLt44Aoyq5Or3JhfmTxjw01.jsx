import './IruGsLt44Aoyq5Or3JhfmTxjw01.css'

export default function IruGsLt44Aoyq5Or3JhfmTxjw01() {
  return (
    <div className="iru-gs-lt-44-aoyq-5-or-3-jhfm-txjw-01">
      <img className="container-22" src="assets/vectors/Container5_x2.svg" />
    </div>
  )
}
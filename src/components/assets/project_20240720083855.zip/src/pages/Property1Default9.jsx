import './Property1Default9.css'

export default function Property1Default9() {
  return (
    <div className="property-1-default">
      <img className="group-91" src="assets/vectors/Group9111_x2.svg" />
      <div className="frame-124">
        <span className="buy">
        Buy
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-6" src="assets/vectors/Vector389_x2.svg" />
        </div>
      </div>
    </div>
  )
}
import './Group98.css'

export default function Group98() {
  return (
    <div className="group-98">
      <div className="group-95">
        <div className="rectangle-50">
        </div>
        <span className="hiring">
        #Hiring
        </span>
      </div>
      <div className="container">
        <div className="sampras-singh">
        Sampras singh
        </div>
        <div className="rubia-services-recruiter">
        Rubia.services Recruiter
        </div>
        <p className="remote-internship-alertrubia-services-read-more">
        <span className="remote-internship-alertrubia-services-read-more-sub-0"></span><span></span>
        </p>
      </div>
    </div>
  )
}
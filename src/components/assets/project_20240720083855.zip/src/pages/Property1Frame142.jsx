import './Property1Frame142.css'

export default function Property1Frame142() {
  return (
    <div className="property-1-frame-142">
      <div className="auto-mobile">
        <div className="giscar">
          <img className="vector" src="assets/vectors/Vector137_x2.svg" />
        </div>
        <div className="frame-134">
          <span className="auto-mobile-1">
          auto mobile
          </span>
          <div className="teenyiconsdown-solid">
            <img className="vector-1" src="assets/vectors/Vector375_x2.svg" />
          </div>
        </div>
      </div>
      <div className="group-109">
        <div className="frame-139">
          <div className="frame-137">
            <div className="bikes-1">
              <span className="bikes-3">
              Cars
              </span>
            </div>
            <div className="ev-scooters-6">
              <span className="ev-scooters-16">
               EV Scooters
              </span>
            </div>
            <div className="ev-scooters">
              <span className="ev-scooters-10">
              Suv
              </span>
            </div>
            <div className="ev-scooters-1">
              <span className="ev-scooters-11">
              Hatchback
              </span>
            </div>
            <div className="ev-scooters-2">
              <span className="ev-scooters-12">
              Sedan
              </span>
            </div>
            <div className="ev-scooters-3">
              <span className="ev-scooters-13">
              Luxury
              </span>
            </div>
          </div>
          <div className="frame-138">
            <div className="bikes">
              <span className="bikes-2">
              Bikes
              </span>
            </div>
            <div className="bicycles-1">
              <span className="bicycles-3">
              Bicycles
              </span>
            </div>
            <div className="motor-cycles">
              <span className="motor-cycles-1">
              Motor cycles
              </span>
            </div>
            <div className="scooters">
              <span className="scooters-1">
              Scooters
              </span>
            </div>
            <div className="ev-bikes">
              <span className="ev-bikes-1">
               EV Bikes
              </span>
            </div>
            <div className="ev-scooters-5">
              <span className="ev-scooters-15">
               EV Scooters
              </span>
            </div>
          </div>
        </div>
        <div className="frame-140">
          <div className="ev-scooters-7">
            <span className="ev-scooters-17">
            Bus
            </span>
          </div>
          <div className="bicycles">
            <span className="bicycles-2">
            EV Bus
            </span>
          </div>
          <div className="ev-scooters-4">
            <span className="ev-scooters-14">
            Auto
            </span>
          </div>
          <div className="ev-scooters-8">
            <span className="ev-scooters-18">
            EV Auto
            </span>
          </div>
          <div className="ev-scooters-9">
            <span className="ev-scooters-19">
            Tractor
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
import './Frame214.css'

export default function Frame214() {
  return (
    <div className="frame-214">
      <div className="container">
        <span className="residential">
        Residential
        </span>
        <span className="residential-1">
        Residential
        </span>
      </div>
      <div className="container-2">
        <div className="component-13">
          <span className="independent-house">
          Independent House
          </span>
        </div>
        <div className="component-19">
          <span className="independent-house-1">
          Office Space
          </span>
        </div>
      </div>
      <div className="container-3">
        <div className="component-14">
          <span className="independent-house-4">
          duplex House 
          </span>
        </div>
        <div className="component-20">
          <span className="independent-house-2">
          Shop/Showroom
          </span>
        </div>
      </div>
      <div className="container-1">
        <div className="component-15">
          <span className="independent-house-5">
          Triplex House
          </span>
        </div>
        <div className="component-21">
          <span className="independent-house-3">
          Open plots
          </span>
        </div>
      </div>
      <div className="component-16">
        <span className="independent-house-6">
        Independent flates
        </span>
      </div>
      <div className="component-17">
        <span className="independent-house-7">
        duplex flates
        </span>
      </div>
      <div className="component-18">
        <span className="independent-house-8">
        Triplex flates
        </span>
      </div>
    </div>
  )
}
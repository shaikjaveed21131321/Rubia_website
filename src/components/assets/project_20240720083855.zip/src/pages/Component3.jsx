import './Component3.css'

export default function Component3() {
  return (
    <div className="component-3">
      <div className="rectangle-53">
      </div>
      <div className="frame-167">
        <div className="group-1011">
        </div>
        <div className="real-estate">
        Real estate
        </div>
      </div>
      <p className="ex-residence-hospitalscompaniesindustries-camarshieal-areas-and-etc">
      <span className="ex-residence-hospitalscompaniesindustries-camarshieal-areas-and-etc-sub-17"></span><span></span>
      </p>
      <span className="lands-buy-sell-and-const">
      Lands Buy,  Sell and Const....
      </span>
      <div className="image-42">
      </div>
      <div className="iconamoonarrow-right-2-bold">
        <img className="vector" src="assets/vectors/Vector138_x2.svg" />
      </div>
      <div className="iconamoonarrow-right-2-bold-1">
        <img className="vector-1" src="assets/vectors/Vector469_x2.svg" />
      </div>
    </div>
  )
}
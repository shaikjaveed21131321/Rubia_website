import './Property1Group143.css'

export default function Property1Group143() {
  return (
    <div className="property-1-group-143">
      <div className="group-135">
        <span className="budget">
        Budget
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector330_x2.svg" />
        </div>
      </div>
      <div className="group-141">
        <div className="container-2">
          <div className="budget-1">
          Budget
          </div>
          <div className="container-3">
            <div className="group-136">
              <span className="lac">
              ₹5Lac
              </span>
              <div className="group">
                <img className="vector-1" src="assets/vectors/Vector207_x2.svg" />
              </div>
            </div>
            <div className="group-137">
              <span className="max">
              Max
              </span>
              <div className="group-1">
                <img className="vector-2" src="assets/vectors/Vector367_x2.svg" />
              </div>
            </div>
          </div>
          <div className="container">
            <div className="group-139">
              <span className="lac-1">
              ₹5Lac
              </span>
            </div>
            <div className="group-138">
              <span className="cr">
              ₹ 5cr
              </span>
            </div>
          </div>
          <div className="container-1">
            <div className="rectangle-106">
            </div>
            <div className="rectangle-105">
            </div>
          </div>
          <div className="done">
            <span className="done-1">
            Done
            </span>
          </div>
        </div>
        <div className="ellipse-18">
        </div>
        <div className="ellipse-19">
        </div>
      </div>
    </div>
  )
}
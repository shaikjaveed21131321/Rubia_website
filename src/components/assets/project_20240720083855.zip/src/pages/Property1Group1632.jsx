import './Property1Group1632.css'

export default function Property1Group1632() {
  return (
    <div className="property-1-group-163">
      <div className="unnati-shree-rath-apartments">
      Unnati Shree Rath Apartments
      </div>
      <div className="nizampet-hyderabad">
      Nizampet, Hyderabad
      </div>
      <div className="container">
        <p className="cr">
        <span className="cr-sub-7"></span><span></span>
        </p>
        <div className="rectangle-126">
        </div>
        <img className="iytsnctfi-5-e-8-sm-zs-pj-cy-3-erg-b-71" src="assets/vectors/Iytsnctfi5E8SmZsPjCy3ErgB71_x2.svg" />
        <div className="sqft">
        2044 sqft
        </div>
      </div>
      <img className="group-163" src="assets/vectors/Group163_x2.svg" />
    </div>
  )
}
import './Property1Default4.css'

export default function Property1Default4() {
  return (
    <div className="property-1-default">
      <img className="group-93" src="assets/vectors/Group934_x2.svg" />
      <div className="frame-125">
        <span className="sell">
        Sell
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-6" src="assets/vectors/Vector293_x2.svg" />
        </div>
      </div>
    </div>
  )
}
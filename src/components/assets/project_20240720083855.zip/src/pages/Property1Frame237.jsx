import './Property1Frame237.css'

export default function Property1Frame237() {
  return (
    <div className="property-1-frame-237">
      <div className="rectangle-49">
      </div>
      <div className="frame-236">
        <div className="sandeep">
        Sandeep
        </div>
        <span className="uiux-designer">
        Ui/ux designer
        </span>
      </div>
    </div>
  )
}
import './Property1Title.css'

export default function Property1Title() {
  return (
    <div className="property-1-title">
      <span className="title">
      ‘Title’
      </span>
    </div>
  )
}
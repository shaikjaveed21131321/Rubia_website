import './Group124.css'

export default function Group124() {
  return (
    <div className="group-124">
      <div className="container">
        <div className="rectangle-80">
        </div>
        <div className="frame-238">
          <div className="sampras-singh">
          Sampras singh
          </div>
          <span className="junior-ui-ux-designer">
          Junior UI/UX Designer
          </span>
        </div>
        <div className="frame-239">
          <div className="ellipse-14">
          </div>
          <span className="nagendra-and-5-other-mutual-connections">
          Nagendra and 5 other<br />
          mutual connections
          </span>
        </div>
        <div className="frame-240">
          <span className="follow-back">
          Follow back
          </span>
        </div>
      </div>
      <div className="ellipse-18">
      </div>
    </div>
  )
}
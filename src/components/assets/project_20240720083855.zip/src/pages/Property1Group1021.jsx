import './Property1Group1021.css'

export default function Property1Group1021() {
  return (
    <div className="property-1-group-102">
      <div className="group-95">
        <div className="rectangle-50">
        </div>
        <span className="hiring">
        #Hiring
        </span>
      </div>
      <div className="container">
        <div className="sampras-singh">
        Sampras singh
        </div>
        <div className="rubia-services-recruiter">
        Rubia.services Recruiter
        </div>
        <p className="remote-internship-alertrubia-services-bangalore-india-is-hiring-ui-ux-designer-intern-stipend-rs-20-k-25-kmonth-eligible-202120222023202420252026-skills-figma-ui-ux-product-design-ux-research-duration-3-monthsstarting-date-immediate-comment-interested-ill-dm-you-the-link-see-less">
        <span className="remote-internship-alertrubia-services-bangalore-india-is-hiring-ui-ux-designer-intern-stipend-rs-20-k-25-kmonth-eligible-202120222023202420252026-skills-figma-ui-ux-product-design-ux-research-duration-3-monthsstarting-date-immediate-comment-interested-ill-dm-you-the-link-see-less-sub-0"></span><span></span>
        </p>
      </div>
      <div className="container-1">
        <div className="hr-ago">
        1hr ago
        </div>
        <div className="frame-127">
          <span className="follow">
          Follow
          </span>
        </div>
      </div>
    </div>
  )
}
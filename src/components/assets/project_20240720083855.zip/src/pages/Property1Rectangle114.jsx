import './Property1Rectangle114.css'

export default function Property1Rectangle114() {
  return (
    <div className="property-1-rectangle-114">
      <div className="rectangle-114">
      </div>
    </div>
  )
}
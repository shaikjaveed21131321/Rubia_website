import './Profile1.css'

export default function Profile1() {
  return (
    <div className="profile">
      <div className="frame-178">
        <div className="ellipse-14">
        </div>
        <div className="frame-176">
          <span className="profile-1">
          Profile
          </span>
          <div className="teenyiconsdown-solid">
            <img className="vector" src="assets/vectors/Vector211_x2.svg" />
          </div>
        </div>
      </div>
      <div className="group-113">
        <div className="group-112">
          <div className="ellipse-141">
          </div>
          <div className="container">
            <div className="sampras-singh">
            Sampras singh
            </div>
            <span className="ui-ux-designer">
            UI/UX Designer
            </span>
          </div>
        </div>
        <div className="frame-179">
          <span className="view-profile">
          View profile
          </span>
        </div>
        <div className="employers-sign-in">
        Employers Sign in 
        </div>
        <span className="sign-out">
        Sign Out 
        </span>
      </div>
    </div>
  )
}
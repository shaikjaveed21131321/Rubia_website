import './Property1AutoMobile.css'

export default function Property1AutoMobile() {
  return (
    <div className="property-1-auto-mobile">
      <div className="giscar">
        <img className="vector" src="assets/vectors/Vector686_x2.svg" />
      </div>
      <div className="frame-134">
        <span className="auto-mobile">
        auto mobile
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-1" src="assets/vectors/Vector140_x2.svg" />
        </div>
      </div>
    </div>
  )
}
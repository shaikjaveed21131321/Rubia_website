import './Property1Frame1371.css'

export default function Property1Frame1371() {
  return (
    <div className="property-1-frame-137">
      <span className="bikes">
      Bikes
      </span>
    </div>
  )
}
import './Services.css'

export default function Services() {
  return (
    <div className="services">
      <div className="container">
        <div className="digital-marketing">
          <div className="property-1-frame-1185">
            <img className="mask-group-8" src="assets/vectors/MaskGroup5_x2.svg" />
            <div className="digital-marketing-1">
            DIGITAL MARKETING
            </div>
          </div>
          <div className="property-1-frame-2175">
            <img className="mask-group-9" src="assets/vectors/MaskGroup71_x2.svg" />
            <div className="digital-marketing-2">
            DIGITAL MARKETING
            </div>
          </div>
        </div>
        <div className="job-portal">
          <div className="property-1-frame-1187">
            <img className="mask-group-12" src="assets/vectors/MaskGroup36_x2.svg" />
            <div className="job-portal-1">
            JOB PORTAL
            </div>
          </div>
          <div className="property-1-frame-2177">
            <img className="mask-group-13" src="assets/vectors/MaskGroup49_x2.svg" />
            <div className="job-portal-2">
            JOB PORTAL
            </div>
          </div>
        </div>
        <div className="ux-ui-designing">
          <div className="property-1-frame-1186">
            <img className="mask-group-10" src="assets/vectors/MaskGroup30_x2.svg" />
            <div className="ux-ui-designing-1">
            UX/UI Designing
            </div>
          </div>
          <div className="property-1-frame-2176">
            <img className="mask-group-11" src="assets/vectors/MaskGroup51_x2.svg" />
            <div className="ux-ui-designing-2">
            UX/UI Designing
            </div>
          </div>
        </div>
        <div className="job-portal-3">
          <div className="property-1-frame-1188">
            <img className="mask-group-14" src="assets/vectors/MaskGroup26_x2.svg" />
            <div className="real-estate">
            REAL ESTATE
            </div>
          </div>
          <div className="property-1-frame-2178">
            <img className="mask-group-15" src="assets/vectors/MaskGroup35_x2.svg" />
            <div className="real-estate-1">
            REAL ESTATE
            </div>
          </div>
        </div>
      </div>
      <div className="container-1">
        <div className="software">
          <div className="property-1-frame-1184">
            <img className="mask-group-6" src="assets/vectors/MaskGroup65_x2.svg" />
            <div className="software-1">
            SOFTWARE
            </div>
          </div>
          <div className="property-1-frame-2174">
            <img className="mask-group-7" src="assets/vectors/MaskGroup21_x2.svg" />
            <div className="software-2">
            SOFTWARE
            </div>
          </div>
        </div>
        <div className="graphic-designing">
          <div className="property-1-frame-1183">
            <div className="group-42">
              <img className="mask-group-16" src="assets/vectors/MaskGroup12_x2.svg" />
            </div>
            <div className="graphic-designing-1">
            GRAPHIC DESIGNING
            </div>
          </div>
          <div className="property-1-frame-2173">
            <div className="group-43">
              <img className="mask-group-17" src="assets/vectors/MaskGroup87_x2.svg" />
            </div>
            <div className="graphic-designing-2">
            GRAPHIC DESIGNING
            </div>
          </div>
        </div>
        <div className="taxi">
          <div className="property-1-frame-1182">
            <img className="mask-group-4" src="assets/vectors/MaskGroup54_x2.svg" />
            <div className="taxi-1">
            TAXI
            </div>
          </div>
          <div className="property-1-frame-2172">
            <img className="mask-group-5" src="assets/vectors/MaskGroup75_x2.svg" />
            <div className="taxi-2">
            TAXI
            </div>
          </div>
        </div>
        <div className="fcc">
          <div className="property-1-frame-118">
            <img className="mask-group" src="assets/vectors/MaskGroup59_x2.svg" />
            <div className="business-listing">
            Business Listing
            </div>
          </div>
          <div className="property-1-frame-217">
            <img className="mask-group-1" src="assets/vectors/MaskGroup19_x2.svg" />
            <div className="business-listing-1">
            Business Listing
            </div>
          </div>
        </div>
        <div className="drivers">
          <div className="property-1-frame-1181">
            <img className="mask-group-2" src="assets/vectors/MaskGroup81_x2.svg" />
            <div className="drivers-1">
            DRIVERS
            </div>
          </div>
          <div className="property-1-frame-2171">
            <img className="mask-group-3" src="assets/vectors/MaskGroup57_x2.svg" />
            <div className="drivers-2">
            DRIVERS
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
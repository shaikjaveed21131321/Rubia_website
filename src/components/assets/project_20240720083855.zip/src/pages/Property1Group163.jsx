import './Property1Group163.css'

export default function Property1Group163() {
  return (
    <div className="property-1-group-163">
      <div className="rectangle-124">
      </div>
      <div className="ellipse-4">
      </div>
      <div className="rectangle-28">
      </div>
      <div className="ellipse-5">
      </div>
    </div>
  )
}
import './Property1Frame1377.css'

export default function Property1Frame1377() {
  return (
    <div className="property-1-frame-137">
      <span className="read-more-comment">
      Read more comment
      </span>
    </div>
  )
}
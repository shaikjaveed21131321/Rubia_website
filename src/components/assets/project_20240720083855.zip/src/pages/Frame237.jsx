import './Frame237.css'

export default function Frame237() {
  return (
    <div className="frame-237">
    </div>
  )
}
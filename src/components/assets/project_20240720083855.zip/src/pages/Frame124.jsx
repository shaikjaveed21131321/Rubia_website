import './Frame124.css'

export default function Frame124() {
  return (
    <div className="frame-124">
      <div className="icbaseline-search">
        <img className="vector" src="assets/vectors/Vector272_x2.svg" />
      </div>
      <span className="search">
      Search
      </span>
    </div>
  )
}
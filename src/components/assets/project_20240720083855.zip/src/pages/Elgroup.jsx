import './Elgroup.css'

export default function Elgroup() {
  return (
    <div className="elgroup">
      <img className="vector" src="assets/vectors/Vector309_x2.svg" />
    </div>
  )
}
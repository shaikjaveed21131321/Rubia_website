import './Property1Buy.css'

export default function Property1Buy() {
  return (
    <div className="property-1-buy">
      <img className="group-91" src="assets/vectors/Group91_x2.svg" />
      <div className="frame-124">
        <span className="buy">
        Buy
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-6" src="assets/vectors/Vector488_x2.svg" />
        </div>
      </div>
    </div>
  )
}
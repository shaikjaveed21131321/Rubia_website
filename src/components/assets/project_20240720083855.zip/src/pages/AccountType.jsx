import './AccountType.css'

export default function AccountType() {
  return (
    <div className="account-type">
      <div className="container">
        <div className="manpower-consultants">
          <div className="property-1-frame-1761">
            <span className="manpower-consultants-1">
            Manpower consultants
            </span>
          </div>
          <div className="property-1-frame-1771">
            <span className="manpower-consultants-2">
            Manpower consultants
            </span>
          </div>
        </div>
        <div className="employers-corporates-2">
          <div className="property-1-frame-176">
            <span className="employers-corporates">
            Employers/Corporates
            </span>
          </div>
          <div className="property-1-frame-177">
            <span className="employers-corporates-1">
            Employers/Corporates
            </span>
          </div>
        </div>
      </div>
      <div className="container-3">
        <div className="colleges-universities">
          <div className="property-1-frame-1762">
            <span className="colleges-universities-1">
            Colleges/Universities
            </span>
          </div>
          <div className="property-1-frame-1772">
            <span className="colleges-universities-2">
            Colleges/Universities
            </span>
          </div>
        </div>
        <div className="educational-consultants">
          <div className="property-1-frame-1764">
            <span className="educational-consultants-1">
            Educational Consultants
            </span>
          </div>
          <div className="property-1-frame-1774">
            <span className="educational-consultants-2">
            Educational Consultants
            </span>
          </div>
        </div>
      </div>
      <div className="container-2">
        <div className="training-institutes">
          <div className="property-1-frame-1763">
            <span className="training-institutes-1">
            Training Institutes
            </span>
          </div>
          <div className="property-1-frame-1773">
            <span className="training-institutes-2">
            Training Institutes
            </span>
          </div>
        </div>
        <div className="others">
          <div className="property-1-frame-1767">
            <span className="others-1">
            Others
            </span>
          </div>
          <div className="property-1-frame-1777">
            <span className="others-2">
            Others
            </span>
          </div>
        </div>
      </div>
      <div className="container-1">
        <div className="ad-agencies-affiliates">
          <div className="property-1-frame-1765">
            <span className="ad-agencies-affiliates-1">
            Ad Agencies/Affiliates
            </span>
          </div>
          <div className="property-1-frame-1775">
            <span className="ad-agencies-affiliates-2">
            Ad Agencies/Affiliates
            </span>
          </div>
        </div>
        <div className="job-seeker">
          <div className="property-1-frame-1766">
            <span className="job-seeker-1">
            Job Seeker
            </span>
          </div>
          <div className="property-1-frame-1776">
            <span className="job-seeker-2">
            Job Seeker
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
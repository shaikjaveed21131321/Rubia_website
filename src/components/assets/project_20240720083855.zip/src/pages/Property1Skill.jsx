import './Property1Skill.css'

export default function Property1Skill() {
  return (
    <div className="property-1-skill">
      <span className="skill">
      ‘Skill’
      </span>
    </div>
  )
}
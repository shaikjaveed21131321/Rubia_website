import './IrqRwB31VqcenPfnZc35ZripVv11.css'

export default function IrqRwB31VqcenPfnZc35ZripVv11() {
  return (
    <div className="irq-rw-b-31-vqcen-pfn-zc-35-zrip-vv-11">
      <img className="container-52" src="assets/vectors/Container4_x2.svg" />
    </div>
  )
}
import './RealEstate.css'

export default function RealEstate() {
  return (
    <div className="real-estate">
      <div className="container">
        <div className="group-101">
        </div>
        <div className="frame-4">
          <span className="home">
          HOME
          </span>
          <span className="services">
          SERVICES
          </span>
          <span className="about-us">
          ABOUT US
          </span>
          <span className="contact-us">
          CONTACT US
          </span>
          <span className="blog">
          BLOG
          </span>
        </div>
      </div>
      <div className="container-10">
        <div className="group-89">
          <div className="frame-12">
            <span className="we-provide">
            We Provide
            </span>
          </div>
          <div className="frame-3">
            <span className="drivers">
            DRIVERS
            </span>
          </div>
          <div className="frame-7">
            <span className="graphic-designing">
            GRAPHIC DESIGNING
            </span>
          </div>
          <div className="frame-6">
            <span className="software">
            SOFTWARE
            </span>
          </div>
          <div className="frame-8">
            <span className="digital-marketing">
            DIGITAL MARKETING
            </span>
          </div>
          <div className="frame-15">
            <span className="ux-ui-designing">
            UX/UI Designing
            </span>
          </div>
          <div className="frame-114">
            <span className="taxi">
            TAXI
            </span>
          </div>
          <div className="frame-115">
            <span className="job-portal">
            JOB PORTAL
            </span>
          </div>
          <div className="frame-116">
            <span className="real-estate-1">
            REAL ESTATE
            </span>
          </div>
        </div>
        <div className="container-5">
          <div className="container-1">
            <div className="container-12">
              <div className="buy-222">
                <img className="group-91" src="assets/vectors/Group9119_x2.svg" />
                <div className="frame-124">
                  <span className="buy">
                  Buy
                  </span>
                  <div className="teenyiconsdown-solid-3">
                    <img className="vector-37" src="assets/vectors/Vector614_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="rent-1">
                <img className="group-92" src="assets/vectors/Group925_x2.svg" />
                <div className="frame-1253">
                  <span className="rent">
                  Rent
                  </span>
                  <div className="teenyiconsdown-solid-8">
                    <img className="vector-45" src="assets/vectors/Vector743_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="sell">
                <img className="group-93" src="assets/vectors/Group931_x2.svg" />
                <div className="frame-125">
                  <span className="sell-1">
                  Sell
                  </span>
                  <div className="teenyiconsdown-solid">
                    <img className="vector-24" src="assets/vectors/Vector214_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="home-loans">
                <img className="group-941" src="assets/vectors/Group949_x2.svg" />
                <div className="frame-1261">
                  <span className="home-loans-1">
                  Home Loans
                  </span>
                  <div className="teenyiconsdown-solid-1">
                    <img className="vector-28" src="assets/vectors/Vector424_x2.svg" />
                  </div>
                </div>
              </div>
            </div>
            <div className="container-6">
              <div className="pg">
                <div className="fluent-emoji-high-contrastoffice-building">
                  <img className="vector-41" src="assets/vectors/Vector604_x2.svg" />
                </div>
                <div className="frame-1252">
                  <span className="pg-1">
                  PG
                  </span>
                  <div className="teenyiconsdown-solid-6">
                    <img className="vector-40" src="assets/vectors/Vector377_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="help">
                <div className="mingcuteservice-fill">
                  <img className="vector-29" src="assets/vectors/Vector334_x2.svg" />
                </div>
                <div className="frame-1251">
                  <span className="help-1">
                  Help
                  </span>
                  <div className="teenyiconsdown-solid-2">
                    <img className="vector-30" src="assets/vectors/Vector456_x2.svg" />
                  </div>
                </div>
              </div>
              <div className="frame-212">
                <span className="sign-in">
                Sign in
                </span>
                <div className="mingcutedown-fill">
                  <img className="vector-14" src="assets/vectors/Vector252_x2.svg" />
                </div>
              </div>
            </div>
          </div>
          <div className="container-8">
            <div className="property-types">
              <span className="property-types-1">
              Property Types
              </span>
              <div className="teenyiconsdown-solid-4">
                <img className="vector-38" src="assets/vectors/Vector478_x2.svg" />
              </div>
            </div>
            <div className="bhk">
              <span className="bhk-1">
              BHK
              </span>
              <div className="teenyiconsdown-solid-5">
                <img className="vector-39" src="assets/vectors/Vector291_x2.svg" />
              </div>
            </div>
            <div className="budgettttttttttttt">
              <span className="budget">
              Budget
              </span>
              <div className="teenyiconsdown-solid-10">
                <img className="vector-47" src="assets/vectors/Vector294_x2.svg" />
              </div>
            </div>
            <div className="posted-by">
              <span className="posted-by-1">
              Posted By
              </span>
              <div className="teenyiconsdown-solid-7">
                <img className="vector-42" src="assets/vectors/Vector74_x2.svg" />
              </div>
            </div>
            <div className="component-34">
              <span className="filters">
              Filters
              </span>
              <div className="teenyiconsdown-solid-9">
                <img className="vector-46" src="assets/vectors/Vector625_x2.svg" />
              </div>
            </div>
          </div>
          <div className="group-108">
            <p className="find-ahome-away-fromhome">
            <span className="find-ahome-away-fromhome-sub-0"></span><span></span>
            </p>
            <div className="group-94">
              <div className="container-11">
                <div className="icbaseline-search">
                  <img className="vector-15" src="assets/vectors/Vector371_x2.svg" />
                </div>
                <span className="search">
                Search
                </span>
              </div>
              <div className="container-9">
                <div className="rectangle-46">
                </div>
                <div className="weuilocation-outlined">
                  <img className="vector-16" src="assets/vectors/Vector373_x2.svg" />
                </div>
                <div className="anywhere-in-india">
                Anywhere in India
                </div>
              </div>
              <div className="container-3">
                <div className="map">
                  <div className="fluentmy-location-20-filled">
                    <img className="vector-17" src="assets/vectors/Vector158_x2.svg" />
                  </div>
                </div>
                <div className="frame-126">
                  <span className="search-1">
                  Search
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="container-7">
            <div className="ddddd">
              <div className="image-31">
              </div>
              <div className="rectangle-1241">
              </div>
              <div className="rectangle-282">
              </div>
              <div className="ellipse-41">
              </div>
              <div className="ellipse-51">
              </div>
            </div>
            <div className="no-1">
              <div className="image-3">
              </div>
              <div className="rectangle-124">
              </div>
              <div className="rectangle-281">
              </div>
              <div className="ellipse-4">
              </div>
              <div className="ellipse-5">
              </div>
            </div>
          </div>
        </div>
        <div className="group-90">
          <div className="container-4">
            <span className="new-project">
            New project
            </span>
          </div>
          <div className="rectangle-30">
          </div>
          <div className="rectangle-31">
          </div>
          <div className="rectangle-32">
          </div>
        </div>
      </div>
      <div className="rectangle-66">
      </div>
      <div className="rectangle-67">
      </div>
      <div className="frame-31">
        <div className="download-the-mobile-app-now">
        Download the Mobile App Now
        </div>
        <div className="frame-30">
          <div className="frame-29">
            <div className="qr-code">
              <img className="vector-11" src="assets/vectors/Vector279_x2.svg" />
            </div>
            <div className="image-260-nw-23151053071">
            </div>
          </div>
          <div className="frame-28">
            <div className="qr-code-1">
              <img className="vector-13" src="assets/vectors/Vector95_x2.svg" />
            </div>
            <div className="image-260-nw-23151053072">
            </div>
          </div>
        </div>
      </div>
      <div className="frame-27">
        <div className="container-2">
          <div className="frame-22">
            <div className="links">
            Links
            </div>
            <div className="frame-20">
              <div className="home-1">
              Home
              </div>
              <div className="about">
              About
              </div>
              <div className="service">
              Service
              </div>
              <span className="contact-us-1">
              Contact us
              </span>
            </div>
          </div>
          <div className="frame-21">
            <div className="info">
            Info
            </div>
            <div className="frame-201">
              <div className="terms-conditions">
              Terms &amp; Conditions
              </div>
              <div className="refund-policy">
              Refund policy
              </div>
              <span className="privacy-policy">
              Privacy policy
              </span>
            </div>
          </div>
          <div className="frame-19">
            <div className="address">
            Address
            </div>
            <div className="frame-18">
              <p className="registed-61105-saifabad-khairatabad-hyderabad-500004">
              <span className="registed-61105-saifabad-khairatabad-hyderabad-500004-sub-1"></span><span></span>
              </p>
              <p className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018">
              <span className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018-sub-2"></span><span></span>
              </p>
            </div>
          </div>
        </div>
        <div className="frame-26">
          <div className="frame-24">
            <div className="contact-no">
            Contact No
            </div>
            <div className="frame-23">
              <div className="container">
              +91 78936 53899
              </div>
              <span className="inforubia-services">
              info@rubia.services
              </span>
            </div>
          </div>
          <div className="frame-25">
            <div className="skill-iconstwitter">
              <img className="group" src="assets/vectors/Group72_x2.svg" />
            </div>
            <div className="akar-iconsfacebook-fill">
              <img className="vector-3" src="assets/vectors/Vector369_x2.svg" />
            </div>
            <div className="skill-iconslinkedin">
              <img className="group-1" src="assets/vectors/Group75_x2.svg" />
            </div>
            <div className="skill-iconsinstagram">
              <img className="group-2" src="assets/vectors/Group59_x2.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
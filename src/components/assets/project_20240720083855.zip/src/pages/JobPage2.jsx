import './JobPage2.css'

export default function JobPage2() {
  return (
    <div className="job-page">
      <div className="container">
        <div className="group-101">
        </div>
        <div className="frame-4">
          <span className="home">
          HOME
          </span>
          <span className="services">
          SERVICES
          </span>
          <span className="about-us">
          ABOUT US
          </span>
          <span className="contact-us">
          CONTACT US
          </span>
          <span className="blog">
          BLOG
          </span>
        </div>
      </div>
      <div className="container-4">
        <div className="group-89">
          <div className="frame-12">
            <span className="we-provide">
            We Provide
            </span>
          </div>
          <div className="frame-3">
            <span className="drivers">
            DRIVERS
            </span>
          </div>
          <div className="frame-7">
            <span className="graphic-designing">
            GRAPHIC DESIGNING
            </span>
          </div>
          <div className="frame-6">
            <span className="software">
            SOFTWARE
            </span>
          </div>
          <div className="frame-8">
            <span className="digital-marketing">
            DIGITAL MARKETING
            </span>
          </div>
          <div className="frame-15">
            <span className="ux-ui-designing">
            UX/UI Designing
            </span>
          </div>
          <div className="frame-114">
            <span className="taxi">
            TAXI
            </span>
          </div>
          <div className="frame-115">
            <span className="job-portal">
            JOB PORTAL
            </span>
          </div>
          <div className="frame-116">
            <span className="real-estate">
            REAL ESTATE
            </span>
          </div>
        </div>
        <div className="container-1">
          <div className="container-6">
            <div className="frame-123">
              <div className="heroiconshome-solid">
                <img className="group-3" src="assets/vectors/Group17_x2.svg" />
              </div>
              <span className="home-2">
              Home
              </span>
            </div>
            <div className="component-5">
              <div className="icbaseline-search">
                <img className="vector-17" src="assets/vectors/Vector496_x2.svg" />
              </div>
              <span className="search">
              Search
              </span>
            </div>
            <div className="component-2">
              <div className="basilbag-solid">
                <img className="vector-20" src="assets/vectors/Vector239_x2.svg" />
                <img className="vector-21" src="assets/vectors/Vector678_x2.svg" />
              </div>
              <span className="jobs">
              Jobs
              </span>
            </div>
            <div className="component-6">
              <div className="mdipeople-add">
                <img className="vector-18" src="assets/vectors/Vector520_x2.svg" />
              </div>
              <span className="my-network">
              My Network
              </span>
            </div>
            <div className="component-4">
              <div className="lets-iconsmessage-fill">
                <img className="vector-19" src="assets/vectors/Vector255_x2.svg" />
              </div>
              <span className="messages">
              Messages
              </span>
            </div>
            <div className="profile">
              <div className="ellipse-141">
              </div>
              <div className="frame-176">
                <span className="profile-1">
                Profile
                </span>
                <div className="teenyiconsdown-solid">
                  <img className="vector-22" src="assets/vectors/Vector415_x2.svg" />
                </div>
              </div>
            </div>
          </div>
          <div className="container-2">
            <div className="container-7">
              <img className="group-16" src="assets/vectors/Group163_x2.svg" />
            </div>
            <div className="frame-228">
              <div className="banoth-sampras-singh">
              Banoth Sampras singh
              </div>
              <span className="ui-ux-designer">
              UI/UX Designer
              </span>
            </div>
            <div className="frame-229">
              <div className="container-1">
              24
              </div>
              <span className="post">
              Post
              </span>
            </div>
            <div className="frame-230">
              <div className="container-2">
              124
              </div>
              <span className="followers">
              Followers
              </span>
            </div>
            <div className="frame-231">
              <div className="container-3">
              84
              </div>
              <span className="followers-1">
              Followers
              </span>
            </div>
          </div>
          <div className="container-3">
            <div className="post-1">
              <div className="subwaybox-1">
                <img className="vector-30" src="assets/vectors/Vector38_x2.svg" />
              </div>
              <span className="posts">
              Posts
              </span>
              <div className="teenyiconsdown-solid-4">
                <img className="vector-29" src="assets/vectors/Vector577_x2.svg" />
              </div>
            </div>
            <div className="saved">
              <img className="rectangle-62" src="assets/vectors/Rectangle629_x2.svg" />
              <span className="saved-3">
              Saved
              </span>
              <div className="teenyiconsdown-solid-1">
                <img className="vector-23" src="assets/vectors/Vector724_x2.svg" />
              </div>
            </div>
            <div className="saved-1">
              <div className="material-symbolspost-add">
                <img className="vector-25" src="assets/vectors/Vector562_x2.svg" />
              </div>
              <span className="create-apost">
              Create a post
              </span>
              <div className="teenyiconsdown-solid-2">
                <img className="vector-24" src="assets/vectors/Vector141_x2.svg" />
              </div>
            </div>
            <div className="saved-2">
              <div className="hugeiconsjob-search">
                <img className="group-4" src="assets/vectors/Group16_x2.svg" />
              </div>
              <span className="applied-jobs">
              Applied Jobs
              </span>
              <div className="teenyiconsdown-solid-3">
                <img className="vector-26" src="assets/vectors/Vector344_x2.svg" />
              </div>
            </div>
          </div>
          <div className="rectangle-68">
          </div>
        </div>
        <div className="group-90">
          <div className="rectangle-29">
          </div>
          <div className="rectangle-30">
          </div>
          <div className="rectangle-31">
          </div>
          <div className="rectangle-32">
          </div>
        </div>
      </div>
      <div className="frame-31">
        <div className="download-the-mobile-app-now">
        Download the Mobile App Now
        </div>
        <div className="frame-30">
          <div className="frame-29">
            <div className="qr-code">
              <img className="vector-11" src="assets/vectors/Vector565_x2.svg" />
            </div>
            <div className="image-260-nw-23151053071">
            </div>
          </div>
          <div className="frame-28">
            <div className="qr-code-1">
              <img className="vector-13" src="assets/vectors/Vector299_x2.svg" />
            </div>
            <div className="image-260-nw-23151053072">
            </div>
          </div>
        </div>
      </div>
      <div className="frame-27">
        <div className="container-5">
          <div className="frame-22">
            <div className="links">
            Links
            </div>
            <div className="frame-20">
              <div className="home-1">
              Home
              </div>
              <div className="about">
              About
              </div>
              <div className="service">
              Service
              </div>
              <span className="contact-us-1">
              Contact us
              </span>
            </div>
          </div>
          <div className="frame-21">
            <div className="info">
            Info
            </div>
            <div className="frame-201">
              <div className="terms-conditions">
              Terms &amp; Conditions
              </div>
              <div className="refund-policy">
              Refund policy
              </div>
              <span className="privacy-policy">
              Privacy policy
              </span>
            </div>
          </div>
          <div className="frame-19">
            <div className="address">
            Address
            </div>
            <div className="frame-18">
              <p className="registed-61105-saifabad-khairatabad-hyderabad-500004">
              <span className="registed-61105-saifabad-khairatabad-hyderabad-500004-sub-1"></span><span></span>
              </p>
              <p className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018">
              <span className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018-sub-2"></span><span></span>
              </p>
            </div>
          </div>
        </div>
        <div className="frame-26">
          <div className="frame-24">
            <div className="contact-no">
            Contact No
            </div>
            <div className="frame-23">
              <div className="container">
              +91 78936 53899
              </div>
              <span className="inforubia-services">
              info@rubia.services
              </span>
            </div>
          </div>
          <div className="frame-25">
            <div className="skill-iconstwitter">
              <img className="group" src="assets/vectors/Group22_x2.svg" />
            </div>
            <div className="akar-iconsfacebook-fill">
              <img className="vector-3" src="assets/vectors/Vector76_x2.svg" />
            </div>
            <div className="skill-iconslinkedin">
              <img className="group-1" src="assets/vectors/Group60_x2.svg" />
            </div>
            <div className="skill-iconsinstagram">
              <img className="group-2" src="assets/vectors/Group80_x2.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
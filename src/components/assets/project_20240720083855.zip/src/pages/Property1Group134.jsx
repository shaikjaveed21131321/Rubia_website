import './Property1Group134.css'

export default function Property1Group134() {
  return (
    <div className="property-1-group-134">
      <div className="group-126">
        <span className="property-types">
        Property Types
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector355_x2.svg" />
        </div>
      </div>
      <div className="group-132">
        <div className="container-2">
          <span className="residential">
          Residential
          </span>
          <span className="commercial">
          Commercial
          </span>
        </div>
        <div className="container-4">
          <div className="component-13">
            <span className="independent-house-2">
            Independent House
            </span>
          </div>
          <div className="component-19">
            <span className="independent-house-3">
            Office Space
            </span>
          </div>
        </div>
        <div className="container-5">
          <div className="component-24">
            <span className="independent-house-11">
            Single floor
            </span>
          </div>
          <div className="component-20">
            <span className="independent-house-4">
            Shop/Showroom
            </span>
          </div>
        </div>
        <div className="container-1">
          <div className="component-14">
            <span className="independent-house-6">
            duplex House 
            </span>
          </div>
          <div className="component-21">
            <span className="independent-house-5">
            Open Space
            </span>
          </div>
        </div>
        <div className="container">
          <div className="component-15">
            <span className="independent-house-7">
            Triplex House
            </span>
          </div>
          <div className="component-22">
            <span className="independent-house">
            Independent House
            </span>
          </div>
        </div>
        <div className="container-6">
          <div className="component-16">
            <span className="independent-house-8">
            Apartment
            </span>
          </div>
          <div className="component-23">
            <span className="independent-house-1">
            Independent flates
            </span>
          </div>
        </div>
        <div className="component-25">
          <span className="independent-house-12">
          Single floor
          </span>
        </div>
        <div className="component-17">
          <span className="independent-house-9">
          duplex Apartment
          </span>
        </div>
        <div className="container-3">
          <div className="component-18">
            <span className="independent-house-10">
            Triplex Apartment
            </span>
          </div>
          <div className="done">
            <span className="done-1">
            Done
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
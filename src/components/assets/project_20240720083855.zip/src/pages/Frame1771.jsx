import './Frame1771.css'

export default function Frame1771() {
  return (
    <div className="frame-177">
      <span className="save">
      Save
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector701_x2.svg" />
      </div>
    </div>
  )
}
import './InstagramPost7.css'

export default function InstagramPost7() {
  return (
    <div className="instagram-post-7">
      <div className="image-3">
      </div>
      <div className="container">
        <div className="group-2">
          <img className="mask-group-1" src="assets/vectors/MaskGroup70_x2.svg" />
        </div>
        <p className="happy-international-yoga-day">
        <span className="happy-international-yoga-day-sub-0"></span><span className="happy-international-yoga-day-sub-371"></span><span></span>
        </p>
        <img className="mask-group" src="assets/vectors/MaskGroup6_x2.svg" />
        <div className="image-11">
        </div>
      </div>
      <div className="image-6">
      </div>
      <div className="image-1">
      </div>
    </div>
  )
}
import './Property1Default.css'

export default function Property1Default() {
  return (
    <div className="property-1-default">
      <span className="job-seeker-sign-in">
      Job seeker Sign in
      </span>
    </div>
  )
}
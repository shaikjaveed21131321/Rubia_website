import './Property1Group127.css'

export default function Property1Group127() {
  return (
    <div className="property-1-group-127">
      <span className="budget">
      Budget
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector487_x2.svg" />
      </div>
    </div>
  )
}
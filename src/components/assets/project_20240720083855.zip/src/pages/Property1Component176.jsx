import './Property1Component176.css'

export default function Property1Component176() {
  return (
    <div className="property-1-component-17">
      <div className="icbaseline-search">
        <img className="vector" src="assets/vectors/Vector129_x2.svg" />
      </div>
      <span className="search">
      Search
      </span>
    </div>
  )
}
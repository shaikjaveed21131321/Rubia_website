import './Property1Frame181.css'

export default function Property1Frame181() {
  return (
    <div className="property-1-frame-181">
      <div className="mditick-circle-outline">
        <img className="vector" src="assets/vectors/Vector172_x2.svg" />
      </div>
      <span className="independent-house">
      Independent House
      </span>
    </div>
  )
}
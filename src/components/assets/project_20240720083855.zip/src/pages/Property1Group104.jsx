import './Property1Group104.css'

export default function Property1Group104() {
  return (
    <div className="property-1-group-104">
      <div className="container">
        <span className="likes">
        1203 likes
        </span>
        <span className="comments">
        1203 Comments
        </span>
      </div>
      <div className="rectangle-53">
      </div>
      <div className="container-1">
        <div className="frame-128">
          <div className="mdilike-outline">
            <img className="vector-4" src="assets/vectors/Vector453_x2.svg" />
          </div>
          <span className="like">
          Like
          </span>
        </div>
        <div className="frame-129">
          <div className="material-symbolscomment-outline">
            <img className="vector" src="assets/vectors/Vector91_x2.svg" />
          </div>
          <div className="comment">
          Comment
          </div>
        </div>
        <div className="frame-130">
          <div className="material-symbolsshare">
            <img className="vector-1" src="assets/vectors/Vector208_x2.svg" />
          </div>
          <div className="share">
          Share
          </div>
        </div>
        <div className="frame-131">
          <div className="fluentsave-copy-20-filled">
            <img className="vector-2" src="assets/vectors/Vector602_x2.svg" />
          </div>
          <span className="save">
          Save
          </span>
        </div>
      </div>
      <div className="container-2">
        <div className="rectangle-49">
        </div>
        <div className="group-103">
          <span className="add-acomment">
          Add a Comment
          </span>
          <div className="fluentemoji-24-regular">
            <img className="vector-3" src="assets/vectors/Vector394_x2.svg" />
          </div>
        </div>
      </div>
    </div>
  )
}
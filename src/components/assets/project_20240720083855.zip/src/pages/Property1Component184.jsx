import './Property1Component184.css'

export default function Property1Component184() {
  return (
    <div className="property-1-component-18">
      <div className="rectangle-72">
      </div>
      <span className="game-app">
      Game app
      </span>
    </div>
  )
}
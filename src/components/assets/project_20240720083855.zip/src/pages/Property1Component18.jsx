import './Property1Component18.css'

export default function Property1Component18() {
  return (
    <div className="property-1-component-18">
      <div className="rectangle-72">
      </div>
      <span className="yoga-day">
      Yoga Day
      </span>
    </div>
  )
}
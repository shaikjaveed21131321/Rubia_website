import './Property1Frame1261.css'

export default function Property1Frame1261() {
  return (
    <div className="property-1-frame-126">
      <img className="group-92" src="assets/vectors/Group9218_x2.svg" />
      <div className="frame-125">
        <span className="rent">
        Rent
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-2" src="assets/vectors/Vector598_x2.svg" />
        </div>
      </div>
    </div>
  )
}
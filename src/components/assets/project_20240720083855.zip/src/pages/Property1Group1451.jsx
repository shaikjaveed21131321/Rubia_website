import './Property1Group1451.css'

export default function Property1Group1451() {
  return (
    <div className="property-1-group-145">
      <span className="filters">
      Filters
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector337_x2.svg" />
      </div>
    </div>
  )
}
import './Property1Component183.css'

export default function Property1Component183() {
  return (
    <div className="property-1-component-18">
      <div className="rectangle-72">
      </div>
      <span className="sanchari">
      Sanchari
      </span>
    </div>
  )
}
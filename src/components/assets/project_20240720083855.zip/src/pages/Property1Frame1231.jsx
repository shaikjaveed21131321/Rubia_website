import './Property1Frame1231.css'

export default function Property1Frame1231() {
  return (
    <div className="property-1-frame-123">
      <div className="mdipeople-add">
        <img className="vector" src="assets/vectors/Vector171_x2.svg" />
      </div>
      <span className="my-network">
      My Network
      </span>
    </div>
  )
}
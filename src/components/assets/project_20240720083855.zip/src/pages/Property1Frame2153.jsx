import './Property1Frame2153.css'

export default function Property1Frame2153() {
  return (
    <div className="property-1-frame-215">
      <div className="group-136">
        <span className="posted-by">
        Posted By
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector" src="assets/vectors/Vector552_x2.svg" />
        </div>
      </div>
      <div className="group-134">
        <div className="posted-by-1">
        Posted By
        </div>
        <div className="component-13">
          <span className="independent-house">
          Owner
          </span>
        </div>
        <div className="component-17">
          <span className="independent-house-1">
          Agent
          </span>
        </div>
        <div className="component-18">
          <span className="independent-house-2">
          Builder
          </span>
        </div>
        <div className="done">
          <span className="done-1">
          Done
          </span>
        </div>
      </div>
    </div>
  )
}
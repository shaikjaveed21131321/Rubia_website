import './FlowbitehomeSolid.css'

export default function FlowbitehomeSolid() {
  return (
    <div className="flowbitehome-solid">
      <img className="vector" src="assets/vectors/Vector285_x2.svg" />
    </div>
  )
}
import './Page.css'

export default function Page() {
  return (
    <div className="container">
      <div className="container">
        <div className="under-50-lac">
          <div className="property-1-frame-1762">
            <p className="under-50-lac-1">
            <span className="under-50-lac-1-sub-0"></span><span className="under-50-lac-1-sub-10"></span><span></span>
            </p>
          </div>
          <div className="property-1-frame-1813">
            <p className="under-50-lac-2">
            <span className="under-50-lac-2-sub-0"></span><span className="under-50-lac-2-sub-6"></span><span></span>
            </p>
          </div>
        </div>
        <div className="cr-15-cr">
          <div className="property-1-frame-176">
            <p className="cr-15-cr-1">
            <span className="cr-15-cr-1-sub-6"></span><span></span>
            </p>
          </div>
          <div className="property-1-frame-1811">
            <span className="cr-15-cr-2">
            1cr - 15cr
            </span>
          </div>
        </div>
      </div>
      <div className="container-1">
        <div className="under-50-lac-3">
          <div className="property-1-frame-1763">
            <p className="lac-1-cr-1">
            <span className="lac-1-cr-1-sub-6"></span><span></span>
            </p>
          </div>
          <div className="property-1-frame-181">
            <p className="lac-1-cr">
            <span className="lac-1-cr-sub-7"></span><span></span>
            </p>
          </div>
        </div>
        <div className="cr-15-cr-3">
          <div className="property-1-frame-1761">
            <p className="above-15-cr">
            <span className="above-15-cr-sub-0"></span><span className="above-15-cr-sub-6"></span><span></span>
            </p>
          </div>
          <div className="property-1-frame-1812">
            <p className="above-15-cr-1">
            <span className="above-15-cr-1-sub-0"></span><span className="above-15-cr-1-sub-7"></span><span></span>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
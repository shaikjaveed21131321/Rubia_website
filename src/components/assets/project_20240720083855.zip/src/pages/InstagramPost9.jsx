import './InstagramPost9.css'

export default function InstagramPost9() {
  return (
    <div className="instagram-post-9">
      <div className="image-3">
      </div>
      <div className="container">
        <div className="happy-international-yoga-day">
        Happy<br />
        International yoga<br />
        Day
        </div>
        <img className="mask-group" src="assets/vectors/MaskGroup24_x2.svg" />
        <div className="image-11">
        </div>
      </div>
      <div className="image-6">
      </div>
      <div className="image-15">
      </div>
    </div>
  )
}
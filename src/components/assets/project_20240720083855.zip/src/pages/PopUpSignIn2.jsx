import './PopUpSignIn2.css'

export default function PopUpSignIn2() {
  return (
    <div className="pop-up-sign-in">
      <div className="container-3">
        <div className="sign-in">
        Sign in
        </div>
        <div className="are-you">
        Are you
        </div>
        <div className="component-11">
          <div className="group-114">
            <div className="group-108">
              <div className="ellipse-15">
              </div>
            </div>
            <div className="buyer">
            Buyer
            </div>
          </div>
          <div className="group-112">
            <div className="group-109">
              <div className="ellipse-151">
              </div>
            </div>
            <div className="owner">
            Owner
            </div>
          </div>
          <div className="group-111">
            <div className="group-110">
              <div className="ellipse-152">
              </div>
            </div>
            <div className="agent">
            Agent
            </div>
          </div>
          <div className="group-113">
            <div className="group-1101">
              <div className="ellipse-153">
              </div>
            </div>
            <div className="builder">
            Builder
            </div>
          </div>
        </div>
        <div className="group-105">
          <div className="container-2">
            <span className="enter-your-mobile-number-here">
            Enter your Mobile number here
            </span>
          </div>
          <div className="frame-142">
            <span className="mobile-number">
            Mobile Number
            </span>
          </div>
        </div>
        <div className="group-106">
          <div className="container">
            <span className="enter-your-email-id-here">
            Enter your email id here
            </span>
          </div>
          <div className="frame-1421">
            <span className="email-id">
            Email id
            </span>
          </div>
        </div>
        <div className="group-107">
          <div className="container-1">
            <span className="minimum-6-characters">
            Minimum 6 characters
            </span>
          </div>
          <div className="frame-1422">
            <span className="password">
            Password
            </span>
          </div>
        </div>
        <div className="frame-178">
          <span className="continue">
          Continue
          </span>
        </div>
        <div className="frame-190">
          <span className="dont-have-an-account">
          Don’t have an account? 
          </span>
          <span className="sign-up">
          Sign up
          </span>
        </div>
      </div>
      <span className="forgot-possword">
      Forgot Possword
      </span>
    </div>
  )
}
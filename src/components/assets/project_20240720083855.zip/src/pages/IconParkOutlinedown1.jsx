import './IconParkOutlinedown1.css'

export default function IconParkOutlinedown1() {
  return (
    <div className="icon-park-outlinedown">
      <img className="vector" src="assets/vectors/Vector193_x2.svg" />
    </div>
  )
}
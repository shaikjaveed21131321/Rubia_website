import './Property1Rectangle115.css'

export default function Property1Rectangle115() {
  return (
    <div className="property-1-rectangle-115">
      <div className="rectangle-115">
      </div>
    </div>
  )
}
import './Property1Default14.css'

export default function Property1Default14() {
  return (
    <div className="property-1-default">
      <img className="group-94" src="assets/vectors/Group942_x2.svg" />
      <div className="frame-126">
        <span className="home-loans">
        Home Loans
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-3" src="assets/vectors/Vector631_x2.svg" />
        </div>
      </div>
    </div>
  )
}
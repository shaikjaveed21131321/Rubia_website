import './Property1Frame1386.css'

export default function Property1Frame1386() {
  return (
    <div className="property-1-frame-138">
      <span className="ev-bikes">
       EV Bikes
      </span>
    </div>
  )
}
import './JobPortal3.css'

export default function JobPortal3() {
  return (
    <div className="job-portal">
      <div className="container-1">
        <div className="group-101">
        </div>
        <div className="frame-4">
          <span className="home">
          HOME
          </span>
          <span className="services">
          SERVICES
          </span>
          <span className="about-us">
          ABOUT US
          </span>
          <span className="contact-us">
          CONTACT US
          </span>
          <span className="blog">
          BLOG
          </span>
        </div>
      </div>
      <div className="container-14">
        <div className="group-89">
          <div className="frame-12">
            <span className="we-provide">
            We Provide
            </span>
          </div>
          <div className="frame-3">
            <span className="drivers">
            DRIVERS
            </span>
          </div>
          <div className="frame-7">
            <span className="graphic-designing">
            GRAPHIC DESIGNING
            </span>
          </div>
          <div className="frame-6">
            <span className="software">
            SOFTWARE
            </span>
          </div>
          <div className="frame-8">
            <span className="digital-marketing">
            DIGITAL MARKETING
            </span>
          </div>
          <div className="frame-15">
            <span className="ux-ui-designing">
            UX/UI Designing
            </span>
          </div>
          <div className="frame-114">
            <span className="taxi">
            TAXI
            </span>
          </div>
          <div className="frame-115">
            <span className="job-portal-1">
            JOB PORTAL
            </span>
          </div>
          <div className="frame-116">
            <span className="real-estate">
            REAL ESTATE
            </span>
          </div>
        </div>
        <div className="container-13">
          <div className="container-3">
            <div className="frame-123">
              <div className="heroiconshome-solid">
                <img className="group-3" src="assets/vectors/Group15_x2.svg" />
              </div>
              <span className="home-2">
              Home
              </span>
            </div>
            <div className="search">
              <div className="icbaseline-search-1">
                <img className="vector-31" src="assets/vectors/Vector346_x2.svg" />
              </div>
              <span className="search-1">
              Search
              </span>
            </div>
            <div className="jobs">
              <div className="basilbag-solid">
                <img className="vector-28" src="assets/vectors/Vector439_x2.svg" />
                <img className="vector-29" src="assets/vectors/Vector45_x2.svg" />
              </div>
              <span className="jobs-1">
              Jobs
              </span>
            </div>
            <div className="my-network">
              <div className="mdipeople-add">
                <img className="vector-18" src="assets/vectors/Vector412_x2.svg" />
              </div>
              <span className="my-network-1">
              My Network
              </span>
            </div>
            <div className="message">
              <div className="lets-iconsmessage-fill">
                <img className="vector-19" src="assets/vectors/Vector391_x2.svg" />
              </div>
              <span className="messages">
              Messages
              </span>
            </div>
            <div className="profile-1">
              <div className="ellipse-14">
              </div>
              <div className="frame-176">
                <span className="profile-2">
                Profile
                </span>
                <div className="teenyiconsdown-solid">
                  <img className="vector-30" src="assets/vectors/Vector399_x2.svg" />
                </div>
              </div>
            </div>
          </div>
          <div className="ready-to-find-your-dream-job-now">
          Ready  to Find your Dream Job Now
          </div>
          <div className="search-bar">
            <div className="container-9">
              <div className="icbaseline-search">
                <img className="vector-14" src="assets/vectors/Vector600_x2.svg" />
              </div>
              <span className="search-job-by">
              Search job by
              </span>
              <div className="component-3">
                <span className="skill">
                ‘Skill’
                </span>
              </div>
            </div>
            <div className="container-4">
              <div className="rectangle-46">
              </div>
              <div className="weuilocation-outlined">
                <img className="vector-15" src="assets/vectors/Vector592_x2.svg" />
              </div>
              <div className="anywhere-in-india">
              Anywhere in India
              </div>
            </div>
            <div className="frame-126">
              <span className="search-jobs">
              Search Jobs
              </span>
            </div>
          </div>
          <div className="frame-196">
            <div className="vera-sudhakar-rao">
              <div className="profile">
                <div className="container-8">
                  <div className="group-95">
                    <div className="rectangle-50">
                    </div>
                    <span className="hiring">
                    #Hiring
                    </span>
                  </div>
                  <div className="container-11">
                    <div className="sampras-singh-1">
                    Veera sudhakar rao 
                    </div>
                    <div className="rubia-services-recruiter">
                    Rubia.services Recruiter
                    </div>
                    <p className="remote-internship-alertrubia-services-read-more">
                    <span className="remote-internship-alertrubia-services-read-more-sub-0"></span><span></span>
                    </p>
                  </div>
                </div>
                <div className="container-6">
                  <div className="hr-ago">
                  1hr ago
                  </div>
                  <div className="frame-127">
                    <span className="follow">
                    Follow
                    </span>
                  </div>
                </div>
              </div>
              <div className="group-104">
                <div className="image-8">
                </div>
              </div>
              <div className="component-7">
                <div className="container">
                  <span className="likes">
                  1203 likes
                  </span>
                  <span className="comments">
                  1203 Comments
                  </span>
                </div>
                <div className="rectangle-53">
                </div>
                <div className="frame-172">
                  <div className="frame-128">
                    <div className="mdilike-outline">
                      <img className="vector-20" src="assets/vectors/Vector556_x2.svg" />
                    </div>
                    <div className="like">
                    Like
                    </div>
                  </div>
                  <div className="frame-129">
                    <div className="material-symbolscomment-outline">
                      <img className="vector-21" src="assets/vectors/Vector431_x2.svg" />
                    </div>
                    <div className="comment">
                    Comment
                    </div>
                  </div>
                  <div className="frame-130">
                    <div className="material-symbolsshare">
                      <img className="vector-22" src="assets/vectors/Vector106_x2.svg" />
                    </div>
                    <div className="share">
                    Share
                    </div>
                  </div>
                  <div className="frame-131">
                    <div className="fluentsave-copy-20-filled">
                      <img className="vector-23" src="assets/vectors/Vector154_x2.svg" />
                    </div>
                    <div className="save">
                    Save
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="sampras-singh">
              <div className="singh">
                <div className="container-2">
                  <div className="group-951">
                    <div className="rectangle-501">
                    </div>
                    <span className="job-seeker">
                    #Job seeker
                    </span>
                  </div>
                  <div className="container-12">
                    <div className="sampras-singh-2">
                    Sampras singh
                    </div>
                    <div className="ui-ux-designer">
                    UI/UX Designer
                    </div>
                    <p className="remote-internship-alertrubia-services-read-more-1">
                    <span className="remote-internship-alertrubia-services-read-more-1-sub-0"></span><span></span>
                    </p>
                  </div>
                </div>
                <div className="container-5">
                  <div className="hr-ago-1">
                  1hr ago
                  </div>
                  <div className="frame-1271">
                    <span className="follow-1">
                    Follow
                    </span>
                  </div>
                </div>
              </div>
              <div className="group-1041">
                <div className="rectangle-511">
                </div>
              </div>
              <div className="component-71">
                <div className="container-7">
                  <span className="likes-1">
                  120 likes
                  </span>
                  <span className="comments-1">
                  123 Comments
                  </span>
                </div>
                <div className="rectangle-531">
                </div>
                <div className="frame-1721">
                  <div className="frame-1281">
                    <div className="mdilike-outline-1">
                      <img className="vector-24" src="assets/vectors/Vector434_x2.svg" />
                    </div>
                    <div className="like-1">
                    Like
                    </div>
                  </div>
                  <div className="frame-1291">
                    <div className="material-symbolscomment-outline-1">
                      <img className="vector-25" src="assets/vectors/Vector117_x2.svg" />
                    </div>
                    <div className="comment-1">
                    Comment
                    </div>
                  </div>
                  <div className="frame-1301">
                    <div className="material-symbolsshare-1">
                      <img className="vector-26" src="assets/vectors/Vector92_x2.svg" />
                    </div>
                    <div className="share-1">
                    Share
                    </div>
                  </div>
                  <div className="frame-1311">
                    <div className="fluentsave-copy-20-filled-1">
                      <img className="vector-27" src="assets/vectors/Vector707_x2.svg" />
                    </div>
                    <div className="save-1">
                    Save
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="frame-31">
            <div className="download-the-mobile-app-now">
            Download the Mobile App Now
            </div>
            <div className="frame-30">
              <div className="frame-29">
                <div className="qr-code">
                  <img className="vector-11" src="assets/vectors/Vector157_x2.svg" />
                </div>
                <div className="image-260-nw-23151053071">
                </div>
              </div>
              <div className="frame-28">
                <div className="qr-code-1">
                  <img className="vector-13" src="assets/vectors/Vector640_x2.svg" />
                </div>
                <div className="image-260-nw-23151053072">
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="group-90">
          <div className="rectangle-29">
          </div>
          <div className="rectangle-30">
          </div>
          <div className="rectangle-31">
          </div>
          <div className="rectangle-32">
          </div>
        </div>
      </div>
      <div className="frame-27">
        <div className="container-10">
          <div className="frame-22">
            <div className="links">
            Links
            </div>
            <div className="frame-20">
              <div className="home-1">
              Home
              </div>
              <div className="about">
              About
              </div>
              <div className="service">
              Service
              </div>
              <span className="contact-us-1">
              Contact us
              </span>
            </div>
          </div>
          <div className="frame-21">
            <div className="info">
            Info
            </div>
            <div className="frame-201">
              <div className="terms-conditions">
              Terms &amp; Conditions
              </div>
              <div className="refund-policy">
              Refund policy
              </div>
              <span className="privacy-policy">
              Privacy policy
              </span>
            </div>
          </div>
          <div className="frame-19">
            <div className="address">
            Address
            </div>
            <div className="frame-18">
              <p className="registed-61105-saifabad-khairatabad-hyderabad-500004">
              <span className="registed-61105-saifabad-khairatabad-hyderabad-500004-sub-1"></span><span></span>
              </p>
              <p className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018">
              <span className="branch-metro-pillar-no-974-flat-no-107-rams-enclave-vikaspuri-erragadda-hyderabad-500018-sub-2"></span><span></span>
              </p>
            </div>
          </div>
        </div>
        <div className="frame-26">
          <div className="frame-24">
            <div className="contact-no">
            Contact No
            </div>
            <div className="frame-23">
              <div className="container">
              +91 78936 53899
              </div>
              <span className="inforubia-services">
              info@rubia.services
              </span>
            </div>
          </div>
          <div className="frame-25">
            <div className="skill-iconstwitter">
              <img className="group" src="assets/vectors/Group43_x2.svg" />
            </div>
            <div className="akar-iconsfacebook-fill">
              <img className="vector-3" src="assets/vectors/Vector521_x2.svg" />
            </div>
            <div className="skill-iconslinkedin">
              <img className="group-1" src="assets/vectors/Group27_x2.svg" />
            </div>
            <div className="skill-iconsinstagram">
              <img className="group-2" src="assets/vectors/Group70_x2.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
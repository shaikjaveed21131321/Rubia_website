import './Property1Group128.css'

export default function Property1Group128() {
  return (
    <div className="property-1-group-128">
      <span className="budget">
      Budget
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector462_x2.svg" />
      </div>
    </div>
  )
}
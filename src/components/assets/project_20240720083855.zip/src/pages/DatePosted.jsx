import './DatePosted.css'

export default function DatePosted() {
  return (
    <div className="date-posted">
      <div className="container-1">
        <div className="late-24-hours">
          <div className="property-1-frame-176">
            <span className="last-24-hours">
            Last 24 hours
            </span>
          </div>
          <div className="property-1-frame-177">
            <span className="last-24-hours-1">
            Last 24 hours
            </span>
          </div>
        </div>
        <div className="since-you-last-visit">
          <div className="property-1-frame-1762">
            <span className="since-you-last-visit-1">
            Since you last visit
            </span>
          </div>
          <div className="property-1-frame-1772">
            <span className="since-you-last-visit-2">
            Since you last visit
            </span>
          </div>
        </div>
      </div>
      <div className="container">
        <div className="late-03-days">
          <div className="property-1-frame-1761">
            <span className="last-03-days">
            Last 03 days
            </span>
          </div>
          <div className="property-1-frame-1771">
            <span className="last-03-days-1">
            Last 03 days
            </span>
          </div>
        </div>
        <div className="late-07-days">
          <div className="property-1-frame-1763">
            <span className="last-07-days">
            Last 07 days
            </span>
          </div>
          <div className="property-1-frame-1773">
            <span className="last-07-days-1">
            Last 07 days
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
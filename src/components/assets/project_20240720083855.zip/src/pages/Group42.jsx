import './Group42.css'

export default function Group42() {
  return (
    <div className="group-42">
      <img className="mask-group" src="assets/vectors/MaskGroup18_x2.svg" />
    </div>
  )
}
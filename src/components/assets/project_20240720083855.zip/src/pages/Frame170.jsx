import './Frame170.css'

export default function Frame170() {
  return (
    <div className="frame-170">
      <div className="image-44">
      </div>
      <img className="ellipse-3" src="assets/vectors/Ellipse3_x2.svg" />
      <div className="container">
        <div className="real-estate">
        Real estate
        </div>
        <div className="image-46">
        </div>
      </div>
      <div className="container-2">
        <div className="container-1">
          <div className="lands-buy-sell-and-const">
          Lands Buy,  Sell and Const....
          </div>
          <p className="ex-residence-hospitalscompaniesindustries-camarshieal-areas-and-etc">
          <span className="ex-residence-hospitalscompaniesindustries-camarshieal-areas-and-etc-sub-27"></span><span></span>
          </p>
          <div className="frame-171">
            <span className="view-more">
            View more
            </span>
          </div>
        </div>
        <div className="image-48">
        </div>
      </div>
    </div>
  )
}
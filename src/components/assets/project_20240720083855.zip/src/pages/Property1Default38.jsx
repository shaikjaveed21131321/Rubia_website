import './Property1Default38.css'

export default function Property1Default38() {
  return (
    <div className="property-1-default">
      <div className="mditv">
        <img className="vector" src="assets/vectors/Vector639_x2.svg" />
      </div>
      <div className="moter-cycle">
        <span className="electronic-appliances">
        Electronic Appliances
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-1" src="assets/vectors/Vector617_x2.svg" />
        </div>
      </div>
    </div>
  )
}
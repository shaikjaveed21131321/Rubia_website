import './Frame169.css'

export default function Frame169() {
  return (
    <div className="frame-169">
      <div className="image-47">
      </div>
      <img className="ellipse-5" src="assets/vectors/Ellipse5_x2.svg" />
      <div className="container-2">
        <div className="container">
          <div className="real-estate">
          Real estate
          </div>
          <div className="image-46">
          </div>
        </div>
        <div className="lands-buy-sell-and-const">
        Lands Buy,  Sell and Const....
        </div>
        <div className="frame-171">
          <span className="view-more">
          View more
          </span>
        </div>
        <div className="container-1">
          <p className="ex-residence-hospitalscompaniesindustries-camarshieal-areas-and-etc">
          <span className="ex-residence-hospitalscompaniesindustries-camarshieal-areas-and-etc-sub-27"></span><span></span>
          </p>
        </div>
      </div>
      <div className="image-45">
      </div>
    </div>
  )
}
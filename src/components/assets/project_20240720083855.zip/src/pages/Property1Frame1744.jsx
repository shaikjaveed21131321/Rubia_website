import './Property1Frame1744.css'

export default function Property1Frame1744() {
  return (
    <div className="property-1-frame-174">
      <span className="sign-in">
      Sign in
      </span>
      <div className="mingcutedown-fill">
        <img className="vector" src="assets/vectors/Vector549_x2.svg" />
      </div>
    </div>
  )
}
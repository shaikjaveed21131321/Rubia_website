import './Property1Default10.css'

export default function Property1Default10() {
  return (
    <div className="property-1-default">
      <img className="group-92" src="assets/vectors/Group928_x2.svg" />
      <div className="frame-125">
        <span className="rent">
        Rent
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-2" src="assets/vectors/Vector136_x2.svg" />
        </div>
      </div>
    </div>
  )
}
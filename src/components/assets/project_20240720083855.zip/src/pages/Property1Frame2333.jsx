import './Property1Frame2333.css'

export default function Property1Frame2333() {
  return (
    <div className="property-1-frame-233">
      <div className="hugeiconsjob-search">
        <img className="group" src="assets/vectors/Group5_x2.svg" />
      </div>
      <span className="applied-jobs">
      Applied Jobs
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector534_x2.svg" />
      </div>
    </div>
  )
}
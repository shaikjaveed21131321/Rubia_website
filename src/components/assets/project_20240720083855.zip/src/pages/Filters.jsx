import './Filters.css'

export default function Filters() {
  return (
    <div className="filters">
      <div className="container-7">
        <div className="covered-areasqft">
        Covered Area (sqft)
        </div>
        <div className="group-143">
          <div className="group-141">
            <span className="min">
            Min
            </span>
            <div className="group">
              <img className="vector" src="assets/vectors/Vector341_x2.svg" />
            </div>
          </div>
          <div className="group-137">
            <span className="max">
            Max
            </span>
            <div className="group-1">
              <img className="vector-1" src="assets/vectors/Vector723_x2.svg" />
            </div>
          </div>
        </div>
        <div className="group-142">
          <div className="container-2">
            <div className="group-139">
              <span className="container">
              0
              </span>
            </div>
            <div className="group-138">
              <span className="cr">
              ₹ 5cr
              </span>
            </div>
          </div>
          <img className="group-140" src="assets/vectors/Group1407_x2.svg" />
        </div>
      </div>
      <div className="possession-status">
      Possession Status
      </div>
      <div className="container-4">
        <div className="component-18">
          <span className="independent-house">
          Ready To Move
          </span>
        </div>
        <div className="component-19">
          <span className="independent-house-13">
          Under Construction
          </span>
        </div>
        <div className="component-20">
          <span className="independent-house-14">
          New Launch
          </span>
        </div>
      </div>
      <div className="rectangle-109">
      </div>
      <div className="purchase-type">
      Purchase type
      </div>
      <div className="container-5">
        <div className="component-21">
          <span className="independent-house-1">
          Resale
          </span>
        </div>
        <div className="component-22">
          <span className="independent-house-10">
          New Booking
          </span>
        </div>
      </div>
      <div className="rectangle-110">
      </div>
      <div className="furnishing">
      Furnishing
      </div>
      <div className="container-6">
        <div className="component-23">
          <span className="independent-house-2">
          Furnishing
          </span>
        </div>
        <div className="component-24">
          <span className="independent-house-12">
          Semi-Furnished
          </span>
        </div>
        <div className="component-25">
          <span className="independent-house-11">
          Unfurnished
          </span>
        </div>
      </div>
      <div className="rectangle-111">
      </div>
      <div className="amenities">
      Amenities
      </div>
      <div className="container">
        <div className="component-26">
          <span className="independent-house-3">
          Parking
          </span>
        </div>
        <div className="component-27">
          <span className="independent-house-4">
          Power Backup
          </span>
        </div>
        <div className="component-28">
          <span className="independent-house-5">
          Lift
          </span>
        </div>
        <div className="component-29">
          <span className="independent-house-6">
          Park
          </span>
        </div>
      </div>
      <div className="container-3">
        <div className="component-30">
          <span className="independent-house-7">
          Swimming Pool
          </span>
        </div>
        <div className="component-31">
          <span className="independent-house-8">
          Club house
          </span>
        </div>
        <div className="component-32">
          <span className="independent-house-9">
          Security Personnel
          </span>
        </div>
      </div>
      <div className="container-1">
        <div className="photos-videos">
        Photos &amp; Videos
        </div>
        <div className="component-33">
          <div className="ellipse-21">
          </div>
        </div>
      </div>
    </div>
  )
}
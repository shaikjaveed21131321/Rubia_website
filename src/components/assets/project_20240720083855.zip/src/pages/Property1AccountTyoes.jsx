import './Property1AccountTyoes.css'

export default function Property1AccountTyoes() {
  return (
    <div className="property-1-account-tyoes">
      <span className="select-rang">
      Select rang
      </span>
      <div className="mingcutedown-line">
        <img className="vector" src="assets/vectors/Vector720_x2.svg" />
      </div>
    </div>
  )
}
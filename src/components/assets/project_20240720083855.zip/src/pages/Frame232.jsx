import './Frame232.css'

export default function Frame232() {
  return (
    <div className="frame-232">
      <span className="create-apost">
      Create a post
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector718_x2.svg" />
      </div>
    </div>
  )
}
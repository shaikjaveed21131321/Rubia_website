import './Property1Frame1791.css'

export default function Property1Frame1791() {
  return (
    <div className="property-1-frame-179">
      <div className="chinnu">
        <img className="group-91" src="assets/vectors/Group917_x2.svg" />
        <div className="frame-124">
          <span className="buy">
          Buy
          </span>
          <div className="teenyiconsdown-solid">
            <img className="vector-6" src="assets/vectors/Vector3_x2.svg" />
          </div>
        </div>
      </div>
      <div className="group-118">
        <div className="container">
          <div className="frame-176">
            <span className="residential">
            Residential
            </span>
          </div>
          <div className="frame-177">
            <span className="commercial">
            Commercial
            </span>
          </div>
          <div className="frame-178">
            <span className="plots-1">
            Plots
            </span>
          </div>
        </div>
        <div className="container-1">
          <div className="flates">
            <span className="flates-1">
            Independent House
            </span>
          </div>
          <div className="under-50-lac-1">
            <span className="under-50-lac-3">
            Independent House
            </span>
          </div>
          <div className="under-50-lac-2">
            <span className="under-50-lac-4">
            Open plots
            </span>
          </div>
        </div>
        <div className="container-2">
          <div className="house">
            <span className="house-1">
            duplex house 
            </span>
          </div>
          <div className="cr-15-cr">
            <span className="cr-15-cr-1">
            Duplex house 
            </span>
          </div>
        </div>
        <div className="container-3">
          <div className="plots">
            <span className="plots-2">
            Triplex house
            </span>
          </div>
          <div className="under-50-lac">
            <span className="lac-1-cr">
            Triplex house
            </span>
          </div>
        </div>
        <div className="villas">
          <span className="villas-1">
          Independent flates
          </span>
        </div>
        <div className="office-space">
          <span className="office-space-2">
          duplex flates
          </span>
        </div>
        <div className="office-space-1">
          <span className="office-space-3">
          Triplex flates
          </span>
        </div>
      </div>
    </div>
  )
}
import './Property1Frame2355.css'

export default function Property1Frame2355() {
  return (
    <div className="property-1-frame-235">
      <div className="simple-line-iconsuser-following">
        <img className="vector-1" src="assets/vectors/Vector77_x2.svg" />
      </div>
      <span className="following">
      Following
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector" src="assets/vectors/Vector100_x2.svg" />
      </div>
    </div>
  )
}
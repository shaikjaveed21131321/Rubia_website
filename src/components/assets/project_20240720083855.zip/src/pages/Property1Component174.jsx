import './Property1Component174.css'

export default function Property1Component174() {
  return (
    <div className="property-1-component-17">
      <div className="rectangle-72">
      </div>
      <span className="game-app">
      Game app
      </span>
    </div>
  )
}
import './Property1Frame1372.css'

export default function Property1Frame1372() {
  return (
    <div className="property-1-frame-137">
      <span className="motor-cycles">
      Motor cycles
      </span>
    </div>
  )
}
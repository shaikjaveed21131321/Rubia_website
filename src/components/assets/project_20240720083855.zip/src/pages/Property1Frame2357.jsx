import './Property1Frame2357.css'

export default function Property1Frame2357() {
  return (
    <div className="property-1-frame-235">
      <div className="fluent-mdl-2-group">
        <img className="vector" src="assets/vectors/Vector284_x2.svg" />
      </div>
      <span className="groups">
      Groups
      </span>
      <div className="teenyiconsdown-solid">
        <img className="vector-1" src="assets/vectors/Vector733_x2.svg" />
      </div>
    </div>
  )
}
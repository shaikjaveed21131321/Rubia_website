import './Property1No11.css'

export default function Property1No11() {
  return (
    <div className="property-1-no-1">
      <div className="image-3">
      </div>
      <div className="rectangle-124">
      </div>
      <div className="rectangle-28">
      </div>
      <div className="ellipse-4">
      </div>
      <div className="ellipse-5">
      </div>
    </div>
  )
}
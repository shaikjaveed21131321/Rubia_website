import './Property1Frame128.css'

export default function Property1Frame128() {
  return (
    <div className="property-1-frame-128">
      <img className="group-94" src="assets/vectors/Group94_x2.svg" />
      <div className="frame-126">
        <span className="home-loans">
        Home Loans
        </span>
        <div className="teenyiconsdown-solid">
          <img className="vector-3" src="assets/vectors/Vector128_x2.svg" />
        </div>
      </div>
    </div>
  )
}
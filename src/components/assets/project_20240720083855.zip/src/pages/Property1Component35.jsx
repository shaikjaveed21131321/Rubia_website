import './Property1Component35.css'

export default function Property1Component35() {
  return (
    <div className="property-1-component-35">
      <div className="rectangle-114">
      </div>
    </div>
  )
}
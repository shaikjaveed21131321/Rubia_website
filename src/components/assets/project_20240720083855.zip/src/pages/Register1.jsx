import './Register1.css'

export default function Register1() {
  return (
    <div className="register">
      <div className="employers-sign-up">
      Employers  Sign Up
      </div>
      <div className="enter-your-mobile-number-email-id-for-create-aaccount">
      Enter your mobile number &amp; Email id for Create a Account 
      </div>
      <div className="container-1">
        <div className="frame-188">
          <div className="name">
          Name
          </div>
          <div className="frame-11">
            <span className="first-name">
            First name
            </span>
          </div>
        </div>
        <div className="frame-189">
          <div className="frame-12">
            <span className="last-name">
            Last name
            </span>
          </div>
        </div>
      </div>
      <div className="container-2">
        <div className="frame-1881">
          <div className="email-id">
          Email id
          </div>
          <div className="frame-13">
            <span className="enter-your-email-id-here">
            Enter your email id here
            </span>
          </div>
        </div>
        <div className="frame-187">
          <div className="mobile-number">
          Mobile Number
          </div>
          <div className="frame-1">
            <img className="emojione-v-1-flag-for-india" src="assets/vectors/EmojioneV1FlagForIndia2_x2.svg" />
            <div className="container">
            +91
            </div>
            <div className="enter-your-10-digit-mobile-number">
            Enter your 10 digit Mobile number 
            </div>
          </div>
        </div>
      </div>
      <div className="container-5">
        <div className="frame-197">
          <div className="account-types">
          Account Types
          </div>
          <div className="account-tyoes">
            <span className="account-type">
            Account Type
            </span>
            <div className="mingcutedown-line">
              <img className="vector-6" src="assets/vectors/Vector684_x2.svg" />
            </div>
          </div>
        </div>
        <div className="frame-198">
          <div className="company-name">
          Company Name
          </div>
          <div className="frame-14">
            <span className="enter-your-company-name">
            Enter your Company Name
            </span>
          </div>
        </div>
      </div>
      <div className="container-4">
        <div className="frame-199">
          <div className="designation">
          Designation
          </div>
          <div className="frame-15">
            <span className="enter-your-designation">
            Enter your Designation
            </span>
          </div>
        </div>
        <div className="frame-200">
          <div className="city">
          City
          </div>
          <div className="frame-16">
            <span className="enter-your-city">
            Enter your City
            </span>
          </div>
        </div>
      </div>
      <div className="container-3">
        <div className="frame-241">
          <div className="no-of-employees">
          No. of Employees
          </div>
          <div className="select-rang">
            <span className="select-rang-1">
            Select rang
            </span>
            <div className="mingcutedown-line-1">
              <img className="vector-7" src="assets/vectors/Vector163_x2.svg" />
            </div>
          </div>
        </div>
        <div className="frame-2011">
          <div className="gst-number">
          GST Number
          </div>
          <div className="frame-18">
            <span className="enter-your-gst-number">
            Enter your GST number
            </span>
          </div>
        </div>
      </div>
      <div className="container">
        <div className="frame-201">
          <div className="create-password">
          Create Password
          </div>
          <div className="frame-17">
            <span className="create-password-1">
            Create Password
            </span>
          </div>
        </div>
        <div className="frame-242">
          <div className="reenter-password">
          Reenter Password
          </div>
          <div className="frame-19">
            <span className="reenter-password-1">
            Reenter Password
            </span>
          </div>
        </div>
      </div>
      <div className="frame-178">
        <span className="submit">
        Submit
        </span>
      </div>
      <div className="frame-190">
        <span className="already-have-an-account">
        Already have an account
        </span>
        <span className="sign-in">
        Sign in
        </span>
      </div>
    </div>
  )
}
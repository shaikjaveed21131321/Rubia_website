import './Property1Group1171.css'

export default function Property1Group1171() {
  return (
    <div className="property-1-group-117">
      <div className="rectangle-72">
      </div>
      <span className="game-screen-ui">
      Game screen Ui
      </span>
    </div>
  )
}
import './Property1Default2.css'

export default function Property1Default2() {
  return (
    <div className="property-1-default">
      <span className="employers-sign-in">
      Employers  Sign in
      </span>
    </div>
  )
}
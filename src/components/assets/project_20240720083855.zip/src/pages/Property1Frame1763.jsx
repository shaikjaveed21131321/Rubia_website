import './Property1Frame1763.css'

export default function Property1Frame1763() {
  return (
    <div className="property-1-frame-176">
      <div className="account-tyoes">
        <span className="select-rang">
        Select rang
        </span>
        <div className="mingcutedown-line">
          <img className="vector" src="assets/vectors/Vector66_x2.svg" />
        </div>
      </div>
      <div className="group-111">
        <div className="container">
          <span className="container-5">
          15_100
          </span>
        </div>
        <div className="container-1">
          <span className="container-6">
          101_200
          </span>
        </div>
        <div className="container-2">
          <span className="container-7">
          201_1000
          </span>
        </div>
        <div className="container-3">
          <span className="container-8">
          1001_10000
          </span>
        </div>
        <div className="container-4">
          <span className="container-9">
          &gt;10000
          </span>
        </div>
      </div>
    </div>
  )
}
import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './index.css';
import F12Main from './F12Main';

import AccountType from './pages/AccountType';
import AndroidLarge1 from './pages/AndroidLarge1';
import Buy from './pages/Buy';
import Component1 from './pages/Component1';
import Component11 from './pages/Component11';
import Component3 from './pages/Component3';
import Component5 from './pages/Component5';
import DatePosted from './pages/DatePosted';
import Elgroup from './pages/Elgroup';
import Fcc from './pages/Fcc';
import Filters from './pages/Filters';
import FlowbitehomeSolid from './pages/FlowbitehomeSolid';
import Frame117 from './pages/Frame117';
import Frame123 from './pages/Frame123';
import Frame124 from './pages/Frame124';
import Frame1241 from './pages/Frame1241';
import Frame127 from './pages/Frame127';
import Frame1271 from './pages/Frame1271';
import Frame136 from './pages/Frame136';
import Frame168 from './pages/Frame168';
import Frame169 from './pages/Frame169';
import Frame170 from './pages/Frame170';
import Frame176 from './pages/Frame176';
import Frame1761 from './pages/Frame1761';
import Frame177 from './pages/Frame177';
import Frame1771 from './pages/Frame1771';
import Frame178 from './pages/Frame178';
import Frame195 from './pages/Frame195';
import Frame213 from './pages/Frame213';
import Frame214 from './pages/Frame214';
import Frame215 from './pages/Frame215';
import Frame216 from './pages/Frame216';
import Frame2161 from './pages/Frame2161';
import Frame232 from './pages/Frame232';
import Frame2321 from './pages/Frame2321';
import Frame234 from './pages/Frame234';
import Frame237 from './pages/Frame237';
import Frame243 from './pages/Frame243';
import Gadgets from './pages/Gadgets';
import Group100 from './pages/Group100';
import Group101 from './pages/Group101';
import Group117 from './pages/Group117';
import Group119 from './pages/Group119';
import Group120 from './pages/Group120';
import Group1201 from './pages/Group1201';
import Group121 from './pages/Group121';
import Group122 from './pages/Group122';
import Group1221 from './pages/Group1221';
import Group123 from './pages/Group123';
import Group1231 from './pages/Group1231';
import Group124 from './pages/Group124';
import Group1241 from './pages/Group1241';
import Group1242 from './pages/Group1242';
import Group125 from './pages/Group125';
import Group128 from './pages/Group128';
import Group129 from './pages/Group129';
import Group168 from './pages/Group168';
import Group42 from './pages/Group42';
import Group89 from './pages/Group89';
import Group93 from './pages/Group93';
import Group97 from './pages/Group97';
import Group98 from './pages/Group98';
import HeroiconsbuildingOffice16Solid from './pages/HeroiconsbuildingOffice16Solid';
import IconParkOutlinedown from './pages/IconParkOutlinedown';
import IconParkOutlinedown1 from './pages/IconParkOutlinedown1';
import IconParkOutlinepeoples from './pages/IconParkOutlinepeoples';
import IcoutlinePeople from './pages/IcoutlinePeople';
import InstagramPost12 from './pages/InstagramPost12';
import InstagramPost13 from './pages/InstagramPost13';
import InstagramPost14 from './pages/InstagramPost14';
import InstagramPost2 from './pages/InstagramPost2';
import InstagramPost3 from './pages/InstagramPost3';
import InstagramPost5 from './pages/InstagramPost5';
import InstagramPost6 from './pages/InstagramPost6';
import InstagramPost7 from './pages/InstagramPost7';
import InstagramPost9 from './pages/InstagramPost9';
import IrqRwB31VqcenPfnZc35ZripVv11 from './pages/IrqRwB31VqcenPfnZc35ZripVv11';
import IruGsLt44Aoyq5Or3JhfmTxjw01 from './pages/IruGsLt44Aoyq5Or3JhfmTxjw01';
import IyumTiFgjb92PtpHeicdkmapk51 from './pages/IyumTiFgjb92PtpHeicdkmapk51';
import JobByCourse from './pages/JobByCourse';
import JobPage from './pages/JobPage';
import JobPage1 from './pages/JobPage1';
import JobPage2 from './pages/JobPage2';
import JobPage3 from './pages/JobPage3';
import JobPage4 from './pages/JobPage4';
import JobPage5 from './pages/JobPage5';
import JobPortal from './pages/JobPortal';
import JobPortal1 from './pages/JobPortal1';
import JobPortal2 from './pages/JobPortal2';
import JobPortal3 from './pages/JobPortal3';
import JobPortal4 from './pages/JobPortal4';
import JobPortal5 from './pages/JobPortal5';
import JobsComponent from './pages/JobsComponent';
import JobsFrame117 from './pages/JobsFrame117';
import LikeComment from './pages/LikeComment';
import Location from './pages/Location';
import MaskGroup from './pages/MaskGroup';
import Mdiheart from './pages/Mdiheart';
import MingcutedownFill from './pages/MingcutedownFill';
import Motorcycles from './pages/Motorcycles';
import NumOfEmploy from './pages/NumOfEmploy';
import OuimlCreateSingleMetricJob from './pages/OuimlCreateSingleMetricJob';
import Page from './pages/Page';
import PopUpSignIn from './pages/PopUpSignIn';
import PopUpSignIn1 from './pages/PopUpSignIn1';
import PopUpSignIn2 from './pages/PopUpSignIn2';
import PopUpSignIn3 from './pages/PopUpSignIn3';
import Profile from './pages/Profile';
import Profile1 from './pages/Profile1';
import Property1AccountTyoes from './pages/Property1AccountTyoes';
import Property1AutoMobile from './pages/Property1AutoMobile';
import Property1Buy from './pages/Property1Buy';
import Property1Chinnu from './pages/Property1Chinnu';
import Property1Company from './pages/Property1Company';
import Property1Component17 from './pages/Property1Component17';
import Property1Component171 from './pages/Property1Component171';
import Property1Component172 from './pages/Property1Component172';
import Property1Component173 from './pages/Property1Component173';
import Property1Component174 from './pages/Property1Component174';
import Property1Component175 from './pages/Property1Component175';
import Property1Component176 from './pages/Property1Component176';
import Property1Component18 from './pages/Property1Component18';
import Property1Component181 from './pages/Property1Component181';
import Property1Component182 from './pages/Property1Component182';
import Property1Component183 from './pages/Property1Component183';
import Property1Component184 from './pages/Property1Component184';
import Property1Component185 from './pages/Property1Component185';
import Property1Component35 from './pages/Property1Component35';
import Property1Default from './pages/Property1Default';
import Property1Default1 from './pages/Property1Default1';
import Property1Default10 from './pages/Property1Default10';
import Property1Default11 from './pages/Property1Default11';
import Property1Default12 from './pages/Property1Default12';
import Property1Default13 from './pages/Property1Default13';
import Property1Default14 from './pages/Property1Default14';
import Property1Default15 from './pages/Property1Default15';
import Property1Default16 from './pages/Property1Default16';
import Property1Default17 from './pages/Property1Default17';
import Property1Default18 from './pages/Property1Default18';
import Property1Default19 from './pages/Property1Default19';
import Property1Default2 from './pages/Property1Default2';
import Property1Default20 from './pages/Property1Default20';
import Property1Default21 from './pages/Property1Default21';
import Property1Default22 from './pages/Property1Default22';
import Property1Default23 from './pages/Property1Default23';
import Property1Default24 from './pages/Property1Default24';
import Property1Default25 from './pages/Property1Default25';
import Property1Default26 from './pages/Property1Default26';
import Property1Default27 from './pages/Property1Default27';
import Property1Default28 from './pages/Property1Default28';
import Property1Default29 from './pages/Property1Default29';
import Property1Default3 from './pages/Property1Default3';
import Property1Default30 from './pages/Property1Default30';
import Property1Default31 from './pages/Property1Default31';
import Property1Default32 from './pages/Property1Default32';
import Property1Default33 from './pages/Property1Default33';
import Property1Default34 from './pages/Property1Default34';
import Property1Default35 from './pages/Property1Default35';
import Property1Default36 from './pages/Property1Default36';
import Property1Default37 from './pages/Property1Default37';
import Property1Default38 from './pages/Property1Default38';
import Property1Default39 from './pages/Property1Default39';
import Property1Default4 from './pages/Property1Default4';
import Property1Default5 from './pages/Property1Default5';
import Property1Default6 from './pages/Property1Default6';
import Property1Default7 from './pages/Property1Default7';
import Property1Default8 from './pages/Property1Default8';
import Property1Default9 from './pages/Property1Default9';
import Property1Filter2 from './pages/Property1Filter2';
import Property1Filter3 from './pages/Property1Filter3';
import Property1Frame123 from './pages/Property1Frame123';
import Property1Frame1231 from './pages/Property1Frame1231';
import Property1Frame124 from './pages/Property1Frame124';
import Property1Frame1241 from './pages/Property1Frame1241';
import Property1Frame1242 from './pages/Property1Frame1242';
import Property1Frame125 from './pages/Property1Frame125';
import Property1Frame1251 from './pages/Property1Frame1251';
import Property1Frame126 from './pages/Property1Frame126';
import Property1Frame1261 from './pages/Property1Frame1261';
import Property1Frame1262 from './pages/Property1Frame1262';
import Property1Frame1263 from './pages/Property1Frame1263';
import Property1Frame127 from './pages/Property1Frame127';
import Property1Frame1271 from './pages/Property1Frame1271';
import Property1Frame1272 from './pages/Property1Frame1272';
import Property1Frame128 from './pages/Property1Frame128';
import Property1Frame1281 from './pages/Property1Frame1281';
import Property1Frame137 from './pages/Property1Frame137';
import Property1Frame1371 from './pages/Property1Frame1371';
import Property1Frame1372 from './pages/Property1Frame1372';
import Property1Frame1373 from './pages/Property1Frame1373';
import Property1Frame1374 from './pages/Property1Frame1374';
import Property1Frame1375 from './pages/Property1Frame1375';
import Property1Frame1376 from './pages/Property1Frame1376';
import Property1Frame1377 from './pages/Property1Frame1377';
import Property1Frame138 from './pages/Property1Frame138';
import Property1Frame1381 from './pages/Property1Frame1381';
import Property1Frame1382 from './pages/Property1Frame1382';
import Property1Frame1383 from './pages/Property1Frame1383';
import Property1Frame1384 from './pages/Property1Frame1384';
import Property1Frame1385 from './pages/Property1Frame1385';
import Property1Frame1386 from './pages/Property1Frame1386';
import Property1Frame1387 from './pages/Property1Frame1387';
import Property1Frame142 from './pages/Property1Frame142';
import Property1Frame174 from './pages/Property1Frame174';
import Property1Frame1741 from './pages/Property1Frame1741';
import Property1Frame1742 from './pages/Property1Frame1742';
import Property1Frame1743 from './pages/Property1Frame1743';
import Property1Frame1744 from './pages/Property1Frame1744';
import Property1Frame176 from './pages/Property1Frame176';
import Property1Frame1761 from './pages/Property1Frame1761';
import Property1Frame1762 from './pages/Property1Frame1762';
import Property1Frame1763 from './pages/Property1Frame1763';
import Property1Frame1764 from './pages/Property1Frame1764';
import Property1Frame1765 from './pages/Property1Frame1765';
import Property1Frame1766 from './pages/Property1Frame1766';
import Property1Frame1767 from './pages/Property1Frame1767';
import Property1Frame1768 from './pages/Property1Frame1768';
import Property1Frame177 from './pages/Property1Frame177';
import Property1Frame1771 from './pages/Property1Frame1771';
import Property1Frame1772 from './pages/Property1Frame1772';
import Property1Frame1773 from './pages/Property1Frame1773';
import Property1Frame1774 from './pages/Property1Frame1774';
import Property1Frame178 from './pages/Property1Frame178';
import Property1Frame1781 from './pages/Property1Frame1781';
import Property1Frame1782 from './pages/Property1Frame1782';
import Property1Frame179 from './pages/Property1Frame179';
import Property1Frame1791 from './pages/Property1Frame1791';
import Property1Frame1792 from './pages/Property1Frame1792';
import Property1Frame180 from './pages/Property1Frame180';
import Property1Frame1801 from './pages/Property1Frame1801';
import Property1Frame1802 from './pages/Property1Frame1802';
import Property1Frame1803 from './pages/Property1Frame1803';
import Property1Frame1804 from './pages/Property1Frame1804';
import Property1Frame1805 from './pages/Property1Frame1805';
import Property1Frame1806 from './pages/Property1Frame1806';
import Property1Frame1807 from './pages/Property1Frame1807';
import Property1Frame181 from './pages/Property1Frame181';
import Property1Frame184 from './pages/Property1Frame184';
import Property1Frame1841 from './pages/Property1Frame1841';
import Property1Frame1842 from './pages/Property1Frame1842';
import Property1Frame1843 from './pages/Property1Frame1843';
import Property1Frame1844 from './pages/Property1Frame1844';
import Property1Frame1845 from './pages/Property1Frame1845';
import Property1Frame215 from './pages/Property1Frame215';
import Property1Frame2151 from './pages/Property1Frame2151';
import Property1Frame2152 from './pages/Property1Frame2152';
import Property1Frame2153 from './pages/Property1Frame2153';
import Property1Frame2154 from './pages/Property1Frame2154';
import Property1Frame2155 from './pages/Property1Frame2155';
import Property1Frame217 from './pages/Property1Frame217';
import Property1Frame233 from './pages/Property1Frame233';
import Property1Frame2331 from './pages/Property1Frame2331';
import Property1Frame2332 from './pages/Property1Frame2332';
import Property1Frame2333 from './pages/Property1Frame2333';
import Property1Frame2334 from './pages/Property1Frame2334';
import Property1Frame2335 from './pages/Property1Frame2335';
import Property1Frame2336 from './pages/Property1Frame2336';
import Property1Frame2337 from './pages/Property1Frame2337';
import Property1Frame2338 from './pages/Property1Frame2338';
import Property1Frame235 from './pages/Property1Frame235';
import Property1Frame2351 from './pages/Property1Frame2351';
import Property1Frame2352 from './pages/Property1Frame2352';
import Property1Frame2353 from './pages/Property1Frame2353';
import Property1Frame2354 from './pages/Property1Frame2354';
import Property1Frame2355 from './pages/Property1Frame2355';
import Property1Frame2356 from './pages/Property1Frame2356';
import Property1Frame2357 from './pages/Property1Frame2357';
import Property1Frame2358 from './pages/Property1Frame2358';
import Property1Frame237 from './pages/Property1Frame237';
import Property1Frame2371 from './pages/Property1Frame2371';
import Property1Frame2372 from './pages/Property1Frame2372';
import Property1Frame2373 from './pages/Property1Frame2373';
import Property1Frame2374 from './pages/Property1Frame2374';
import Property1Frame238 from './pages/Property1Frame238';
import Property1Frame2381 from './pages/Property1Frame2381';
import Property1Frame2382 from './pages/Property1Frame2382';
import Property1Frame2383 from './pages/Property1Frame2383';
import Property1Group101 from './pages/Property1Group101';
import Property1Group1011 from './pages/Property1Group1011';
import Property1Group1012 from './pages/Property1Group1012';
import Property1Group102 from './pages/Property1Group102';
import Property1Group1021 from './pages/Property1Group1021';
import Property1Group104 from './pages/Property1Group104';
import Property1Group106 from './pages/Property1Group106';
import Property1Group1061 from './pages/Property1Group1061';
import Property1Group1062 from './pages/Property1Group1062';
import Property1Group107 from './pages/Property1Group107';
import Property1Group1071 from './pages/Property1Group1071';
import Property1Group109 from './pages/Property1Group109';
import Property1Group1091 from './pages/Property1Group1091';
import Property1Group110 from './pages/Property1Group110';
import Property1Group1101 from './pages/Property1Group1101';
import Property1Group111 from './pages/Property1Group111';
import Property1Group1111 from './pages/Property1Group1111';
import Property1Group1112 from './pages/Property1Group1112';
import Property1Group1113 from './pages/Property1Group1113';
import Property1Group1114 from './pages/Property1Group1114';
import Property1Group116 from './pages/Property1Group116';
import Property1Group1161 from './pages/Property1Group1161';
import Property1Group117 from './pages/Property1Group117';
import Property1Group1171 from './pages/Property1Group1171';
import Property1Group125 from './pages/Property1Group125';
import Property1Group126 from './pages/Property1Group126';
import Property1Group1261 from './pages/Property1Group1261';
import Property1Group127 from './pages/Property1Group127';
import Property1Group128 from './pages/Property1Group128';
import Property1Group1281 from './pages/Property1Group1281';
import Property1Group134 from './pages/Property1Group134';
import Property1Group135 from './pages/Property1Group135';
import Property1Group1351 from './pages/Property1Group1351';
import Property1Group142 from './pages/Property1Group142';
import Property1Group1421 from './pages/Property1Group1421';
import Property1Group143 from './pages/Property1Group143';
import Property1Group144 from './pages/Property1Group144';
import Property1Group1441 from './pages/Property1Group1441';
import Property1Group145 from './pages/Property1Group145';
import Property1Group1451 from './pages/Property1Group1451';
import Property1Group155 from './pages/Property1Group155';
import Property1Group162 from './pages/Property1Group162';
import Property1Group163 from './pages/Property1Group163';
import Property1Group1631 from './pages/Property1Group1631';
import Property1Group1632 from './pages/Property1Group1632';
import Property1Group164 from './pages/Property1Group164';
import Property1Group169 from './pages/Property1Group169';
import Property1Group170 from './pages/Property1Group170';
import Property1Group99 from './pages/Property1Group99';
import Property1Group991 from './pages/Property1Group991';
import Property1No1 from './pages/Property1No1';
import Property1No11 from './pages/Property1No11';
import Property1Rectangle114 from './pages/Property1Rectangle114';
import Property1Rectangle115 from './pages/Property1Rectangle115';
import Property1Rectangle116 from './pages/Property1Rectangle116';
import Property1Rent from './pages/Property1Rent';
import Property1Rent1 from './pages/Property1Rent1';
import Property1Skill from './pages/Property1Skill';
import Property1Title from './pages/Property1Title';
import RealEstate from './pages/RealEstate';
import RealEstate1 from './pages/RealEstate1';
import RealEstate10 from './pages/RealEstate10';
import RealEstate2 from './pages/RealEstate2';
import RealEstate3 from './pages/RealEstate3';
import RealEstate4 from './pages/RealEstate4';
import RealEstate5 from './pages/RealEstate5';
import RealEstate6 from './pages/RealEstate6';
import RealEstate7 from './pages/RealEstate7';
import RealEstate8 from './pages/RealEstate8';
import RealEstate9 from './pages/RealEstate9';
import Register from './pages/Register';
import Register1 from './pages/Register1';
import SelectYouCar2 from './pages/SelectYouCar2';
import Services from './pages/Services';
import SignIn from './pages/SignIn';
import SignIn1 from './pages/SignIn1';
import TextSize from './pages/TextSize';


const router = createBrowserRouter([
  { path: '/', element: <F12Main /> },
{ path: '/AccountType', element: <AccountType /> },
{ path: '/AndroidLarge1', element: <AndroidLarge1 /> },
{ path: '/Buy', element: <Buy /> },
{ path: '/Component1', element: <Component1 /> },
{ path: '/Component11', element: <Component11 /> },
{ path: '/Component3', element: <Component3 /> },
{ path: '/Component5', element: <Component5 /> },
{ path: '/DatePosted', element: <DatePosted /> },
{ path: '/Elgroup', element: <Elgroup /> },
{ path: '/Fcc', element: <Fcc /> },
{ path: '/Filters', element: <Filters /> },
{ path: '/FlowbitehomeSolid', element: <FlowbitehomeSolid /> },
{ path: '/Frame117', element: <Frame117 /> },
{ path: '/Frame123', element: <Frame123 /> },
{ path: '/Frame124', element: <Frame124 /> },
{ path: '/Frame1241', element: <Frame1241 /> },
{ path: '/Frame127', element: <Frame127 /> },
{ path: '/Frame1271', element: <Frame1271 /> },
{ path: '/Frame136', element: <Frame136 /> },
{ path: '/Frame168', element: <Frame168 /> },
{ path: '/Frame169', element: <Frame169 /> },
{ path: '/Frame170', element: <Frame170 /> },
{ path: '/Frame176', element: <Frame176 /> },
{ path: '/Frame1761', element: <Frame1761 /> },
{ path: '/Frame177', element: <Frame177 /> },
{ path: '/Frame1771', element: <Frame1771 /> },
{ path: '/Frame178', element: <Frame178 /> },
{ path: '/Frame195', element: <Frame195 /> },
{ path: '/Frame213', element: <Frame213 /> },
{ path: '/Frame214', element: <Frame214 /> },
{ path: '/Frame215', element: <Frame215 /> },
{ path: '/Frame216', element: <Frame216 /> },
{ path: '/Frame2161', element: <Frame2161 /> },
{ path: '/Frame232', element: <Frame232 /> },
{ path: '/Frame2321', element: <Frame2321 /> },
{ path: '/Frame234', element: <Frame234 /> },
{ path: '/Frame237', element: <Frame237 /> },
{ path: '/Frame243', element: <Frame243 /> },
{ path: '/Gadgets', element: <Gadgets /> },
{ path: '/Group100', element: <Group100 /> },
{ path: '/Group101', element: <Group101 /> },
{ path: '/Group117', element: <Group117 /> },
{ path: '/Group119', element: <Group119 /> },
{ path: '/Group120', element: <Group120 /> },
{ path: '/Group1201', element: <Group1201 /> },
{ path: '/Group121', element: <Group121 /> },
{ path: '/Group122', element: <Group122 /> },
{ path: '/Group1221', element: <Group1221 /> },
{ path: '/Group123', element: <Group123 /> },
{ path: '/Group1231', element: <Group1231 /> },
{ path: '/Group124', element: <Group124 /> },
{ path: '/Group1241', element: <Group1241 /> },
{ path: '/Group1242', element: <Group1242 /> },
{ path: '/Group125', element: <Group125 /> },
{ path: '/Group128', element: <Group128 /> },
{ path: '/Group129', element: <Group129 /> },
{ path: '/Group168', element: <Group168 /> },
{ path: '/Group42', element: <Group42 /> },
{ path: '/Group89', element: <Group89 /> },
{ path: '/Group93', element: <Group93 /> },
{ path: '/Group97', element: <Group97 /> },
{ path: '/Group98', element: <Group98 /> },
{ path: '/HeroiconsbuildingOffice16Solid', element: <HeroiconsbuildingOffice16Solid /> },
{ path: '/IconParkOutlinedown', element: <IconParkOutlinedown /> },
{ path: '/IconParkOutlinedown1', element: <IconParkOutlinedown1 /> },
{ path: '/IconParkOutlinepeoples', element: <IconParkOutlinepeoples /> },
{ path: '/IcoutlinePeople', element: <IcoutlinePeople /> },
{ path: '/InstagramPost12', element: <InstagramPost12 /> },
{ path: '/InstagramPost13', element: <InstagramPost13 /> },
{ path: '/InstagramPost14', element: <InstagramPost14 /> },
{ path: '/InstagramPost2', element: <InstagramPost2 /> },
{ path: '/InstagramPost3', element: <InstagramPost3 /> },
{ path: '/InstagramPost5', element: <InstagramPost5 /> },
{ path: '/InstagramPost6', element: <InstagramPost6 /> },
{ path: '/InstagramPost7', element: <InstagramPost7 /> },
{ path: '/InstagramPost9', element: <InstagramPost9 /> },
{ path: '/IrqRwB31VqcenPfnZc35ZripVv11', element: <IrqRwB31VqcenPfnZc35ZripVv11 /> },
{ path: '/IruGsLt44Aoyq5Or3JhfmTxjw01', element: <IruGsLt44Aoyq5Or3JhfmTxjw01 /> },
{ path: '/IyumTiFgjb92PtpHeicdkmapk51', element: <IyumTiFgjb92PtpHeicdkmapk51 /> },
{ path: '/JobByCourse', element: <JobByCourse /> },
{ path: '/JobPage', element: <JobPage /> },
{ path: '/JobPage1', element: <JobPage1 /> },
{ path: '/JobPage2', element: <JobPage2 /> },
{ path: '/JobPage3', element: <JobPage3 /> },
{ path: '/JobPage4', element: <JobPage4 /> },
{ path: '/JobPage5', element: <JobPage5 /> },
{ path: '/JobPortal', element: <JobPortal /> },
{ path: '/JobPortal1', element: <JobPortal1 /> },
{ path: '/JobPortal2', element: <JobPortal2 /> },
{ path: '/JobPortal3', element: <JobPortal3 /> },
{ path: '/JobPortal4', element: <JobPortal4 /> },
{ path: '/JobPortal5', element: <JobPortal5 /> },
{ path: '/JobsComponent', element: <JobsComponent /> },
{ path: '/JobsFrame117', element: <JobsFrame117 /> },
{ path: '/LikeComment', element: <LikeComment /> },
{ path: '/Location', element: <Location /> },
{ path: '/MaskGroup', element: <MaskGroup /> },
{ path: '/Mdiheart', element: <Mdiheart /> },
{ path: '/MingcutedownFill', element: <MingcutedownFill /> },
{ path: '/Motorcycles', element: <Motorcycles /> },
{ path: '/NumOfEmploy', element: <NumOfEmploy /> },
{ path: '/OuimlCreateSingleMetricJob', element: <OuimlCreateSingleMetricJob /> },
{ path: '/Page', element: <Page /> },
{ path: '/PopUpSignIn', element: <PopUpSignIn /> },
{ path: '/PopUpSignIn1', element: <PopUpSignIn1 /> },
{ path: '/PopUpSignIn2', element: <PopUpSignIn2 /> },
{ path: '/PopUpSignIn3', element: <PopUpSignIn3 /> },
{ path: '/Profile', element: <Profile /> },
{ path: '/Profile1', element: <Profile1 /> },
{ path: '/Property1AccountTyoes', element: <Property1AccountTyoes /> },
{ path: '/Property1AutoMobile', element: <Property1AutoMobile /> },
{ path: '/Property1Buy', element: <Property1Buy /> },
{ path: '/Property1Chinnu', element: <Property1Chinnu /> },
{ path: '/Property1Company', element: <Property1Company /> },
{ path: '/Property1Component17', element: <Property1Component17 /> },
{ path: '/Property1Component171', element: <Property1Component171 /> },
{ path: '/Property1Component172', element: <Property1Component172 /> },
{ path: '/Property1Component173', element: <Property1Component173 /> },
{ path: '/Property1Component174', element: <Property1Component174 /> },
{ path: '/Property1Component175', element: <Property1Component175 /> },
{ path: '/Property1Component176', element: <Property1Component176 /> },
{ path: '/Property1Component18', element: <Property1Component18 /> },
{ path: '/Property1Component181', element: <Property1Component181 /> },
{ path: '/Property1Component182', element: <Property1Component182 /> },
{ path: '/Property1Component183', element: <Property1Component183 /> },
{ path: '/Property1Component184', element: <Property1Component184 /> },
{ path: '/Property1Component185', element: <Property1Component185 /> },
{ path: '/Property1Component35', element: <Property1Component35 /> },
{ path: '/Property1Default', element: <Property1Default /> },
{ path: '/Property1Default1', element: <Property1Default1 /> },
{ path: '/Property1Default10', element: <Property1Default10 /> },
{ path: '/Property1Default11', element: <Property1Default11 /> },
{ path: '/Property1Default12', element: <Property1Default12 /> },
{ path: '/Property1Default13', element: <Property1Default13 /> },
{ path: '/Property1Default14', element: <Property1Default14 /> },
{ path: '/Property1Default15', element: <Property1Default15 /> },
{ path: '/Property1Default16', element: <Property1Default16 /> },
{ path: '/Property1Default17', element: <Property1Default17 /> },
{ path: '/Property1Default18', element: <Property1Default18 /> },
{ path: '/Property1Default19', element: <Property1Default19 /> },
{ path: '/Property1Default2', element: <Property1Default2 /> },
{ path: '/Property1Default20', element: <Property1Default20 /> },
{ path: '/Property1Default21', element: <Property1Default21 /> },
{ path: '/Property1Default22', element: <Property1Default22 /> },
{ path: '/Property1Default23', element: <Property1Default23 /> },
{ path: '/Property1Default24', element: <Property1Default24 /> },
{ path: '/Property1Default25', element: <Property1Default25 /> },
{ path: '/Property1Default26', element: <Property1Default26 /> },
{ path: '/Property1Default27', element: <Property1Default27 /> },
{ path: '/Property1Default28', element: <Property1Default28 /> },
{ path: '/Property1Default29', element: <Property1Default29 /> },
{ path: '/Property1Default3', element: <Property1Default3 /> },
{ path: '/Property1Default30', element: <Property1Default30 /> },
{ path: '/Property1Default31', element: <Property1Default31 /> },
{ path: '/Property1Default32', element: <Property1Default32 /> },
{ path: '/Property1Default33', element: <Property1Default33 /> },
{ path: '/Property1Default34', element: <Property1Default34 /> },
{ path: '/Property1Default35', element: <Property1Default35 /> },
{ path: '/Property1Default36', element: <Property1Default36 /> },
{ path: '/Property1Default37', element: <Property1Default37 /> },
{ path: '/Property1Default38', element: <Property1Default38 /> },
{ path: '/Property1Default39', element: <Property1Default39 /> },
{ path: '/Property1Default4', element: <Property1Default4 /> },
{ path: '/Property1Default5', element: <Property1Default5 /> },
{ path: '/Property1Default6', element: <Property1Default6 /> },
{ path: '/Property1Default7', element: <Property1Default7 /> },
{ path: '/Property1Default8', element: <Property1Default8 /> },
{ path: '/Property1Default9', element: <Property1Default9 /> },
{ path: '/Property1Filter2', element: <Property1Filter2 /> },
{ path: '/Property1Filter3', element: <Property1Filter3 /> },
{ path: '/Property1Frame123', element: <Property1Frame123 /> },
{ path: '/Property1Frame1231', element: <Property1Frame1231 /> },
{ path: '/Property1Frame124', element: <Property1Frame124 /> },
{ path: '/Property1Frame1241', element: <Property1Frame1241 /> },
{ path: '/Property1Frame1242', element: <Property1Frame1242 /> },
{ path: '/Property1Frame125', element: <Property1Frame125 /> },
{ path: '/Property1Frame1251', element: <Property1Frame1251 /> },
{ path: '/Property1Frame126', element: <Property1Frame126 /> },
{ path: '/Property1Frame1261', element: <Property1Frame1261 /> },
{ path: '/Property1Frame1262', element: <Property1Frame1262 /> },
{ path: '/Property1Frame1263', element: <Property1Frame1263 /> },
{ path: '/Property1Frame127', element: <Property1Frame127 /> },
{ path: '/Property1Frame1271', element: <Property1Frame1271 /> },
{ path: '/Property1Frame1272', element: <Property1Frame1272 /> },
{ path: '/Property1Frame128', element: <Property1Frame128 /> },
{ path: '/Property1Frame1281', element: <Property1Frame1281 /> },
{ path: '/Property1Frame137', element: <Property1Frame137 /> },
{ path: '/Property1Frame1371', element: <Property1Frame1371 /> },
{ path: '/Property1Frame1372', element: <Property1Frame1372 /> },
{ path: '/Property1Frame1373', element: <Property1Frame1373 /> },
{ path: '/Property1Frame1374', element: <Property1Frame1374 /> },
{ path: '/Property1Frame1375', element: <Property1Frame1375 /> },
{ path: '/Property1Frame1376', element: <Property1Frame1376 /> },
{ path: '/Property1Frame1377', element: <Property1Frame1377 /> },
{ path: '/Property1Frame138', element: <Property1Frame138 /> },
{ path: '/Property1Frame1381', element: <Property1Frame1381 /> },
{ path: '/Property1Frame1382', element: <Property1Frame1382 /> },
{ path: '/Property1Frame1383', element: <Property1Frame1383 /> },
{ path: '/Property1Frame1384', element: <Property1Frame1384 /> },
{ path: '/Property1Frame1385', element: <Property1Frame1385 /> },
{ path: '/Property1Frame1386', element: <Property1Frame1386 /> },
{ path: '/Property1Frame1387', element: <Property1Frame1387 /> },
{ path: '/Property1Frame142', element: <Property1Frame142 /> },
{ path: '/Property1Frame174', element: <Property1Frame174 /> },
{ path: '/Property1Frame1741', element: <Property1Frame1741 /> },
{ path: '/Property1Frame1742', element: <Property1Frame1742 /> },
{ path: '/Property1Frame1743', element: <Property1Frame1743 /> },
{ path: '/Property1Frame1744', element: <Property1Frame1744 /> },
{ path: '/Property1Frame176', element: <Property1Frame176 /> },
{ path: '/Property1Frame1761', element: <Property1Frame1761 /> },
{ path: '/Property1Frame1762', element: <Property1Frame1762 /> },
{ path: '/Property1Frame1763', element: <Property1Frame1763 /> },
{ path: '/Property1Frame1764', element: <Property1Frame1764 /> },
{ path: '/Property1Frame1765', element: <Property1Frame1765 /> },
{ path: '/Property1Frame1766', element: <Property1Frame1766 /> },
{ path: '/Property1Frame1767', element: <Property1Frame1767 /> },
{ path: '/Property1Frame1768', element: <Property1Frame1768 /> },
{ path: '/Property1Frame177', element: <Property1Frame177 /> },
{ path: '/Property1Frame1771', element: <Property1Frame1771 /> },
{ path: '/Property1Frame1772', element: <Property1Frame1772 /> },
{ path: '/Property1Frame1773', element: <Property1Frame1773 /> },
{ path: '/Property1Frame1774', element: <Property1Frame1774 /> },
{ path: '/Property1Frame178', element: <Property1Frame178 /> },
{ path: '/Property1Frame1781', element: <Property1Frame1781 /> },
{ path: '/Property1Frame1782', element: <Property1Frame1782 /> },
{ path: '/Property1Frame179', element: <Property1Frame179 /> },
{ path: '/Property1Frame1791', element: <Property1Frame1791 /> },
{ path: '/Property1Frame1792', element: <Property1Frame1792 /> },
{ path: '/Property1Frame180', element: <Property1Frame180 /> },
{ path: '/Property1Frame1801', element: <Property1Frame1801 /> },
{ path: '/Property1Frame1802', element: <Property1Frame1802 /> },
{ path: '/Property1Frame1803', element: <Property1Frame1803 /> },
{ path: '/Property1Frame1804', element: <Property1Frame1804 /> },
{ path: '/Property1Frame1805', element: <Property1Frame1805 /> },
{ path: '/Property1Frame1806', element: <Property1Frame1806 /> },
{ path: '/Property1Frame1807', element: <Property1Frame1807 /> },
{ path: '/Property1Frame181', element: <Property1Frame181 /> },
{ path: '/Property1Frame184', element: <Property1Frame184 /> },
{ path: '/Property1Frame1841', element: <Property1Frame1841 /> },
{ path: '/Property1Frame1842', element: <Property1Frame1842 /> },
{ path: '/Property1Frame1843', element: <Property1Frame1843 /> },
{ path: '/Property1Frame1844', element: <Property1Frame1844 /> },
{ path: '/Property1Frame1845', element: <Property1Frame1845 /> },
{ path: '/Property1Frame215', element: <Property1Frame215 /> },
{ path: '/Property1Frame2151', element: <Property1Frame2151 /> },
{ path: '/Property1Frame2152', element: <Property1Frame2152 /> },
{ path: '/Property1Frame2153', element: <Property1Frame2153 /> },
{ path: '/Property1Frame2154', element: <Property1Frame2154 /> },
{ path: '/Property1Frame2155', element: <Property1Frame2155 /> },
{ path: '/Property1Frame217', element: <Property1Frame217 /> },
{ path: '/Property1Frame233', element: <Property1Frame233 /> },
{ path: '/Property1Frame2331', element: <Property1Frame2331 /> },
{ path: '/Property1Frame2332', element: <Property1Frame2332 /> },
{ path: '/Property1Frame2333', element: <Property1Frame2333 /> },
{ path: '/Property1Frame2334', element: <Property1Frame2334 /> },
{ path: '/Property1Frame2335', element: <Property1Frame2335 /> },
{ path: '/Property1Frame2336', element: <Property1Frame2336 /> },
{ path: '/Property1Frame2337', element: <Property1Frame2337 /> },
{ path: '/Property1Frame2338', element: <Property1Frame2338 /> },
{ path: '/Property1Frame235', element: <Property1Frame235 /> },
{ path: '/Property1Frame2351', element: <Property1Frame2351 /> },
{ path: '/Property1Frame2352', element: <Property1Frame2352 /> },
{ path: '/Property1Frame2353', element: <Property1Frame2353 /> },
{ path: '/Property1Frame2354', element: <Property1Frame2354 /> },
{ path: '/Property1Frame2355', element: <Property1Frame2355 /> },
{ path: '/Property1Frame2356', element: <Property1Frame2356 /> },
{ path: '/Property1Frame2357', element: <Property1Frame2357 /> },
{ path: '/Property1Frame2358', element: <Property1Frame2358 /> },
{ path: '/Property1Frame237', element: <Property1Frame237 /> },
{ path: '/Property1Frame2371', element: <Property1Frame2371 /> },
{ path: '/Property1Frame2372', element: <Property1Frame2372 /> },
{ path: '/Property1Frame2373', element: <Property1Frame2373 /> },
{ path: '/Property1Frame2374', element: <Property1Frame2374 /> },
{ path: '/Property1Frame238', element: <Property1Frame238 /> },
{ path: '/Property1Frame2381', element: <Property1Frame2381 /> },
{ path: '/Property1Frame2382', element: <Property1Frame2382 /> },
{ path: '/Property1Frame2383', element: <Property1Frame2383 /> },
{ path: '/Property1Group101', element: <Property1Group101 /> },
{ path: '/Property1Group1011', element: <Property1Group1011 /> },
{ path: '/Property1Group1012', element: <Property1Group1012 /> },
{ path: '/Property1Group102', element: <Property1Group102 /> },
{ path: '/Property1Group1021', element: <Property1Group1021 /> },
{ path: '/Property1Group104', element: <Property1Group104 /> },
{ path: '/Property1Group106', element: <Property1Group106 /> },
{ path: '/Property1Group1061', element: <Property1Group1061 /> },
{ path: '/Property1Group1062', element: <Property1Group1062 /> },
{ path: '/Property1Group107', element: <Property1Group107 /> },
{ path: '/Property1Group1071', element: <Property1Group1071 /> },
{ path: '/Property1Group109', element: <Property1Group109 /> },
{ path: '/Property1Group1091', element: <Property1Group1091 /> },
{ path: '/Property1Group110', element: <Property1Group110 /> },
{ path: '/Property1Group1101', element: <Property1Group1101 /> },
{ path: '/Property1Group111', element: <Property1Group111 /> },
{ path: '/Property1Group1111', element: <Property1Group1111 /> },
{ path: '/Property1Group1112', element: <Property1Group1112 /> },
{ path: '/Property1Group1113', element: <Property1Group1113 /> },
{ path: '/Property1Group1114', element: <Property1Group1114 /> },
{ path: '/Property1Group116', element: <Property1Group116 /> },
{ path: '/Property1Group1161', element: <Property1Group1161 /> },
{ path: '/Property1Group117', element: <Property1Group117 /> },
{ path: '/Property1Group1171', element: <Property1Group1171 /> },
{ path: '/Property1Group125', element: <Property1Group125 /> },
{ path: '/Property1Group126', element: <Property1Group126 /> },
{ path: '/Property1Group1261', element: <Property1Group1261 /> },
{ path: '/Property1Group127', element: <Property1Group127 /> },
{ path: '/Property1Group128', element: <Property1Group128 /> },
{ path: '/Property1Group1281', element: <Property1Group1281 /> },
{ path: '/Property1Group134', element: <Property1Group134 /> },
{ path: '/Property1Group135', element: <Property1Group135 /> },
{ path: '/Property1Group1351', element: <Property1Group1351 /> },
{ path: '/Property1Group142', element: <Property1Group142 /> },
{ path: '/Property1Group1421', element: <Property1Group1421 /> },
{ path: '/Property1Group143', element: <Property1Group143 /> },
{ path: '/Property1Group144', element: <Property1Group144 /> },
{ path: '/Property1Group1441', element: <Property1Group1441 /> },
{ path: '/Property1Group145', element: <Property1Group145 /> },
{ path: '/Property1Group1451', element: <Property1Group1451 /> },
{ path: '/Property1Group155', element: <Property1Group155 /> },
{ path: '/Property1Group162', element: <Property1Group162 /> },
{ path: '/Property1Group163', element: <Property1Group163 /> },
{ path: '/Property1Group1631', element: <Property1Group1631 /> },
{ path: '/Property1Group1632', element: <Property1Group1632 /> },
{ path: '/Property1Group164', element: <Property1Group164 /> },
{ path: '/Property1Group169', element: <Property1Group169 /> },
{ path: '/Property1Group170', element: <Property1Group170 /> },
{ path: '/Property1Group99', element: <Property1Group99 /> },
{ path: '/Property1Group991', element: <Property1Group991 /> },
{ path: '/Property1No1', element: <Property1No1 /> },
{ path: '/Property1No11', element: <Property1No11 /> },
{ path: '/Property1Rectangle114', element: <Property1Rectangle114 /> },
{ path: '/Property1Rectangle115', element: <Property1Rectangle115 /> },
{ path: '/Property1Rectangle116', element: <Property1Rectangle116 /> },
{ path: '/Property1Rent', element: <Property1Rent /> },
{ path: '/Property1Rent1', element: <Property1Rent1 /> },
{ path: '/Property1Skill', element: <Property1Skill /> },
{ path: '/Property1Title', element: <Property1Title /> },
{ path: '/RealEstate', element: <RealEstate /> },
{ path: '/RealEstate1', element: <RealEstate1 /> },
{ path: '/RealEstate10', element: <RealEstate10 /> },
{ path: '/RealEstate2', element: <RealEstate2 /> },
{ path: '/RealEstate3', element: <RealEstate3 /> },
{ path: '/RealEstate4', element: <RealEstate4 /> },
{ path: '/RealEstate5', element: <RealEstate5 /> },
{ path: '/RealEstate6', element: <RealEstate6 /> },
{ path: '/RealEstate7', element: <RealEstate7 /> },
{ path: '/RealEstate8', element: <RealEstate8 /> },
{ path: '/RealEstate9', element: <RealEstate9 /> },
{ path: '/Register', element: <Register /> },
{ path: '/Register1', element: <Register1 /> },
{ path: '/SelectYouCar2', element: <SelectYouCar2 /> },
{ path: '/Services', element: <Services /> },
{ path: '/SignIn', element: <SignIn /> },
{ path: '/SignIn1', element: <SignIn1 /> },
{ path: '/TextSize', element: <TextSize /> },
]);

export default function App() {
  return (
    <RouterProvider router={router} />
  );
}